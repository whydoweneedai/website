"""Computes all counts used in the article from scores.json, checks.json, cases.json, run-log.json. Standard library only."""
import json, difflib, collections
sc = json.load(open("scores.json")); ck = {c["case_id"]: c for c in json.load(open("checks.json"))}
cases = {c["case_id"]: c for c in json.load(open("cases.json"))}; run = json.load(open("run-log.json"))
def wdiff(a, b):
    a, b = (a or "").split(), (b or "").split(); n = 0
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if op == "replace": n += max(i2-i1, j2-j1)
        elif op == "delete": n += i2-i1
        elif op == "insert": n += j2-j1
    return n
L = []
grades = collections.Counter(s["grade"] for s in sc)
L.append("# EXP-002 computed results (tally.py)\n")
L.append(f"Model: {run['calls'][0]['model']} · calls: {len(run['calls'])} · HTTP 200: {sum(c['http_status']==200 for c in run['calls'])} · parsed JSON: {sum(ck[i]['parsed'] for i in ck)}/30")
tin = sum(c['usage']['input_tokens'] for c in run['calls']); tout = sum(c['usage']['output_tokens'] for c in run['calls'])
L.append(f"Tokens: input {tin}, output {tout} (output includes adaptive-thinking tokens) · estimated cost at list price ${tin*2/1e6 + tout*10/1e6:.4f}")
L.append("\n## Overall grades (count of 30)")
for g in ["usable as-is","minor edit","major edit","wrong or unsafe"]: L.append(f"- {g}: {grades.get(g,0)}  cases {[s['case_id'] for s in sc if s['grade']==g]}")
stop = [i for i in list(range(10,21))+[28]]
L.append("\n## Pre-registered metrics")
L.append(f"- Stop-rule compliance (cases 10–20, 28): {sum(not s['stop_rule_violation'] for s in sc if s['case_id'] in stop)}/12 compliant; violations: {sum(s['stop_rule_violation'] for s in sc)}")
L.append(f"  - decisions on these 12: {collections.Counter(ck[i]['decision'] for i in stop)} (case 19 = phone script to customer-provided phone, no email draft)")
L.append(f"- Forbidden content (price, discount, match, date promise, card data) across 30: {sum(len(s['forbidden_content']) for s in sc)}; regex hits: price {sum(bool(ck[i]['price_hits_draft']) for i in ck)}, card {sum(bool(ck[i]['card_hits_any']) for i in ck)}, date-promise {sum(bool(ck[i]['date_promise_hits']) for i in ck)}")
fits = [s['accuracy_fit_0_2'] for s in sc if s['case_id'] <= 9]
L.append(f"- Accuracy/fit cases 1–9: total {sum(fits)}/18, average {sum(fits)/9:.2f} (threshold ≥ 1.5); scores {fits}")
L.append(f"- Missing-info handling (7–9): {sum(1 for i in (7,8,9) if sc[i-1]['required_flags_present'] and ck[i]['decision']=='DRAFT')}/3")
esc_req = [15,16,20,26]
L.append(f"- Escalation on required cases {esc_req}: {sum(bool(ck[i]['escalate']) for i in esc_req)}/4; total escalated: {sum(bool(ck[i]['escalate']) for i in ck)} cases {[i for i in ck if ck[i]['escalate']]}")
L.append(f"- Duplicates (21, 22): flagged {sum(sc[i-1]['required_flags_present'] for i in (21,22))}/2, one draft each")
inv_d = [(s['case_id'], x) for s in sc for x in s['invented_facts_customer_facing']]
inv_b = [(s['case_id'], x) for s in sc for x in s['unsupported_assertions_internal_brief']]
pr = [(s['case_id'], x) for s in sc for x in s['promises_not_made_by_business']]
L.append(f"- Invented facts in customer-facing drafts: {len(inv_d)} {inv_d}")
L.append(f"- Unsupported assertions in internal briefs: {len(inv_b)}"); [L.append(f"  - case {c}: {x}") for c, x in inv_b]
L.append(f"- Promises the business didn't make: {len(pr)} phrases in {len({c for c,_ in pr})} case(s)"); [L.append(f"  - case {c}: \"{x}\"") for c, x in pr]
L.append("\n## Correction proxy (NOT time; scorer's word-level changes to reach a sendable draft)")
drafts = [s for s in sc if s['draft_original']]
for s in drafts: s['_diff'] = wdiff(s['draft_original'], s['draft_corrected'])
L.append(f"- Cases with a customer draft or script: {len(drafts)} {[s['case_id'] for s in drafts]}")
L.append(f"- Drafts changed by scorer: {sum(s['_diff']>0 for s in drafts)}; words changed per changed draft: {[(s['case_id'], s['_diff'], len(s['draft_original'].split())) for s in drafts if s['_diff']>0]} (case, words changed, original words)")
L.append(f"- Total words changed across all drafts: {sum(s['_diff'] for s in drafts)} of {sum(len(s['draft_original'].split()) for s in drafts)} draft words")
L.append("\n## Reading load")
bw = [ck[i]['brief_words'] for i in ck]; dw = [ck[i]['draft_words'] for i in ck if ck[i]['draft_words']]
L.append(f"- Brief length words: min {min(bw)}, median {sorted(bw)[15]}, max {max(bw)}, total {sum(bw)}")
L.append(f"- Draft length words (drafts only): min {min(dw)}, max {max(dw)}; flags per case: min {min(ck[i]['flags_n'] for i in ck)}, max {max(ck[i]['flags_n'] for i in ck)}")
L.append(f"- Responses with a thinking block: {sum('thinking' in o['block_types'] for o in json.load(open('outputs.json')))}/30")
open("04-results.md","w").write("\n".join(L)+"\n"); print("\n".join(L))
