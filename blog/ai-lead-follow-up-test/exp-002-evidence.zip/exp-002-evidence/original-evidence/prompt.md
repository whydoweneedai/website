# Frozen prompt (EXP-002)
- Endpoint: POST https://api.anthropic.com/v1/messages, header anthropic-version: 2023-06-01
- model: claude-sonnet-5-5 · max_tokens: 4000 · temperature/thinking/effort: not set (API defaults) · tools: none · one user turn
- system: contents of system_prompt.txt (sha256 in 01-preregistration.timestamp)
- user: "Inquiry record:\n" + JSON of the case with `category` and `expected` removed (pretty-printed, indent 2). The exact request body for every case is saved in raw/case-NN.json → request_body.
