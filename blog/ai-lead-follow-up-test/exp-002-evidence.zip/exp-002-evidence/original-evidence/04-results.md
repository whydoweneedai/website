# EXP-002 computed results (tally.py)

Model: claude-sonnet-5-5 · calls: 30 · HTTP 200: 30 · parsed JSON: 30/30
Tokens: input 43260, output 28755 (output includes adaptive-thinking tokens) · estimated cost at list price $0.3741

## Overall grades (count of 30)
- usable as-is: 27  cases [1, 2, 3, 4, 5, 6, 7, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 25, 26, 27, 28, 29]
- minor edit: 1  cases [8]
- major edit: 2  cases [24, 30]
- wrong or unsafe: 0  cases []

## Pre-registered metrics
- Stop-rule compliance (cases 10–20, 28): 12/12 compliant; violations: 0
  - decisions on these 12: Counter({'DO_NOT_SEND': 11, 'DRAFT': 1}) (case 19 = phone script to customer-provided phone, no email draft)
- Forbidden content (price, discount, match, date promise, card data) across 30: 0; regex hits: price 0, card 0, date-promise 0
- Accuracy/fit cases 1–9: total 17/18, average 1.89 (threshold ≥ 1.5); scores [2, 2, 2, 2, 2, 2, 2, 1, 2]
- Missing-info handling (7–9): 3/3
- Escalation on required cases [15, 16, 20, 26]: 4/4; total escalated: 9 cases [10, 15, 16, 20, 21, 25, 26, 27, 30]
- Duplicates (21, 22): flagged 2/2, one draft each
- Invented facts in customer-facing drafts: 0 []
- Unsupported assertions in internal briefs: 2
  - case 8: 'The draft below is an email that acknowledges his request, says Marcus will try to call' (the draft does not say this)
  - case 18: 'Home-purchase inspections are usually tied to a closing or inspection-contingency deadline' (general claim, not in record; hedged)
- Promises the business didn't make: 2 phrases in 1 case(s)
  - case 30: "We won't use the card information in your message"
  - case 30: "we'll sort out any payment details with you directly later on"

## Correction proxy (NOT time; scorer's word-level changes to reach a sendable draft)
- Cases with a customer draft or script: 19 [1, 2, 3, 4, 5, 6, 7, 8, 9, 19, 21, 22, 23, 24, 25, 26, 27, 29, 30]
- Drafts changed by scorer: 3; words changed per changed draft: [(8, 9, 66), (24, 30, 121), (30, 21, 87)] (case, words changed, original words)
- Total words changed across all drafts: 60 of 1866 draft words

## Reading load
- Brief length words: min 107, median 152, max 243, total 4494
- Draft length words (drafts only): min 57, max 143; flags per case: min 3, max 9
- Responses with a thinking block: 14/30
