# Evidence: EXP-002 lead follow-up synthetic test (30 invented inquiries)
Evidence label: **Synthetic test.** One AI model run once per case on invented records. Not a live pilot, not a case study, no customers, no messages sent.
Run by: Steve (the site's AI writing assistant), 2026-10-19 ET, on the shared box, using the owner's Anthropic API key from the environment. The key isn't stored in any file here.

| File | What | Recorded (ET) |
|---|---|---|
| 01-preregistration.md (+ .timestamp) | Deviations from design.md, frozen system, expected behavior summary, rubric, reporting rules; hashes of cases.json, system_prompt.txt, prompt.md, run.py, build_cases.py | 08:36:45 |
| build_cases.py → cases.json | 30 invented records with `expected` blocks (stripped before sending) | 08:36 |
| system_prompt.txt, prompt.md | Exact instructions and request shape | 08:36 |
| run.py | API runner with a $4 cap | 08:36 |
| raw/case-NN.json | Request body (no headers) + full response + timestamps + estimated cost | 08:36:49–08:41:04 |
| run-log.json, run-console.txt | Per-call usage, model, status; total $0.37407 | 08:41 |
| outputs.json | Parsed JSON outputs + block types | 08:41 |
| checks.py → checks.json | Regex screen (price/discount/card/date-promise), word counts | 08:42 |
| 03-scoring-started.txt | Time scoring began | 08:42 |
| build_scores.py → scores.json | Scorer judgments, corrected drafts, proxy-rule grades | 08:43 |
| tally.py → 04-results.md (+ 03-scores.timestamp) | All counts used in the article | 08:43:26 |

Reproduce scoring: `python3 checks.py && python3 build_scores.py && python3 tally.py` (standard library only). Rerunning run.py makes new API calls, costs money, and will overwrite raw/.

## Limits
Single scorer, who also wrote the cases and the prompt. One model, one run, default settings (adaptive thinking appeared in 14/30). Hashes and timestamps are self-recorded. Case-writing artifacts: phone numbers without area codes; case 17's attempt count is inconsistent with its history (the model flagged it).
