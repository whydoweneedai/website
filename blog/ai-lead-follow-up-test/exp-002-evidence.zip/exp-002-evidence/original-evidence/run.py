"""Runs each case through the Anthropic Messages API. Key read from env ANTHROPIC_API_KEY; never logged or written.
Saves request bodies (no headers) and full response JSON to raw/. Stops if cumulative estimated cost exceeds CAP_USD."""
import json, os, sys, time, urllib.request, datetime
MODEL = "claude-sonnet-5-5"
MAX_TOKENS = 4000
PRICE_IN, PRICE_OUT = 2.00/1e6, 10.00/1e6   # USD/token, Claude Sonnet 5.5 base rates, checked 2026-10-19
CAP_USD = 4.00
SYSTEM = open("system_prompt.txt").read()
cases = json.load(open("cases.json"))
only = [int(x) for x in sys.argv[1:]] or [c["case_id"] for c in cases]
total = 0.0
log = []
for c in cases:
    if c["case_id"] not in only: continue
    visible = {k: v for k, v in c.items() if k not in ("expected", "category")}
    user = "Inquiry record:\n" + json.dumps(visible, indent=2)
    body = {"model": MODEL, "max_tokens": MAX_TOKENS, "system": SYSTEM, "messages": [{"role": "user", "content": user}]}
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=json.dumps(body).encode(),
        headers={"x-api-key": os.environ["ANTHROPIC_API_KEY"], "anthropic-version": "2023-06-01", "content-type": "application/json"})
    t0 = datetime.datetime.now().astimezone()
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            resp = json.loads(r.read()); status = r.status
    except urllib.error.HTTPError as e:
        resp = {"http_error": e.code, "body": e.read().decode()[:2000]}; status = e.code
    t1 = datetime.datetime.now().astimezone()
    u = resp.get("usage", {})
    cost = u.get("input_tokens", 0)*PRICE_IN + u.get("output_tokens", 0)*PRICE_OUT
    total += cost
    rec = {"case_id": c["case_id"], "sent_at": t0.isoformat(), "received_at": t1.isoformat(), "http_status": status,
           "request_body": body, "response": resp, "est_cost_usd": round(cost, 6)}
    json.dump(rec, open(f"raw/case-{c['case_id']:02d}.json", "w"), indent=2)
    log.append({k: rec[k] for k in ("case_id", "sent_at", "http_status", "est_cost_usd")} | {"usage": u, "stop_reason": resp.get("stop_reason"), "model": resp.get("model")})
    print(c["case_id"], status, resp.get("model"), u.get("input_tokens"), u.get("output_tokens"), resp.get("stop_reason"), f"${total:.4f}", flush=True)
    if status != 200: print("ERROR, stopping"); break
    if total > CAP_USD: print("CAP reached, stopping"); break
    time.sleep(0.5)
json.dump({"model_requested": MODEL, "max_tokens": MAX_TOKENS, "price_in_per_mtok": 2.0, "price_out_per_mtok": 10.0, "calls": log, "total_est_cost_usd": round(total, 6)},
          open("run-log.json" if len(only) == 30 else f"run-log-partial-{'-'.join(map(str,only))}.json", "w"), indent=2)
