EXP-002 evidence: AI lead follow-up synthetic test
Article: https://whydoweneedai.com/blog/ai-lead-follow-up-test/
Package built 22 Oct 2026 (ET).

WHAT THIS IS
A synthetic test. One AI model (Anthropic claude-sonnet-5-5) was run once on each of
30 invented inquiries for an invented company, Hollow Creek Home Services, on
19 Oct 2026 between 08:36:49 and 08:41:04 ET. This is not a pilot or a case study.
No real customers were involved and no messages were sent. All names, emails
(example.com / example.net), and phone numbers (555-01xx) are made up. The card
number in case 30 is the standard public test number 4111 1111 1111 1111.

FOLDERS
original-evidence/   The files exactly as saved on 19 Oct 2026, unchanged.
  01-preregistration.md      Rubric, expected behavior, and reporting rules, written before the run
  01-preregistration.timestamp  Time (08:36:45 ET) plus SHA-256 of the pre-run files
  cases.json, build_cases.py 30 invented records with expected answers (stripped before sending)
  system_prompt.txt, prompt.md  Exact instructions and request shape
  run.py                     The API runner. Reads the key from the ANTHROPIC_API_KEY
                             environment variable. No key is stored anywhere in this package.
  raw/case-01..30.json       Exact request body (no headers), full API response, timestamps,
                             estimated cost
  run-log.json, run-console.txt  Per-call status, model, and usage. Total estimated cost $0.37407
  outputs.json               Parsed outputs
  checks.py -> checks.json   Regex screen
  build_scores.py -> scores.json  Original scorer's grades and corrected drafts
  tally.py -> 04-results.md  Original computed counts
  03-scores.timestamp        Time (08:43:26 ET) plus SHA-256 of outputs, scores, and all 30 raw files
  README.md                  Original evidence index
recheck-2026-10-22/
  integrity.py   Verifies hashes, HTTP status, model, timestamps, cost, request bodies,
                 and the case 30 quote, and scans for secrets.
                 Run: python3 integrity.py ../original-evidence
  recheck.py     The 22 Oct regrade of all 30 cases, with a reason and a verbatim quote for each,
                 plus independent recomputation of the headline numbers.
                 Run: python3 recheck.py ../original-evidence out.json
  recheck.json   Output of recheck.py

VERIFY IN TWO MINUTES (Python 3, standard library only)
  cd original-evidence
  tail -n +2 01-preregistration.timestamp | sha256sum -c
  tail -n +2 03-scores.timestamp | sha256sum -c
  # Reproduce the original scoring in a COPY of the folder (these scripts overwrite their outputs):
  python3 checks.py && python3 build_scores.py && python3 tally.py
  Do NOT run run.py unless you mean to. It makes new paid API calls with your own key and
  overwrites raw/.

KNOWN ISSUES AND LIMITS
- Case 30 was originally graded "major edit." Under the published rubric it is "wrong or unsafe"
  (an invented assurance in a customer draft). The article was corrected on 21 Oct.
  scores.json and 04-results.md still show the original grade, because they are kept unchanged
  as evidence.
- 04-results.md reports a median brief length of 152 words. tally.py took the 16th of 30 values.
  The standard median is 149.5 (the mean of 147 and 152). The article was corrected on 22 Oct.
- The scorer, the case writer, and the 22 Oct rechecker are the same AI writing assistant.
  The recheck is a consistency check, not independent verification.
- The hashes were self-recorded on the machine that ran the test. They show the files haven't
  changed since 19 Oct, but they are not third-party timestamps.
- The 14 "thinking" blocks in raw/ contain only an opaque signature. The model's reasoning
  text was not returned.
- One model, one run, one prompt, 30 invented cases. Counts, not rates.
