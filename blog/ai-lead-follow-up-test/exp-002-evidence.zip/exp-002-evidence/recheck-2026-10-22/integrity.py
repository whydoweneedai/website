"""EXP-002 integrity check. Read-only on the evidence folder. Standard library only.
Usage: python3 integrity.py [EVIDENCE_DIR]"""
import json, hashlib, os, re, sys, datetime, glob
E = sys.argv[1] if len(sys.argv) > 1 else "/workspace/wdwnai/lead-follow-up-synthetic-test/evidence"
os.chdir(E)
def sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()
ok_all = True
def report(name, ok, detail=""):
    global ok_all; ok_all &= ok
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" -- {detail}" if detail else ""))

# 1. Hash manifests
for man in ("01-preregistration.timestamp", "03-scores.timestamp"):
    lines = open(man).read().splitlines()
    print(f"\n{man}: recorded at '{lines[0]}'")
    bad = []
    n = 0
    for ln in lines[1:]:
        if not ln.strip(): continue
        h, p = ln.split(None, 1); n += 1
        got = sha(p) if os.path.exists(p) else "MISSING"
        if got != h: bad.append((p, h, got))
    report(f"{man}: {n} hashes match", not bad, str(bad) if bad else "")

# 2. Raw files
raws = sorted(glob.glob("raw/case-*.json"))
report("30 raw files present (case-01..case-30)", [os.path.basename(r) for r in raws] == [f"case-{i:02d}.json" for i in range(1, 31)], f"found {len(raws)}")
recs = [json.load(open(r)) for r in raws]
report("all HTTP 200", all(r["http_status"] == 200 for r in recs), str([r["http_status"] for r in recs if r["http_status"] != 200]))
models = {r["response"]["model"] for r in recs} | {r["request_body"]["model"] for r in recs}
report("model ID (request and response) = claude-sonnet-5-5", models == {"claude-sonnet-5-5"}, str(models))
report("stop_reason end_turn on all 30", all(r["response"]["stop_reason"] == "end_turn" for r in recs))
report("case_id in file matches filename", all(r["case_id"] == i + 1 for i, r in enumerate(recs)))
sent = [datetime.datetime.fromisoformat(r["sent_at"]) for r in recs]
recv = [datetime.datetime.fromisoformat(r["received_at"]) for r in recs]
first, last = min(sent), max(recv)
print(f"   first sent_at {first.isoformat()}  last received_at {last.isoformat()}")
lo = datetime.datetime.fromisoformat("2026-10-19T08:36:49-04:00"); hi = datetime.datetime.fromisoformat("2026-10-19T08:41:05-04:00")
report("timestamps within published window 08:36:49-08:41:04 ET, 2026-10-19", lo <= first and last < hi and all(a < b for a, b in zip(sent, recv)) and sent == sorted(sent))
prereg_t = datetime.datetime.strptime(open("01-preregistration.timestamp").readline().strip().replace(" EDT", ""), "%Y-%m-%d %H:%M:%S").replace(tzinfo=first.tzinfo)
report("pre-registration timestamp precedes first call", prereg_t < first, f"{prereg_t.time()} < {first.time()}")
# request body matches frozen system prompt and stripped case
SYSTEM = open("system_prompt.txt").read(); cases = {c["case_id"]: c for c in json.load(open("cases.json"))}
mism = []
for r in recs:
    b = r["request_body"]; c = cases[r["case_id"]]
    vis = {k: v for k, v in c.items() if k not in ("expected", "category")}
    exp_user = "Inquiry record:\n" + json.dumps(vis, indent=2)
    if b["system"] != SYSTEM or b["messages"] != [{"role": "user", "content": exp_user}] or b["max_tokens"] != 4000 or set(b) != {"model", "max_tokens", "system", "messages"}:
        mism.append(r["case_id"])
report("every request body = frozen system prompt + case minus category/expected, max_tokens 4000, no other params", not mism, str(mism))
# 3. Cost
summed = sum(r["est_cost_usd"] for r in recs)
log = json.load(open("run-log.json"))
recomputed = sum(r["response"]["usage"]["input_tokens"] * 2e-6 + r["response"]["usage"]["output_tokens"] * 1e-5 for r in recs)
print(f"   sum(raw est_cost_usd) = {summed:.6f}; recomputed from usage = {recomputed:.6f}; run-log total = {log['total_est_cost_usd']}")
report("summed est_cost matches run-log $0.37407", round(summed, 5) == 0.37407 and log["total_est_cost_usd"] == 0.37407)
report("run-log per-call entries match raw files", [ (c["case_id"], c["http_status"], c["est_cost_usd"], c["model"]) for c in log["calls"]] == [(r["case_id"], r["http_status"], r["est_cost_usd"], r["response"]["model"]) for r in recs])
# outputs.json consistency
outs = {o["case_id"]: o for o in json.load(open("outputs.json"))}
def final_json(r):
    t = [b["text"] for b in r["response"]["content"] if b["type"] == "text"][-1]
    return json.loads(t)
report("outputs.json parsed outputs equal JSON parsed from raw responses (30/30)", all(outs[r["case_id"]]["output"] == final_json(r) for r in recs))
# 4. Case 30 quote
t30 = [b["text"] for b in recs[29]["response"]["content"] if b["type"] == "text"][-1]
q = "We won't use the card information in your message, and we'll sort out any payment details with you directly later on."
report("case 30 raw response contains the quoted sentence verbatim", q in t30)
report("case 30 parsed draft_message contains the quoted sentence", q in final_json(recs[29])["draft_message"])
# 5. Secret scan across ALL files in the evidence folder
pat = re.compile(r"sk-ant[-_A-Za-z0-9]*|x-api-key\s*[\"':=]\s*[\"']?[A-Za-z0-9_-]{8,}|authorization\s*[\"':=]|bearer\s+[A-Za-z0-9._-]{10,}|api[_-]?key\s*[\"':=]\s*[\"'][A-Za-z0-9_-]{8,}|ANTHROPIC_API_KEY\s*=|AKIA[0-9A-Z]{16}|ghp_[A-Za-z0-9]{20,}|xox[bp]-|-----BEGIN", re.I)
hits = []; files = sorted(p for p in glob.glob("**/*", recursive=True) if os.path.isfile(p))
for p in files:
    s = open(p, encoding="utf-8", errors="replace").read()
    for m in pat.finditer(s): hits.append((p, m.group(0)))
lit = [(p, w) for p in files for w in ("sk-ant", "x-api-key", "Authorization", "Bearer") if w.lower() in open(p, encoding="utf-8", errors="replace").read().lower()]
print(f"   scanned {len(files)} files; literal mentions of sk-ant/x-api-key/Authorization/Bearer (any case): {lit}")
report("no secret values (keys/tokens/auth headers) in any evidence file", not hits, str(hits))
# 6. Personal-data scan
emails = set(); phones = set(); doms = set()
for p in files:
    s = open(p, encoding="utf-8", errors="replace").read()
    for m in re.finditer(r"[A-Za-z0-9._%+-]+@([A-Za-z0-9.-]+\.[A-Za-z]{2,})", s): emails.add(m.group(0)); doms.add(m.group(1).lower())
    for m in re.finditer(r"(?<![\d.])(?:\(?\d{3}\)?[ .-]?)?\d{3}[ .-]\d{4}(?!\d)", s): phones.add(m.group(0))
nonfict_dom = {d for d in doms if not re.search(r"(^|\.)example\.(com|net|org)$", d)}
nonfict_ph = {p for p in phones if not re.search(r"555", p)}
print(f"   email domains: {sorted(doms)}")
print(f"   distinct phone-like strings: {len(phones)}; non-555: {sorted(nonfict_ph)}")
report("all email addresses use example.com/.net domains", not nonfict_dom, str(nonfict_dom))
report("all phone-like numbers are 555 fictional numbers", not nonfict_ph, str(nonfict_ph))
cards = {m.group(0) for p in files for m in re.finditer(r"\b(?:\d[ -]?){13,19}\b", open(p, encoding='utf-8', errors='replace').read()) if len(re.sub(r'\D','',m.group(0)))>=13}
print(f"   13-19 digit card-like strings: {sorted(cards)}")
report("only card-like number is the public test number 4111 1111 1111 1111", all(re.sub(r'\D','',c) == "4111111111111111" for c in cards), str(cards))
# run.py key handling
runpy = open("run.py").read()
report("run.py reads key only via os.environ['ANTHROPIC_API_KEY'] and contains no literal key", 'os.environ["ANTHROPIC_API_KEY"]' in runpy and "sk-" not in runpy)
print("\nOVERALL:", "PASS" if ok_all else "FAIL")
