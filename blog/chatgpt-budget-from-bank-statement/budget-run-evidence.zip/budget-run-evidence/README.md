# Evidence: "Turn last month's bank statement into a budget" test run

This is a single ChatGPT run done signed out on Nov 4 2026 at about 11:11 AM ET. The bank statement is **made up**: every merchant, amount and date is fictional.

| File | What it is |
|---|---|
| `input.txt` | The made-up October statement: 35 transactions. The `#` lines are labels and were not sent. |
| `paste.txt` | Exactly what was sent to ChatGPT in one message: the CSV lines, then the guide's prompt. |
| `prompt-verbatim.txt` | The prompt alone, as printed in the guide. |
| `output.txt` | ChatGPT's full reply, copied verbatim (402 lines). It includes some page labels and LaTeX math markup. |
| `expected.md` | The answer key, worked out from `input.txt` by `reconcile.py` in integer cents. It doesn't use the reply. |
| `reconcile.py` | Checking script (Python 3, standard library only). Run `python3 reconcile.py output.txt`. |
| `reconcile-report.md` | The script's report. `reconcile-report-v1.md` is the first pass, before a fix to the budget-table parser (explained in `reconciliation.md`). |
| `reconciliation.md` | The line-by-line comparison and verdict. |
| `run-record.md` | When, where and how the run was done, and what the page showed. |
| `screenshots/` | `01.png` is the message before sending. `02.png`–`14.png` show the thread top to bottom. There is a small gap between 04 and 05, mid-chart. The browser bar (with the chat's address) is cropped off 02–14, and an ad below the reply is cropped off 14. The reply itself is not cropped. |
| `fingerprints.sha256` | SHA-256 of every file above. Check with `sha256sum -c fingerprints.sha256`. |
