#!/usr/bin/env python3
"""Independent ground truth for the budget-guide run, and a checker for ChatGPT's saved output.

Usage:
  python3 reconcile.py                      # print ground truth, write expected.md
  python3 reconcile.py output.txt           # also check ChatGPT's saved output, write reconcile-report.md

input.txt is SYNTHETIC (see its header). output.txt must be ChatGPT's full reply, saved as plain text
(copy the reply, or transcribe it from screenshots). The checker uses heuristics, and a person
still reads every figure before anything is quoted. Its job is to make that review fast and complete:
  * category totals vs. truth (allowing the reasonable alternate categories listed in ALT)
  * the totals line (income, spending with or without savings transfers)
  * the shares (percent) against both denominators
  * the flags (duplicate, fees, the trial conversion)
  * the November budget: rows sum to income, a holiday-gifts line exists, savings >= October's
  * every dollar figure in the output that can't be traced to the statement or a derived total
Standard library only. Money is handled in integer cents.
"""
import re, sys, itertools, pathlib
from collections import defaultdict

HERE = pathlib.Path(__file__).resolve().parent
CATS = ["housing", "groceries", "eating out", "transportation", "utilities and phone", "subscriptions",
        "debt payments", "savings", "shopping", "health", "fees", "other"]

# Primary category per description (our call, written down before any run), plus defensible alternates.
PRIMARY = {
    "RENT - MAPLE COURT APTS": "housing",
    "TRANSFER TO SAVINGS": "savings",
    "GREENLEAF MARKET": "groceries",
    "QUIKFUEL 4512": "transportation",
    "STREAMFLIX MONTHLY": "subscriptions",
    "CORNER BISTRO": "eating out",
    "CITY POWER & LIGHT": "utilities and phone",
    "METRO WIRELESS": "utilities and phone",
    "AUTO LOAN PMT - LAKESIDE CU": "debt payments",
    "BEAN THERE CAFE": "eating out",
    "PHARMACARE #220": "health",
    "TUNEBOX MUSIC": "subscriptions",
    "CLOUDVAULT STORAGE": "subscriptions",
    "RIDEGO TRIP": "transportation",
    "PINEWOOD HOME SUPPLY": "shopping",
    "SUNRISE NOODLE HOUSE": "eating out",
    "CREDIT CARD PMT - SUMMIT CARD": "debt payments",
    "CITY WATER UTILITY": "utilities and phone",
    "BRIGHTSMILE DENTAL": "health",
    "PAGETURN BOOKS": "shopping",
    "FRESHPRINT NEWS ANNUAL TRIAL CONVERSION": "subscriptions",
    "MONTHLY MAINTENANCE FEE": "fees",
    "OUT-OF-NETWORK ATM FEE": "fees",
    "ATM WITHDRAWAL": "other",
    "TACO LOCO": "eating out",
    "CITY PARKING METER": "transportation",
    "HOME INTERNET - FIBERLINK": "utilities and phone",
}
ALT = {  # other categories a careful reader would also accept (kept narrow on purpose)
    "FRESHPRINT NEWS ANNUAL TRIAL CONVERSION": ["other"],
    "PINEWOOD HOME SUPPLY": ["other"],
    "PAGETURN BOOKS": ["other"],
}
FLAGS = {  # (what the prompt's step 3 should catch, description, must appear near one of these words)
    "duplicate": ("BEAN THERE CAFE", ["duplicate", "twice", "identical", "double"]),
    "maintenance fee": ("MONTHLY MAINTENANCE FEE", ["fee"]),
    "ATM fee": ("OUT-OF-NETWORK ATM FEE", ["fee"]),
    "trial conversion": ("FRESHPRINT NEWS ANNUAL TRIAL CONVERSION", ["trial", "annual", "unexpected", "convert"]),
}
GIFT_WORDS = ["gift", "holiday"]

def cents(s):
    return int(round(float(s.replace(",", "").replace("$", "")) * 100))

def fmt(c):
    sign = "-" if c < 0 else ""
    return f"{sign}${abs(c)/100:,.2f}"

def load_input():
    rows = []
    for line in (HERE / "input.txt").read_text().splitlines():
        if not line.strip() or line.startswith("#") or line.startswith("Date,"):
            continue
        parts = line.split(",")
        d, amt, desc = parts[0], parts[-1], ",".join(parts[1:-1])
        rows.append((d, desc, cents(amt)))
    return rows

def truth(rows):
    t = {}
    t["n"] = len(rows)
    t["income"] = sum(a for _, _, a in rows if a > 0)
    out = [(d, s, -a) for d, s, a in rows if a < 0]
    t["out"] = out
    t["outflows"] = sum(a for *_, a in out)
    t["savings"] = sum(a for _, s, a in out if PRIMARY[s] == "savings")
    t["spend_ex_savings"] = t["outflows"] - t["savings"]
    cat = defaultdict(int)
    for _, s, a in out:
        cat[PRIMARY[s]] += a
    t["cat"] = {c: cat.get(c, 0) for c in CATS}
    assert sum(t["cat"].values()) == t["outflows"]
    t["net"] = t["income"] - t["outflows"]
    return t

def cat_options(t, c):
    """Every total a category could defensibly have, given ALT moves of individual merchants."""
    base = t["cat"][c]
    moves = []  # (amount delta options) per merchant that could move in or out of c
    by_desc = defaultdict(int)
    for _, s, a in t["out"]:
        by_desc[s] += a
    for s, alts in ALT.items():
        amt = by_desc.get(s, 0)
        if PRIMARY[s] == c:
            moves.append((0, -amt))
        elif c in alts:
            moves.append((0, amt))
    opts = set()
    for combo in itertools.product(*moves) if moves else [()]:
        opts.add(base + sum(combo))
    return sorted(opts)

def write_expected(t, rows):
    L = []
    L.append("# Expected results (ground truth) for the budget-guide run\n")
    L.append("Generated by `reconcile.py` from `input.txt` (SYNTHETIC data, 35 transactions). It was computed independently of any chatbot output: the script never reads output.txt to build it.\n")
    L.append(f"- Transactions: **{t['n']}** (2 deposits, {len(t['out'])} outflows)")
    L.append(f"- Income: **{fmt(t['income'])}**")
    L.append(f"- All money out, including savings transfers: **{fmt(t['outflows'])}**")
    L.append(f"- Savings transfers: **{fmt(t['savings'])}** (Oct 3 $300.00 + Oct 30 $200.00)")
    L.append(f"- Money out excluding savings transfers: **{fmt(t['spend_ex_savings'])}**")
    L.append(f"- Income minus all money out: **{fmt(t['net'])}**\n")
    L.append("ChatGPT may or may not count savings transfers as \"spending\". Either total is correct if it says which one it used.\n")
    L.append("## Category totals (our primary categorization)\n")
    L.append("| Category | Total | Share of all money out | Share excl. savings | Also acceptable totals* |")
    L.append("|---|---:|---:|---:|---|")
    for c in CATS:
        v = t["cat"][c]
        s1 = 100 * v / t["outflows"]
        s2 = "n/a" if c == "savings" else f"{100 * v / t['spend_ex_savings']:.1f}%"
        alts = [fmt(o) for o in cat_options(t, c) if o != v]
        L.append(f"| {c} | {fmt(v)} | {s1:.1f}% | {s2} | {', '.join(alts) or '—'} |")
    L.append(f"| **Total** | **{fmt(t['outflows'])}** | 100% | | |\n")
    L.append("*If one of these merchants is placed in a reasonable alternate category: " +
             "; ".join(f"{k} → {', '.join(v)}" for k, v in ALT.items()) + ".\n")
    L.append("## Line-by-line categorization\n")
    L.append("| Date | Description | Amount | Category |")
    L.append("|---|---|---:|---|")
    for d, s, a in rows:
        L.append(f"| {d} | {s} | {fmt(a)} | {'income' if a > 0 else PRIMARY[s]} |")
    L.append("\n## What step 2 should list (recurring charges and subscriptions)\n")
    L.append("These are clearly subscriptions: STREAMFLIX MONTHLY $15.49 (Oct 5), TUNEBOX MUSIC $10.99 (Oct 13), CLOUDVAULT STORAGE $2.99 (Oct 14), FRESHPRINT NEWS ANNUAL TRIAL CONVERSION $79.00 (Oct 26, an annual charge, not monthly).")
    L.append("These are likely monthly bills: RENT $1,450.00 (Oct 1), CITY POWER & LIGHT $96.40 (Oct 7), METRO WIRELESS $65.00 (Oct 8), AUTO LOAN $289.00 (Oct 10), CREDIT CARD PMT $150.00 (Oct 20), CITY WATER UTILITY $42.18 (Oct 21), HOME INTERNET $55.00 (Oct 31), MONTHLY MAINTENANCE FEE $12.00 (Oct 27). There are also two savings transfers.")
    L.append("Judgment: one month of data can't prove anything recurs. Any reasonable list is fine, as long as the amounts and dates match the statement.\n")
    L.append("## What step 3 should flag\n")
    L.append("- Possible duplicate: BEAN THERE CAFE, $5.85 twice on Oct 11.")
    L.append("- Fees: MONTHLY MAINTENANCE FEE $12.00 (Oct 27); OUT-OF-NETWORK ATM FEE $3.50 (Oct 27). Total $15.50.")
    L.append("- Unexpected charge: FRESHPRINT NEWS ANNUAL TRIAL CONVERSION $79.00 (Oct 26).\n")
    L.append("## Constraints for the November budget (step 4)\n")
    L.append(f"- It's built on actual income: rows should sum to **{fmt(t['income'])}** (or it should state the surplus or shortfall explicitly).")
    L.append("- It includes a holiday-gifts line.")
    L.append(f"- Savings are at least October's **{fmt(t['savings'])}**.")
    (HERE / "expected.md").write_text("\n".join(L) + "\n")

AMT = re.compile(r"(?<![\w.])-?\$?\s?(\d{1,3}(?:,\d{3})+|\d+)(\.\d{2})?(?!\d)")

def money_in(line):
    """Dollar-like amounts in a line, in cents. Requires a $ or two decimals, to skip dates and counts."""
    found = []
    for m in re.finditer(r"\$\s?(\d{1,3}(?:,\d{3})+|\d+)(\.\d{1,2})?|(?<![\d/.-])(\d{1,3}(?:,\d{3})+|\d+)\.(\d{2})(?![\d%])", line):
        if m.group(1):
            found.append(cents(m.group(1) + (m.group(2) or "")))
        else:
            found.append(cents(m.group(3) + "." + m.group(4)))
    return found

def check_output(t, rows, path):
    text = pathlib.Path(path).read_text()
    lines = text.splitlines()
    low = [l.lower() for l in lines]
    R = ["# Reconcile report: ChatGPT output vs. ground truth\n",
         f"Output file: `{path}`. Ground truth: `expected.md`. ✅ = matches, ❌ = mismatch, ⚠️ = needs a human look.\n"]
    # 1. headline totals
    R.append("## 1. Totals")
    allamts = [a for l in lines for a in money_in(l)]
    for label, v in [("income", t["income"]), ("all money out", t["outflows"]),
                     ("money out excl. savings", t["spend_ex_savings"]), ("income minus money out", t["net"])]:
        R.append(f"- {'✅' if v in allamts else '⚠️ not found'} {label} {fmt(v)}")
    for i, l in enumerate(low):
        if "total" in l and ("spend" in l or "income" in l or "outflow" in l or "expense" in l):
            vals = money_in(lines[i])
            ok = all(v in (t["income"], t["outflows"], t["spend_ex_savings"], t["net"]) for v in vals)
            if vals:
                R.append(f"  - {'✅' if ok else '❌'} line {i+1}: `{lines[i].strip()[:160]}`")
    # 2. category table
    R.append("\n## 2. Category totals")
    for c in CATS:
        key = c.split(" and ")[0] if c != "utilities and phone" else "utilities"
        hits = [(i, money_in(lines[i])) for i, l in enumerate(low)
                if re.search(r"\b" + re.escape(key) + r"\b", l) and money_in(lines[i])]
        if not hits:
            R.append(f"- ⚠️ {c}: no line with this category and an amount")
            continue
        i, vals = hits[0]
        opts = cat_options(t, c)
        good = [v for v in vals if v in opts]
        R.append(f"- {'✅' if good else '❌'} {c}: output {', '.join(fmt(v) for v in vals)} | truth {fmt(t['cat'][c])}"
                 + (f" (also ok: {', '.join(fmt(o) for o in opts if o != t['cat'][c])})" if len(opts) > 1 else "")
                 + f" | line {i+1}")
        pct = re.findall(r"(\d+(?:\.\d+)?)\s?%", lines[i])
        if pct:
            p = float(pct[0]); v = good[0] if good else vals[0]
            s1 = 100 * v / t["outflows"]; s2 = 100 * v / t["spend_ex_savings"]
            ok = abs(p - s1) <= 0.15 or abs(p - s2) <= 0.15
            R.append(f"  - {'✅' if ok else '❌'} share {p}% (truth {s1:.1f}% of all out, {s2:.1f}% excl. savings)")
    # 3. flags
    R.append("\n## 3. Flags (step 3)")
    for name, (desc, words) in FLAGS.items():
        stem = desc.split()[0].lower()
        idx = [i for i, l in enumerate(low) if stem in l]
        near = any(any(w in " ".join(low[max(0, i-2):i+3]) for w in words) for i in idx)
        R.append(f"- {'✅' if near else '⚠️'} {name}: {desc} {'mentioned with a flag word' if near else 'not clearly flagged'}")
    # 4. budget
    R.append("\n## 4. November budget (step 4)")
    start = max([i for i, l in enumerate(low) if "november" in l] or [-1])
    first_nov = min([i for i, l in enumerate(low) if "november" in l and "budget" in l] or [start])
    if first_nov < 0:
        R.append("- ⚠️ no November section found")
    else:
        brows, total_rows = [], []
        # Prefer the spreadsheet-ready block (``` fenced, tab or comma separated) if the reply has one;
        # otherwise read markdown table rows and take the LAST amount (the November column).
        fence = [i for i in range(first_nov, len(lines)) if lines[i].strip().startswith("```")]
        scan = range(fence[0] + 1, fence[1]) if len(fence) >= 2 else [i for i in range(first_nov, len(lines)) if lines[i].lstrip().startswith("|")]
        R.append(f"- Parsed from: {'fenced spreadsheet block, lines ' + str(fence[0]+2) + '-' + str(fence[1]) if len(fence) >= 2 else 'markdown table rows (last amount per row)'}")
        for i in scan:
            l = lines[i]
            vals = money_in(l)
            if not vals and "\t" in l:
                tail = l.split("\t")[-1].strip().replace(",", "")
                vals = [cents(tail)] if re.fullmatch(r"\d+(\.\d{1,2})?", tail) else []
            if not vals or not ("|" in l or "," in l or "\t" in l or ":" in l):
                continue
            label = re.split(r"[|,\t:]", l.strip().strip("|"))[0].strip().lower()
            if not label or re.match(r"^[-\s]+$", label):
                continue
            (total_rows if "total" in label or "income" in label or "remaining" in label or "left" in label else brows).append((i, label, vals[-1]))
        seen, uniq = set(), []
        for i, lab, v in brows:  # the same table may appear twice (markdown and CSV); keep first by label
            if lab in seen: continue
            seen.add(lab); uniq.append((i, lab, v))
        s = sum(v for _, _, v in uniq)
        R.append(f"- Budget rows found ({len(uniq)}): " + "; ".join(f"{lab} {fmt(v)}" for _, lab, v in uniq))
        R.append(f"- {'✅' if s == t['income'] else '⚠️'} rows sum to {fmt(s)} vs income {fmt(t['income'])} (check by hand; a parsing miss shows up here)")
        for i, lab, v in total_rows:
            R.append(f"  - stated '{lab}' {fmt(v)} (line {i+1})")
        gift = [(lab, v) for _, lab, v in uniq if any(w in lab for w in GIFT_WORDS)]
        R.append(f"- {'✅' if gift else '❌'} holiday-gifts line: {', '.join(f'{l} {fmt(v)}' for l, v in gift) or 'missing'}")
        sav = [v for _, lab, v in uniq if "saving" in lab]
        R.append(f"- {'✅' if sav and sum(sav) >= t['savings'] else '❌'} savings {fmt(sum(sav)) if sav else 'missing'} vs October {fmt(t['savings'])}")
    # 5. untraceable figures
    R.append("\n## 5. Dollar figures we can't trace")
    known = {a for *_, a in t["out"]} | {t["income"], t["outflows"], t["spend_ex_savings"], t["net"], t["savings"], 237500}
    for c in CATS:
        known.update(cat_options(t, c))
    known.update({1550, 1170})  # fees total; duplicate pair
    budget_lines = set(range(first_nov, len(lines))) if first_nov >= 0 else set()
    for i, l in enumerate(lines):
        for v in money_in(l):
            if v not in known and i not in budget_lines:
                R.append(f"- ⚠️ line {i+1}: {fmt(v)} in `{l.strip()[:140]}`")
    R.append("\nBudget-section figures are proposals, not statement facts, so section 5 skips them. Read them by hand.")
    (HERE / "reconcile-report.md").write_text("\n".join(R) + "\n")
    print("\n".join(R))

if __name__ == "__main__":
    rows = load_input()
    t = truth(rows)
    assert t["n"] == 35, t["n"]
    write_expected(t, rows)
    print(f"transactions {t['n']}  income {fmt(t['income'])}  out {fmt(t['outflows'])}  "
          f"excl savings {fmt(t['spend_ex_savings'])}  net {fmt(t['net'])}")
    for c in CATS:
        print(f"  {c:20s} {fmt(t['cat'][c]):>10s}")
    print("wrote expected.md")
    if len(sys.argv) > 1:
        check_output(t, rows, sys.argv[1])
