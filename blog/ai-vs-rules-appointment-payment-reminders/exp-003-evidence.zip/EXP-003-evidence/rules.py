"""EXP-003 rules baseline: fixed templates + explicit if/then rules implementing the same written policy the AI gets (prompt.md).
Written 2026-10-23 before any AI output was seen. Reads records.json only (never expected.json). Writes evidence/rules-outputs.json.
Design choice (stated up front): a simple rules script can't read free text, so ANY customer_note or staff_note routes the record to a person,
with the note copied into the staff note."""
import json, datetime
BIZ = {"Lakeside Wellness Studio": {"phone": "(555) 010-3300"}, "Ridgeway Landscaping": {"phone": "(555) 010-7700"}}

def fmt_date(iso):
    d = datetime.date.fromisoformat(iso); return f"{d:%A}, {d:%B} {d.day}"

def channel(r):
    if r.get("consent_to_text") and r.get("phone"): return "text"
    if r.get("email"): return "email"
    return None

def out(decision, ch=None, msg=None, staff=None, reason=""):
    return {"decision": decision, "channel": ch, "message": msg, "staff_note": staff, "reason": reason}

def appointment(r):
    if r["booking_status"] != "booked": return out("hold", reason=f"booking_status is {r['booking_status']}")
    if r.get("customer_note") or r.get("staff_note"):
        return out("route_to_person", staff=f"Note on record, needs a person: {r.get('customer_note') or r.get('staff_note')}", reason="record has a free-text note")
    appts = r["appointments"]
    if any(not a.get("date") or not a.get("time") for a in appts): return out("route_to_person", staff="Appointment date or time missing.", reason="missing date/time")
    ch = channel(r)
    if not ch: return out("route_to_person", staff="No usable phone or email.", reason="no channel")
    when = "today" if r["reminder_type"] == "same_day" else "tomorrow"
    def label(a): return "your appointment" if a["service_sensitive"] else f"your {a['service'].split(' (')[0].lower()} appointment"
    if len(appts) == 1:
        a = appts[0]
        body = f"Hi {r['customer_first_name']}, this is a reminder of {label(a)} {when}, {fmt_date(a['date'])}, at {a['time']} ET."
    else:
        parts = [f"{label(a).replace('your ', '')} at {a['time']} ET" for a in appts]
        body = f"Hi {r['customer_first_name']}, a reminder of your appointments {when}, {fmt_date(appts[0]['date'])}: " + " and ".join(parts) + "."
    if any(a["format"] == "video" for a in appts):
        body += " Join by video: " + " ".join(a["video_link"] for a in appts if a["video_link"])
    else:
        body += " We're at 214 Elm Street."
    if r.get("prep_instructions"): body += " " + r["prep_instructions"]
    if r.get("no_show_count", 0) >= 2: body += " Please reply C to confirm or R to reschedule."
    body += f" Questions? Call {BIZ[r['business']]['phone']}. - Lakeside Wellness Studio"
    return out("send", ch, body, reason=f"booked, {r['reminder_type']} reminder")

def invoice(r):
    if r["invoice_status"] == "paid": return out("hold", reason="invoice paid")
    if r["invoice_status"] == "disputed": return out("route_to_person", staff="Invoice is disputed.", reason="disputed")
    if r.get("customer_note") or r.get("staff_note"):
        return out("route_to_person", staff=f"Note on record, needs a person: {r.get('customer_note') or r.get('staff_note')}", reason="record has a free-text note")
    bal = float(r["balance_due"].replace("$", "").replace(",", ""))
    if bal >= 5000 and r["days_overdue"] >= 30: return out("route_to_person", staff="Large balance 30+ days overdue: owner to call.", reason="large overdue balance")
    ch = channel(r)
    if not ch: return out("route_to_person", staff="No usable phone or email.", reason="no channel")
    n, name = r["invoice_number"], r["customer_first_name"]
    if r.get("payment_plan"):
        p = r["payment_plan"]
        body = f"Hi {name}, a reminder that your next payment-plan installment of {p['installment_amount']} for invoice #{n} is due {fmt_date(p['next_installment_due'])}."
    elif r["days_overdue"] <= 0:
        body = f"Hi {name}, a friendly reminder that invoice #{n} for {r['balance_due']} is due {fmt_date(r['due_date'])}."
    else:
        body = f"Hi {name}, our records show invoice #{n} has a balance of {r['balance_due']}, which was due {fmt_date(r['due_date'])}."
        if r.get("late_fee_terms") and r["days_overdue"] >= 30 and r.get("late_fee_amount"):
            body += f" Per your terms, a late fee of {r['late_fee_amount']} applies."
    if r.get("pay_link"): body += f" Pay or view the invoice here: {r['pay_link']}"
    else: body += f" To pay, please call our office at {BIZ[r['business']]['phone']}."
    body += " - Ridgeway Landscaping"
    return out("send", ch, body, reason="invoice reminder")

if __name__ == "__main__":
    recs = json.load(open("records.json"))
    res = [{"record_id": r["record_id"], "method": "rules", "output": appointment(r) if r["record_type"] == "appointment_reminder" else invoice(r)} for r in recs]
    json.dump(res, open("evidence/rules-outputs.json", "w"), indent=2, ensure_ascii=False)
    for x in res: print(x["record_id"], x["output"]["decision"], x["output"]["channel"], (x["output"]["message"] or "")[:200])
