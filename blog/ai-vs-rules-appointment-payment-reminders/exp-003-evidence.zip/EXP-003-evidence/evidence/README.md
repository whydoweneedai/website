# EXP-003 evidence: AI vs. simple rules for appointment and payment reminders (SYNTHETIC TEST)

All 30 records are invented: "Lakeside Wellness Studio" and "Ridgeway Landscaping", 555-01xx phone numbers, example.* domains. This was not a live pilot, and no message was sent to anyone. Everything ran on Fri 23 Oct 2026, between 17:17 and 17:22 ET. Model requested and returned: `claude-sonnet-5-5`. No API key appears in any file: request bodies were saved without headers.

## Spot-check in 3 steps
1. `cd ..; sha256sum -c fingerprints.sha256` should show 6 of the 8 pre-run files as OK. `design.md` and `prompt.md` now FAIL on purpose: each got a dated post-run note (deviations D5 and D6). Their byte-identical originals are in `evidence/prerun-originals/`; check them with `sha256sum evidence/prerun-originals/*` and compare with the manifest. Then compare the manifest time (17:17:19 EDT) with the first call's `sent_at` in `run-log.json` (17:17:27 EDT).
2. `cd ..; python3 score_mechanical.py` regenerates `evidence/scores-mechanical.json` from the raw outputs. Then run `python3 evidence/tally.py` (from either folder) to rebuild `results.md`. Note: this overwrites the hand-written note at the end of results.md, so copy that note first.
3. Pick any `raw/<case>-run<n>.json`. Use the first content block whose `type` is `"text"`, not simply `content[0]`: 25 of the 90 raw files start with a `"thinking"` block (see deviation D6). Check that block's `text` matches the row in `ai-outputs.json` and the per-case table in `results.md`.

## Files
| File | What it is | When written |
|---|---|---|
| `../design.md` | Original design plus Ollie's-changes addendum: rubrics, decision rule. Status line updated after the run (D5) | before run, fingerprinted; status line edited after run |
| `../prompt.md` | Exact system prompt and user template sent to the model, plus a post-run note on thinking blocks (D6) appended below a rule | before run, fingerprinted; note appended after run |
| `prerun-originals/` | Byte-identical pre-run copies of design.md and prompt.md; they match fingerprints.sha256 | copied after run, contents from before run |
| `../records.json`, `../expected.json`, `../build_records.py` | The 30 synthetic records, the expected fields locked before the run, and the script that builds both. The model never saw expected.json. | before run, fingerprinted |
| `../rules.py` | Rules baseline: templates + if/then; routes any record with a free-text note | before run, fingerprinted |
| `../score_mechanical.py` | Locked mechanical scorer (no judgment) | before run, fingerprinted |
| `run.py` | API runner: 3 runs × 30 records, saves raw request/response | before run, fingerprinted |
| `../fingerprints.sha256` | sha256 manifest, 2026-10-23 17:17:19 EDT | before run |
| `rules-run.txt`, `rules-outputs.json` | The rules script's single run (17:17:23 EDT) | run |
| `raw/` (90 files) | Per-call request body + full API response + timestamps + HTTP status + token-based cost | run |
| `ai-outputs.json`, `run-log.json`, `run-console.txt` | AI outputs (raw text), per-call log, console | run |
| `scores-mechanical.json` | Locked scorer output, **primary** | after run |
| `../score_mechanical_v2.py`, `scores-mechanical-v2.json` | Deviation D2 scorer and output (business-hours weekday names allowed) | after run |
| `scores-judgment.json` | **JUDGMENT** scores (tone and notes) and findings by the site's AI assistant; not blind; no human re-score | after run |
| `tally.py` | Adds up the numbers only, no scoring; builds results files | after run |
| `results.md` | Primary results: run facts, cost math, totals, per-category, per-case table, judgment section, hand-written note | after run |
| `results-v2-deviation.md` | Same tables using the v2 scorer | after run |
| `../deviations.md` | D1 to D7, and the decision rule applied under both scorers | after run |
| `../fingerprints-postrun.sha256` | sha256 of every post-run file, with timestamp | after run |

## Post-run fingerprints

`fingerprints-postrun.sha256` (regenerated 2026-10-23 17:41:20 EDT) covers the outputs, scores, results, deviation files, the 90 raw files, the post-run design.md and prompt.md, and the two pre-run originals. Its first line is a comment, so check it with:

    grep -v '^#' fingerprints-postrun.sha256 | sha256sum -c
