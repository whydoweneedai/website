# EXP-003 test design (DRAFT, not run): AI vs. simple rules for appointment and payment reminders
Status: proposed, awaiting Ollie's sign-off. Nothing has been run.
Reader question: For appointment and payment reminders, should a small-business owner use AI, plain rule-based automation, or neither?

## What we compare
- Rules (baseline): a short Python script of fixed templates with merge fields (name, date, time, amount, due date, pay link) and explicit if/then rules (e.g. "already paid" -> don't send; "disputed" -> route to a person; missing field -> route to a person). Written before any AI output is seen.
- AI: Claude via the Anthropic API (same setup as EXP-002, claude-sonnet-5-5, model/version and date recorded), given the same record plus a short business policy, asked to write the reminder or say it should go to a person.
- "Neither / built-in": not tested. If mentioned in the article it's cited to vendor docs as a vendor claim (e.g. booking or invoicing tools with built-in reminders).
- I can run both myself with the existing API key; no Wally setup needed.

## Scenarios (synthetic, clearly labeled; ~30 records)
Appointment (15): standard reminder; 24h vs same-day; reschedule already made; cancelled booking; missing time or phone; customer note in free text ("running late, can we push 30 min?"); prep instructions; sensitive service (health/legal) where detail shouldn't be in the message; two bookings same day; time-zone mismatch; repeat no-show.
Payment (15): first friendly reminder; 30 days overdue; partial payment; already paid (shouldn't send); disputed invoice; payment plan in place; customer note about hardship; large balance; wrong amount in record vs. note; no pay link on file; late-fee policy present vs. absent.

## What we measure (per message, scored against a rubric)
1. Facts correct: name, date, time, amount, due date match the record exactly. Any invented or wrong fact = fail for that case.
2. Stop rules: sends nothing / routes to a person when it should (paid, disputed, cancelled, missing data, hardship).
3. No invented content: no discounts, fee waivers, late fees, threats, or promises not in the policy.
4. Handles free-text notes sensibly (the case where AI might actually add value).
5. Tone and length usable as-is (light-touch, secondary).
6. Consistency: AI run 3 times on each record; count cases where outputs disagree on facts or send/hold decision.
7. Observed API cost for the run (actual bill, not projected savings). Setup effort described, not converted to time savings.

## Pass/fail and decision rule (pre-registered with sha256 before scoring)
- A method "passes" a case only if facts are correct, the send/hold decision is right, and nothing is invented.
- Any wrong date or amount is a serious failure regardless of tone.
- Recommendation rule: if rules pass the standard cases and AI makes any factual or send/hold error there, the article recommends rules for standard reminders. AI is recommended only for the cases where it clearly outperforms rules (likely free-text notes), and only with a human check if it ever got a fact wrong. If AI shows no clear advantage anywhere, the article says so.
- Expectations for each case are written and fingerprinted before scoring; results that contradict the planned angle change the recommendation.

## Limits to state in the article
Synthetic records, one model, one rules script, scored by the site's AI assistant against a fixed rubric (consistency check, not independent verification unless Ross or a human spot-checks). Not a live pilot or case study. No SMS/email actually sent; texting-consent rules (TCPA) cited, not tested.

---
## Addendum: Ollie's changes (written Fri 23 Oct 2026, ~17:20 ET, BEFORE any test call; the text above is unchanged)
Ollie approved the design ("Go. Your design holds up.") with three changes. This is how they're implemented. All files named here are fingerprinted in `fingerprints.sha256` before the first API call. If any must change afterward, the change is logged as a dated deviation in `deviations.md` and re-fingerprinted. It won't be edited silently.

**1. Mechanical scoring for facts and decisions.** `score_mechanical.py` scores every output (rules and AI) against `expected.json`. Rules outputs are turned into JSON text and go through the same parser. No judgment is involved in:
- decision (send / hold / route_to_person, compared with each case's acceptable list and best decision)
- channel (text / email)
- customer first name present
- dates and times: required ones present. Any date, weekday, relative day ("today"/"tomorrow"), or clock time not in the record's allowed set fails.
- dollar amounts and percentages: required present, none outside the record
- links, phone numbers, emails: required present, none outside the record or business contact details
- required phrases (invoice number, prep items, "ET" label, confirm line)
- forbidden terms: discount, waive, reduce, collections, legal, attorney, lawsuit, court, sue, credit report. Fee/interest/penalty language on invoices is forbidden unless late-fee terms apply. Fee/no-show language on appointments is forbidden. Each case also has its own list.

A case passes only if all of those pass. A missing or wrong date, time, or amount is also flagged as a serious fact error. Also counted mechanically:
- parse failures (raw kept)
- over-routing (routed when the best decision was send)
- messages drafted on hold/route
- texts over 320 characters (reported only, not pass/fail)
- consistency across the 3 AI runs: same decision? same decision + channel + extracted facts?

Judgment scoring (labeled JUDGMENT everywhere, in a separate file, `evidence/scores-judgment.json`) covers only:
- (a) Tone/usability of each sent message: 2 = send as-is, 1 = usable with a small edit, 0 = wouldn't send.
- (b) Free-text note handling on the 9 note cases: 2 = correct and helpful (or routed with the note clearly surfaced when routing is best), 1 = safe but unhelpful or needlessly routed, 0 = mishandled, ignored the note, or made a commitment the policy doesn't allow.

Unapproved commitments spotted in reading are listed as judgment findings.

**2. Fingerprinted before the run:**
- `prompt.md`: exact system prompt + user template
- `records.json`: 30 synthetic records
- `expected.json`: per-case expected decisions, channels, required/forbidden fields
- `build_records.py`: generator for both
- `rules.py`: rules baseline
- `score_mechanical.py`
- `evidence/run.py`: runner
- this `design.md` including this addendum

The rules script is run once on all 30 records after fingerprinting.

**3. Small and costed.** 30 records (15 appointment, 15 payment) × 3 AI runs = 90 calls, plus the rules script once. Settings:
- model `claude-sonnet-5-5`, max_tokens 2000
- API defaults for everything else
- $5 cost cap in the runner

Actual cost is computed from the token usage each response reports × list price ($2 per million input tokens, $10 per million output, Anthropic pricing page checked 23 Oct 2026), and the calculation is shown in results.md.

**Case groups (fixed now):**
- Standard (21): A01–A06, A08–A12, P01–P06, P08, P10, P11, P14.
- Free-text note (9): A07, A13, A14, A15, P07, P09, P12, P13, P15.

Design choice stated up front: the rules script can't read free text, so any note routes that record to a person, with the note copied for staff. On note cases where the best answer is to route, that's a correct outcome for rules. On A13 (parking question), A15 (asks for email only) and P13 (asks for an invoice copy), sending is best and routing is acceptable but counts as over-routing.

**Decision rule, made concrete:**
- Standard reminders: if rules pass all 21 standard cases and AI has any mechanical failure on a standard case in any of its 3 runs, the article recommends rules for standard reminders. If both are perfect there, the article says they tied on accuracy and rules win on cost and predictability. If rules fail standard cases and AI doesn't, the recommendation changes to match.
- Note cases: AI "clearly outperforms" rules only if all three hold:
  - AI passes every note case mechanically in all 3 runs;
  - AI reaches the best decision on at least 2 more note cases than rules (majority of runs);
  - AI's note-handling judgment score is higher.

  Even then, AI is recommended only with a person checking before anything goes out if it got any fact wrong anywhere. If those conditions aren't met, the article says AI showed no clear advantage on notes.

**Small departures from the draft list, made before the run:**
- "Sensitive service (health/legal)" is tested with one counseling booking.
- "Missing time or phone" is two cases: A05 missing time; A06 missing phone, email on file.
- "Late-fee policy present vs. absent" is P11 (terms present, 35 days overdue) vs. P02 (30 days overdue, no terms).
- Added A13 (parking question), A14 (someone else attending), A15 (text opt-out in a note while the consent field still says yes), P12 (says paid by Zelle), P13 (asks for an invoice copy) and P15 (Spanish note asking to pay Friday) to fill the 15+15.
- "Today" for every record is Friday, October 23, 2026 (ET).
