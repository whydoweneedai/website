# EXP-003 results: AI vs. simple rules for appointment and payment reminders (SYNTHETIC TEST)

All 30 records are invented. No real customer, business, or message is involved, and nothing was sent to anyone. Mechanical scores come from `score_mechanical_v2.py` (DEVIATION D2, written after the run; see deviations.md. The locked result is in results.md). Scores marked **JUDGMENT** are the site's AI assistant's reading, not a mechanical check.

## Run facts
- Model requested: `claude-sonnet-5-5`. Model string returned in every response: {'claude-sonnet-5-5': 90}.
- AI calls: 90 (30 records × 3 runs). HTTP status counts: {200: 90}. Retries: 0. First call sent 2026-10-23T17:17:27-04:00, last 2026-10-23T17:21:48-04:00.
- Stop reasons: {'end_turn': 90}. Parse results (AI): {'clean': 78, 'extracted': 12}. ('extracted' = valid JSON wrapped in a markdown ```json fence; the scorer accepts it, but a strict JSON parser would reject it.)
- Rules script: run once on all 30 records (`rules-run.txt`).

## Observed API cost (from the token counts each response reported)
- Input tokens: 146,865 × $2.00 / 1,000,000 = $0.2937
- Output tokens: 28,330 × $10.00 / 1,000,000 = $0.2833
- **Total: $0.5770** for 90 calls (≈ $0.0064 per reminder decision). Anthropic list price for Claude Sonnet 5.5, checked 23 Oct 2026. No caching or batch discount was used. The rules script has no per-message API cost.

## Headline totals (MECHANICAL)
| Measure | Rules (1 run) | AI (3 runs = 90 outputs) |
|---|---|---|
| Outputs passing all checks | 30/30 | 90/90 |
| Standard cases passing (21 per run) | 21/21 | 63/63 |
| Note cases passing (9 per run) | 9/9 | 27/27 |
| Send/hold/route decision acceptable | 30/30 | 90/90 |
| Best decision | 27/30 | 90/90 |
| Serious fact errors (wrong/missing date, time or amount) | 0 | 0 |
| Invented content (fact not in record, or forbidden term) | 0 | 0 |
| Parse failures | 0 | 0 |
| Over-routed (routed when sending was best) | 3 | 0 |
| Message drafted on a hold/route decision | 0 | 0 |
| Texts over 320 characters (reported, not pass/fail) | 1 | 1 |
| Cases passing in every run | 30/30 | 30/30 |
| AI consistency: cases where the 3 runs disagreed on decision | n/a | 0/30 |
| AI consistency: cases where runs disagreed on decision, channel or any extracted fact | n/a | 5/30 |
| AI consistency: cases where runs disagreed on pass/fail | n/a | 0/30 |

### Per-category checks on sent messages (MECHANICAL; counts are passes / messages that were sent and where sending was acceptable)
| Check | Rules | AI |
|---|---|---|
| channel | 15/15 | 54/54 |
| name | 15/15 | 54/54 |
| dates_times | 15/15 | 54/54 |
| amounts | 15/15 | 54/54 |
| links_contacts | 15/15 | 54/54 |
| required_phrases | 15/15 | 54/54 |
| no_forbidden | 15/15 | 54/54 |

## Per-case table (MECHANICAL)
Key: S = send, H = hold, R = route to person; ✓ = passed all mechanical checks, ✗ = failed. Channel shown for sends (t = text, e = email).

| Case | Group | Scenario | Expected (best; acceptable) | Rules | AI run 1 | AI run 2 | AI run 3 | Failure detail |
|---|---|---|---|---|---|---|---|---|
| A01 | standard | standard 24h reminder | S; S via text | St ✓ | St ✓ | St ✓ | St ✓ |  |
| A02 | standard | same-day reminder | S; S via text | St ✓ | St ✓ | St ✓ | St ✓ |  |
| A03 | standard | reschedule already made | H; H/R | H ✓ | H ✓ | H ✓ | H ✓ |  |
| A04 | standard | cancelled booking | H; H/R | H ✓ | H ✓ | H ✓ | H ✓ |  |
| A05 | standard | missing time | R; R | R ✓ | R ✓ | R ✓ | R ✓ |  |
| A06 | standard | missing phone, email on file | S; S via email | Se ✓ | Se ✓ | Se ✓ | Se ✓ |  |
| A07 | note | free-text note: running late / push 30 min | R; R | R ✓ | R ✓ | R ✓ | R ✓ |  |
| A08 | standard | prep instructions | S; S via text/email | St ✓ | St ✓ | St ✓ | St ✓ |  |
| A09 | standard | sensitive service | S; S via text | St ✓ | St ✓ | St ✓ | St ✓ |  |
| A10 | standard | two bookings same day | S; S via text | St ✓ | St ✓ | St ✓ | St ✓ |  |
| A11 | standard | time-zone mismatch (customer in Pacific, video) | S; S via text | St ✓ | St ✓ | St ✓ | St ✓ |  |
| A12 | standard | repeat no-show | S; S via text | St ✓ | St ✓ | St ✓ | St ✓ |  |
| A13 | note | free-text note: parking question (answer is in policy) | S; S/R via text | R ✓ | St ✓ | St ✓ | St ✓ |  |
| A14 | note | free-text note: someone else attending | R; R | R ✓ | R ✓ | R ✓ | R ✓ |  |
| A15 | note | free-text note: text opt-out, consent field still true | S; S/R via email | R ✓ | Se ✓ | Se ✓ | Se ✓ |  |
| P01 | standard | first friendly reminder (due in 3 days) | S; S via text | St ✓ | St ✓ | St ✓ | St ✓ |  |
| P02 | standard | 30 days overdue, no late-fee terms | S; S via text | St ✓ | St ✓ | St ✓ | St ✓ |  |
| P03 | standard | partial payment | S; S via text | St ✓ | St ✓ | St ✓ | St ✓ |  |
| P04 | standard | already paid (reminder still queued) | H; H/R | H ✓ | H ✓ | H ✓ | H ✓ |  |
| P05 | standard | disputed invoice | R; R | R ✓ | R ✓ | R ✓ | R ✓ |  |
| P06 | standard | payment plan in place | S; S via text | St ✓ | St ✓ | St ✓ | St ✓ |  |
| P07 | note | free-text note: hardship | R; R | R ✓ | R ✓ | R ✓ | R ✓ |  |
| P08 | standard | large balance | R; R | R ✓ | R ✓ | R ✓ | R ✓ |  |
| P09 | note | wrong amount: record vs staff note | R; R | R ✓ | R ✓ | R ✓ | R ✓ |  |
| P10 | standard | no pay link on file | S; S via text | St ✓ | St ✓ | St ✓ | St ✓ |  |
| P11 | standard | late-fee terms present, 35 days overdue | S; S via text | St ✓ | St ✓ | St ✓ | St ✓ |  |
| P12 | note | free-text note: says already paid (not recorded) | R; H/R | R ✓ | R ✓ | R ✓ | R ✓ |  |
| P13 | note | free-text note: asks for invoice copy (pay link shows invoice) | S; S/R via email/text | R ✓ | Se ✓ | Se ✓ | St ✓ |  |
| P14 | standard | standard second reminder, 14 days overdue | S; S via text | St ✓ | St ✓ | St ✓ | St ✓ |  |
| P15 | note | free-text note in Spanish: can I pay Friday? | R; R/H | R ✓ | R ✓ | R ✓ | R ✓ |  |

## JUDGMENT scores (the site's AI assistant's reading; not mechanical)
Tone/usability (every sent message): 2 = send as-is, 1 = small edit needed, 0 = wouldn't send. Notes handling (9 note cases): 2 = correct and helpful, or routed with the note surfaced for staff; 1 = safe but unhelpful, or over-routed; 0 = mishandled or made an unapproved commitment.

### Tone/usability of sent messages (0–2 each)
| Method | Items scored | Total | Mean | 2s | 1s | 0s |
|---|---|---|---|---|---|---|
| rules | 15 | 29/30 | 1.93 | 14 | 1 | 0 |
| ai | 54 | 107/108 | 1.98 | 53 | 1 | 0 |

Items scored below 2:
- rules A08: 1. 344 characters, over the 320-character limit in the policy; would go out as 3 SMS segments. Trim before sending.
- ai A08 run 1: 1. 333 characters, over the 320-character limit the model was given; would need trimming.

### Free-text note handling, 9 note cases (0–2 each)
| Method | Items scored | Total | Mean | 2s | 1s | 0s |
|---|---|---|---|---|---|---|
| rules | 9 | 15/18 | 1.67 | 6 | 3 | 0 |
| ai | 27 | 53/54 | 1.96 | 26 | 1 | 0 |

Items scored below 2:
- rules A13: 1. Over-routed: a parking question the policy answers; customer gets no reminder until staff act.
- rules A15: 1. Over-routed: safe (no text sent), but the opt-out could be honored by emailing; customer gets no reminder until staff act.
- rules P13: 1. Over-routed: the copy request could be met by emailing the pay link (policy says it shows the full invoice).
- ai P13 run 3: 1. Texted instead of emailing, although the customer asked for email and an email is on file; it did include the link and flagged staff. Safe but not what was asked.

### Other JUDGMENT findings
- No unapproved commitments found in any of the 90 AI outputs (messages or staff notes): no new times confirmed, no payment arrangements, no due-date changes, no discounts or waivers. Checked by reading every output plus a phrase search (we'll / will / guarantee / approved / confirmed / attached).
- Both methods sent A11 (Pacific-time customer) a time labelled ET, as the policy said to. Shared design issue, not a method difference.
- AI P13 runs 1 and 2 sent the copy by email as asked; run 3 sent a text instead. This is the only AI notes item scored below 2.
- The AI's staff notes were more useful than the rules script's raw note copy: it summarized the ask, included the callback number, translated the Spanish note (P15) and spelled out the $410.00 vs $460.00 conflict (P09). The rules script copied the note text without explaining it.

---
## Hand-written note (added after tally.py ran; not generated)
- **What the 5 "runs disagreed" cases were** (added 2026-10-23 17:40 EDT, deviation D7): A12, P06 and P11 differed only in whether the business phone number was included. A13 differed only in whether "tomorrow" was written next to the same date (run 3 left it out). P13 was the only case that differed in channel (email in runs 1 and 2, text in run 3). No case differed in decision.
- **Thinking blocks** (added 2026-10-23 17:40 EDT, deviation D6): 25 of 90 raw responses contain a thinking block; 10,265 thinking tokens are included in the output-token count and cost above. Scored text is unaffected.
