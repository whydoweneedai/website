"""EXP-003 AI runner. 30 records x 3 independent runs = 90 calls to the Anthropic Messages API.
Prompt is read verbatim from ../prompt.md (fenced blocks 1 and 2). Records from ../records.json. expected.json is never read.
The API key is read from the ANTHROPIC_API_KEY environment variable and is never printed or written. Saved request bodies contain no headers.
Cost cap: stops if estimated spend passes $5.00 (Sonnet 5.5 list price $2/MTok input, $10/MTok output, checked 2026-10-23)."""
import json, os, re, sys, time, datetime, urllib.request, urllib.error
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
blocks = re.findall(r"```text\n(.*?)\n```", open(os.path.join(ROOT, "prompt.md"), encoding="utf-8").read(), re.S)
SYSTEM, USER_T = blocks[0], blocks[1]
TODAY = "Friday, October 23, 2026 (ET)"
MODEL, MAX_TOKENS, RUNS = "claude-sonnet-5-5", 2000, 3
PRICE_IN, PRICE_OUT, CAP = 2.00, 10.00, 5.00
recs = json.load(open(os.path.join(ROOT, "records.json"), encoding="utf-8"))
os.makedirs(os.path.join(HERE, "raw"), exist_ok=True)
outputs, log, spent = [], [], 0.0

def call(body):
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=json.dumps(body).encode(), method="POST",
        headers={"x-api-key": os.environ["ANTHROPIC_API_KEY"], "anthropic-version": "2023-06-01", "content-type": "application/json"})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=180) as r: return r.status, json.loads(r.read()), attempt
        except urllib.error.HTTPError as e:
            txt = e.read().decode("utf-8", "replace")
            if e.code in (429, 500, 502, 503, 529) and attempt < 3: time.sleep(10 * (attempt + 1)); continue
            try: return e.code, json.loads(txt), attempt
            except Exception: return e.code, {"error_text": txt[:2000]}, attempt
        except Exception as e:
            if attempt < 3: time.sleep(10); continue
            return None, {"error_text": type(e).__name__ + ": " + str(e)[:500]}, attempt

for run in range(1, RUNS + 1):
    for rec in recs:
        if spent > CAP: print("COST CAP HIT, stopping"); sys.exit(2)
        rid = rec["record_id"]
        body = {"model": MODEL, "max_tokens": MAX_TOKENS, "system": SYSTEM,
                "messages": [{"role": "user", "content": USER_T.replace("{TODAY}", TODAY).replace("{RECORD_JSON}", json.dumps(rec, indent=2, ensure_ascii=False))}]}
        sent = datetime.datetime.now().astimezone().isoformat(timespec="seconds")
        status, resp, retries = call(body)
        recd = datetime.datetime.now().astimezone().isoformat(timespec="seconds")
        u = resp.get("usage", {}) if isinstance(resp, dict) else {}
        cost = u.get("input_tokens", 0) / 1e6 * PRICE_IN + u.get("output_tokens", 0) / 1e6 * PRICE_OUT
        spent += cost
        text = "".join(b.get("text", "") for b in resp.get("content", []) if b.get("type") == "text") if isinstance(resp, dict) else ""
        json.dump({"case_id": rid, "run": run, "sent_at": sent, "received_at": recd, "http_status": status, "retries": retries,
                   "request_body": body, "response": resp, "est_cost_usd": round(cost, 6)},
                  open(os.path.join(HERE, "raw", f"{rid}-run{run}.json"), "w", encoding="utf-8"), indent=2, ensure_ascii=False)
        outputs.append({"record_id": rid, "run": run, "http_status": status, "model": resp.get("model") if isinstance(resp, dict) else None,
                        "stop_reason": resp.get("stop_reason") if isinstance(resp, dict) else None, "usage": u, "raw_text": text})
        log.append({"case_id": rid, "run": run, "http_status": status, "retries": retries, "model": outputs[-1]["model"], "input_tokens": u.get("input_tokens"),
                    "output_tokens": u.get("output_tokens"), "stop_reason": outputs[-1]["stop_reason"], "est_cost_usd": round(cost, 6), "sent_at": sent})
        print(f"run{run} {rid} status={status} model={outputs[-1]['model']} in={u.get('input_tokens')} out={u.get('output_tokens')} cost=${cost:.4f} total=${spent:.4f}", flush=True)
        json.dump(outputs, open(os.path.join(HERE, "ai-outputs.json"), "w", encoding="utf-8"), indent=2, ensure_ascii=False)
        json.dump(log, open(os.path.join(HERE, "run-log.json"), "w", encoding="utf-8"), indent=2)
print(f"DONE calls={len(outputs)} est_total=${spent:.4f}")
