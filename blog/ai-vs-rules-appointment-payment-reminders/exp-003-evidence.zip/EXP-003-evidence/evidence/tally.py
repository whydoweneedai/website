"""EXP-003 tally. Reads scores-mechanical.json (scripted), scores-judgment.json (JUDGMENT), run-log.json, ai-outputs.json. Writes results.md.
Written after the run (aggregation only; it doesn't score anything)."""
import json, os, collections, sys
H = os.path.dirname(os.path.abspath(__file__)); R = os.path.dirname(H)
SC = sys.argv[1] if len(sys.argv) > 1 else "scores-mechanical.json"; OUTF = sys.argv[2] if len(sys.argv) > 2 else "results.md"
M = json.load(open(f"{H}/{SC}")); rows, cons = M["rows"], M["ai_consistency"]
J = json.load(open(f"{H}/scores-judgment.json")) if os.path.exists(f"{H}/scores-judgment.json") else None
LOG = json.load(open(f"{H}/run-log.json")); EXP = json.load(open(f"{R}/expected.json"))["cases"]
PIN, POUT = 2.00, 10.00
ids = list(EXP)
def sel(method, group=None, run=None): return [r for r in rows if r["method"] == method and (group is None or r["group"] == group) and (run is None or r["run"] == run)]
CATS = ["channel", "name", "dates_times", "amounts", "links_contacts", "required_phrases", "no_forbidden"]
L = []; w = L.append
tin = sum(x["input_tokens"] or 0 for x in LOG); tout = sum(x["output_tokens"] or 0 for x in LOG)
models = collections.Counter(x["model"] for x in LOG); stat = collections.Counter(x["http_status"] for x in LOG)
w("# EXP-003 results: AI vs. simple rules for appointment and payment reminders (SYNTHETIC TEST)\n")
w("All 30 records are invented. No real customer, business, or message is involved, and nothing was sent to anyone. Mechanical scores come from `" + ("score_mechanical.py` (fingerprinted before the run; this is the PRIMARY, locked result)" if SC == "scores-mechanical.json" else "score_mechanical_v2.py` (DEVIATION D2, written after the run; see deviations.md. The locked result is in results.md)") + ". Scores marked **JUDGMENT** are the site's AI assistant's reading, not a mechanical check.\n")
w("## Run facts")
w(f"- Model requested: `claude-sonnet-5-5`. Model string returned in every response: {dict(models)}.")
w(f"- AI calls: {len(LOG)} (30 records × 3 runs). HTTP status counts: {dict(stat)}. Retries: {sum(x['retries'] for x in LOG)}. First call sent {LOG[0]['sent_at']}, last {LOG[-1]['sent_at']}.")
w(f"- Stop reasons: {dict(collections.Counter(x['stop_reason'] for x in LOG))}. Parse results (AI): {dict(collections.Counter(r['parse'] for r in sel('ai')))}. ('extracted' = valid JSON wrapped in a markdown ```json fence; the scorer accepts it, but a strict JSON parser would reject it.)")
w("- Rules script: run once on all 30 records (`rules-run.txt`).\n")
w("## Observed API cost (from the token counts each response reported)")
w(f"- Input tokens: {tin:,} × $2.00 / 1,000,000 = ${tin*PIN/1e6:.4f}")
w(f"- Output tokens: {tout:,} × $10.00 / 1,000,000 = ${tout*POUT/1e6:.4f}")
w(f"- **Total: ${tin*PIN/1e6 + tout*POUT/1e6:.4f}** for 90 calls (≈ ${(tin*PIN/1e6 + tout*POUT/1e6)/90:.4f} per reminder decision). Anthropic list price for Claude Sonnet 5.5, checked 23 Oct 2026. No caching or batch discount was used. The rules script has no per-message API cost.\n")
def summary(method, runs):
    out = {}
    for g in ("standard", "note", None):
        rs = [r for r in rows if r["method"] == method and (g is None or r["group"] == g)]
        out[g or "all"] = (sum(r["pass"] for r in rs), len(rs))
    return out
w("## Headline totals (MECHANICAL)")
w("| Measure | Rules (1 run) | AI (3 runs = 90 outputs) |\n|---|---|---|")
rs, ai = sel("rules"), sel("ai")
def frac(a, b): return f"{a}/{b}"
for label, f in [("Outputs passing all checks", lambda X: frac(sum(r['pass'] for r in X), len(X))),
                 ("Standard cases passing (21 per run)", lambda X: frac(sum(r['pass'] for r in X if r['group']=='standard'), sum(r['group']=='standard' for r in X))),
                 ("Note cases passing (9 per run)", lambda X: frac(sum(r['pass'] for r in X if r['group']=='note'), sum(r['group']=='note' for r in X))),
                 ("Send/hold/route decision acceptable", lambda X: frac(sum(r['decision_ok'] for r in X), len(X))),
                 ("Best decision", lambda X: frac(sum(r['decision_best'] for r in X), len(X))),
                 ("Serious fact errors (wrong/missing date, time or amount)", lambda X: str(sum(bool(r.get('serious_fact_error')) for r in X))),
                 ("Invented content (fact not in record, or forbidden term)", lambda X: str(sum(bool(r.get('invented_content')) for r in X))),
                 ("Parse failures", lambda X: str(sum(r['parse'] in ('empty','unparseable') for r in X))),
                 ("Over-routed (routed when sending was best)", lambda X: str(sum(r['over_routed'] for r in X))),
                 ("Message drafted on a hold/route decision", lambda X: str(sum(r['drafted_message_on_nonsend'] for r in X))),
                 ("Texts over 320 characters (reported, not pass/fail)", lambda X: str(sum(bool(r.get('text_over_320')) for r in X)))]:
    w(f"| {label} | {f(rs)} | {f(ai)} |")
allpass = [rid for rid in ids if all(r["pass"] for r in sel("ai") if r["record_id"] == rid)]
w(f"| Cases passing in every run | {sum(r['pass'] for r in rs)}/30 | {len(allpass)}/30 |")
w(f"| AI consistency: cases where the 3 runs disagreed on decision | n/a | {sum(c['decision_disagree'] for c in cons.values())}/30 |")
w(f"| AI consistency: cases where runs disagreed on decision, channel or any extracted fact | n/a | {sum(c['any_disagree'] for c in cons.values())}/30 |")
w(f"| AI consistency: cases where runs disagreed on pass/fail | n/a | {sum(c['pass_disagree'] for c in cons.values())}/30 |\n")
w("### Per-category checks on sent messages (MECHANICAL; counts are passes / messages that were sent and where sending was acceptable)")
w("| Check | Rules | AI |\n|---|---|---|")
for c in CATS:
    vals = []
    for X in (rs, ai):
        S = [r for r in X if r["decision"] == "send" and r["decision_ok"] and r["checks"]]
        vals.append(frac(sum(r["checks"].get(c, False) for r in S), len(S)))
    w(f"| {c} | {vals[0]} | {vals[1]} |")
w("")
w("## Per-case table (MECHANICAL)")
w("Key: S = send, H = hold, R = route to person; ✓ = passed all mechanical checks, ✗ = failed. Channel shown for sends (t = text, e = email).\n")
w("| Case | Group | Scenario | Expected (best; acceptable) | Rules | AI run 1 | AI run 2 | AI run 3 | Failure detail |\n|---|---|---|---|---|---|---|---|---|")
ab = {"send": "S", "hold": "H", "route_to_person": "R", None: "?"}
def cell(r):
    if r is None: return "—"
    ch = {"text": "t", "email": "e"}.get(r["channel"], "") if r["decision"] == "send" else ""
    return f"{ab.get(r['decision'], r['decision'])}{ch} {'✓' if r['pass'] else '✗'}"
for rid in ids:
    e = EXP[rid]; rr = next(r for r in rs if r["record_id"] == rid)
    a = {r["run"]: r for r in ai if r["record_id"] == rid}
    det = [f"rules: {rr['fail_reason']}"] if not rr["pass"] else []
    det += [f"AI r{k}: {a[k]['fail_reason']}" for k in sorted(a) if not a[k]["pass"]]
    w(f"| {rid} | {e['group']} | {e['scenario']} | {ab[e['decision_best']]}; {'/'.join(ab[d] for d in e['decision_ok'])}{(' via ' + '/'.join(e['channel_ok'])) if e['channel_ok'] else ''} | {cell(rr)} | {cell(a.get(1))} | {cell(a.get(2))} | {cell(a.get(3))} | {'<br>'.join(det).replace('|','/') or ''} |")
w("")
if J:
    w("## JUDGMENT scores (the site's AI assistant's reading; not mechanical)")
    w(J["rubric_text"] + "\n")
    for kind, title in (("tone", "Tone/usability of sent messages (0–2 each)"), ("notes", "Free-text note handling, 9 note cases (0–2 each)")):
        w(f"### {title}")
        w("| Method | Items scored | Total | Mean | 2s | 1s | 0s |\n|---|---|---|---|---|---|---|")
        for m in ("rules", "ai"):
            S = [x["score"] for x in J[kind] if x["method"] == m]
            if S: w(f"| {m} | {len(S)} | {sum(S)}/{2*len(S)} | {sum(S)/len(S):.2f} | {S.count(2)} | {S.count(1)} | {S.count(0)} |")
            else: w(f"| {m} | 0 | — | — | — | — | — |")
        w("")
        low = [x for x in J[kind] if x["score"] < 2]
        if low:
            w("Items scored below 2:")
            for x in low: w(f"- {x['method']} {x['record_id']}{(' run ' + str(x['run'])) if x['method']=='ai' else ''}: {x['score']}. {x['note']}")
        w("")
    if J.get("findings"):
        w("### Other JUDGMENT findings")
        for f in J["findings"]: w(f"- {f}")
        w("")
open(f"{H}/{OUTF}", "w").write("\n".join(L))
print("\n".join(L[:60]))
