"""EXP-003 mechanical scorer v2 (DEVIATION D2, written after the run, 23 Oct 2026). Identical to the locked score_mechanical.py except: weekday names from the business-hours line are allowed facts; output goes to evidence/scores-mechanical-v2.json.
Original docstring follows.
EXP-003 mechanical scorer. Written and fingerprinted 2026-10-23 BEFORE any AI call. No judgment here.
Input: evidence/rules-outputs.json and evidence/ai-outputs.json. Every output is scored from its raw text (rules outputs are serialized to JSON text first,
so both methods go through the same parser). Output: evidence/scores-mechanical.json.
Pass (per output) = parsed JSON AND decision in decision_ok AND (if send) channel ok, message present, required name/dates/times/amounts/phrases/urls/phones
present, no fact outside the record's allowed set (dates, times, $ amounts, %, urls, phones, emails), and no forbidden term."""
import json, re, datetime, sys
from collections import Counter

EXP = json.load(open("expected.json")); RECS = {r["record_id"]: r for r in json.load(open("records.json"))}
TODAY = datetime.date.fromisoformat(EXP["today"]); TOMORROW = TODAY + datetime.timedelta(days=1)
MONTHS = {m: i for i, m in enumerate(["jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"], 1)}
WEEKDAYS = ["monday","tuesday","wednesday","thursday","friday","saturday","sunday"]
GLOBAL_FORBIDDEN = [r"discount", r"waiv", r"\breduc", r"collection", r"\blegal\b", r"attorney", r"lawsuit", r"\bcourt\b", r"\bsue\b", r"credit (report|bureau|score)"]
INVOICE_FEE_TERMS = [r"late fee", r"\bfees?\b", r"interest", r"penalt"]  # invoice records only, unless allow_late_fee
APPT_FORBIDDEN = [r"\bfee", r"no[- ]?show"]
# v2 deviation (2026-10-23, after the run): business-hours weekdays stated in prompt.md are allowed facts, same as business-hours times already were.
HOURS_DAYS = {"Lakeside Wellness Studio": set(WEEKDAYS[:6]), "Ridgeway Landscaping": set(WEEKDAYS[:5])}

def parse(raw):
    if not isinstance(raw, str) or not raw.strip(): return None, "empty"
    t = raw.strip()
    try: return json.loads(t), "clean"
    except Exception: pass
    a, b = t.find("{"), t.rfind("}")
    if a != -1 and b > a:
        try: return json.loads(t[a:b+1]), "extracted"
        except Exception: pass
    return None, "unparseable"

URL_RE = re.compile(r"https?://[^\s)\]>\"']+")
def norm_url(u): return u.rstrip(".,;:!?")
def money(s): return f"{float(s.replace('$','').replace(',','')):.2f}"
def digits(s): return re.sub(r"\D", "", s)

def extract(msg):
    urls = [norm_url(u) for u in URL_RE.findall(msg)]
    t = URL_RE.sub(" ", msg)
    emails = re.findall(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+", t); t2 = re.sub(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+", " ", t)
    phones = [digits(p) for p in re.findall(r"\(?\b\d{3}\)?[\s.\-]?\d{3}[\s.\-]\d{4}\b", t2)]
    t3 = re.sub(r"\(?\b\d{3}\)?[\s.\-]?\d{3}[\s.\-]\d{4}\b", " ", t2)
    amounts = [money(a) for a in re.findall(r"\$\s?(\d[\d,]*(?:\.\d{1,2})?)", t3)]
    percents = re.findall(r"\d+(?:\.\d+)?\s?%", t3)
    dates = set()
    for m, d in re.findall(r"\b(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|june?|july?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?\s+(\d{1,2})(?:st|nd|rd|th)?\b", t3, re.I):
        try: dates.add(datetime.date(2026, MONTHS[m[:3].lower()], int(d)).isoformat())
        except ValueError: dates.add(f"invalid:{m} {d}")
    for mo, d, _y in re.findall(r"\b(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?\b", t3):
        try: dates.add(datetime.date(2026, int(mo), int(d)).isoformat())
        except ValueError: dates.add(f"invalid:{mo}/{d}")
    for iso in re.findall(r"\b20\d\d-\d\d-\d\d\b", t3): dates.add(iso)
    rel = set()
    if re.search(r"\btomorrow\b", t3, re.I): rel.add(TOMORROW.isoformat())
    if re.search(r"\b(today|tonight|this (morning|afternoon|evening))\b", t3, re.I): rel.add(TODAY.isoformat())
    weekdays = {w.lower() for w in re.findall(r"\b(" + "|".join(WEEKDAYS) + r")\b", t3, re.I)}
    times = set()
    for h, mnt, ap in re.findall(r"\b(\d{1,2})(?::(\d{2}))?\s*([ap])\.?\s*m\b\.?", t3, re.I):
        h = int(h) % 12 + (12 if ap.lower() == "p" else 0); times.add(f"{h:02d}:{mnt or '00'}")
    unlabeled = re.findall(r"\b(\d{1,2}):(\d{2})\b(?!\s*[ap]\.?\s*m)", t3, re.I)
    if re.search(r"\bnoon\b", t3, re.I): times.add("12:00")
    return dict(urls=urls, emails=[e.lower() for e in emails], phones=phones, amounts=amounts, percents=percents, dates=dates, rel_dates=rel,
                weekdays=weekdays, times=times, unlabeled_times=[f"{int(h):02d}:{m}" for h, m in unlabeled])

def to24(t12):
    m = re.match(r"(\d{1,2}):(\d{2})\s*([AP])M", t12, re.I); h = int(m.group(1)) % 12 + (12 if m.group(3).upper() == "P" else 0); return f"{h:02d}:{m.group(2)}"

def allowed_sets(rec, exp):
    dates, times, amts, urls, emails = {TODAY.isoformat()}, set(exp.get("extra_allowed_times", [])), set(exp.get("extra_allowed_amounts", [])), set(), set()
    phones = {EXP["business_phones"][rec["business"]]}
    emails.add(EXP["business_emails"][rec["business"]])
    if rec.get("email"): emails.add(rec["email"].lower())
    times |= set(EXP["business_hours_times"][rec["business"]])
    if rec["record_type"] == "appointment_reminder":
        for a in rec["appointments"]:
            if a.get("date"): dates.add(a["date"])
            if a.get("time"): times.add(to24(a["time"]))
            if a.get("video_link"): urls.add(a["video_link"])
        if rec.get("rescheduled_to"): dates.add(rec["rescheduled_to"]["date"]); times.add(to24(rec["rescheduled_to"]["time"]))
    else:
        dates.add(rec["due_date"])
        for k in ("invoice_total", "amount_paid", "balance_due", "late_fee_amount"):
            if rec.get(k): amts.add(money(rec[k]))
        if rec.get("payment_plan"): amts.add(money(rec["payment_plan"]["installment_amount"])); dates.add(rec["payment_plan"]["next_installment_due"])
        if rec.get("pay_link"): urls.add(rec["pay_link"])
    return dict(dates=dates, times=times, amounts=amts, urls=urls, phones=phones, emails=emails)

def score(rid, raw):
    rec, exp = RECS[rid], EXP["cases"][rid]
    obj, how = parse(raw)
    row = {"record_id": rid, "group": exp["group"], "parse": how, "decision": None, "channel": None, "decision_ok": False, "decision_best": False,
           "over_routed": False, "drafted_message_on_nonsend": False, "checks": {}, "disallowed": [], "forbidden_hits": [], "missing": [], "pass": False,
           "facts": None, "message_chars": None}
    if obj is None or not isinstance(obj, dict): row["fail_reason"] = "parse failure"; return row
    dec, ch, msg = obj.get("decision"), obj.get("channel"), obj.get("message")
    row.update(decision=dec, channel=ch, decision_ok=dec in exp["decision_ok"], decision_best=dec == exp["decision_best"],
               over_routed=(dec == "route_to_person" and exp["decision_best"] == "send"),
               drafted_message_on_nonsend=(dec in ("hold", "route_to_person") and isinstance(msg, str) and bool(msg.strip())))
    if dec != "send":
        row["pass"] = row["decision_ok"]
        if not row["pass"]: row["fail_reason"] = f"decision {dec!r} not in {exp['decision_ok']}"
        return row
    if not row["decision_ok"]: row["fail_reason"] = f"sent but expected {exp['decision_ok']}"
    if not isinstance(msg, str) or not msg.strip():
        row["fail_reason"] = row.get("fail_reason", "send with empty message"); row["checks"]["message_present"] = False; return row
    row["message_chars"] = len(msg)
    f = extract(msg); A = allowed_sets(rec, exp)
    row["facts"] = {k: sorted(v) if isinstance(v, (set, list)) else v for k, v in f.items()}
    req = exp["required"] or {"name": rec["customer_first_name"], "dates": [], "times": [], "amounts": [], "phrases": [], "urls": [], "phones": []}
    c = {}
    c["channel"] = ch in exp["channel_ok"] if exp["channel_ok"] else False
    # names
    c["name"] = bool(re.search(r"\b" + re.escape(req["name"]) + r"\b", msg))
    # dates & times
    all_dates = f["dates"] | f["rel_dates"]
    miss_d = [d for d in req["dates"] if d not in all_dates]
    bad_d = sorted(d for d in f["dates"] | f["rel_dates"] if d not in A["dates"])
    allowed_wd = {WEEKDAYS[datetime.date.fromisoformat(d).weekday()] for d in A["dates"]}
    allowed_wd |= HOURS_DAYS[rec["business"]]  # v2 deviation: weekday names from the business-hours line in prompt.md (lines 11 and 15)
    bad_wd = sorted(w for w in f["weekdays"] if w not in allowed_wd)
    # a weekday must also agree with any explicit date it sits next to: checked via allowed set (all allowed weekdays come from allowed dates)
    miss_t = [t for t in req["times"] if t not in f["times"] and t not in f["unlabeled_times"] and f"{int(t[:2])-12:02d}:{t[3:]}" not in f["unlabeled_times"]]
    bad_t = sorted(t for t in f["times"] if t not in A["times"])
    bad_ut = [t for t in f["unlabeled_times"] if t not in A["times"] and f"{int(t[:2])+12:02d}:{t[3:]}" not in A["times"]]
    c["dates_times"] = not (miss_d or bad_d or bad_wd or miss_t or bad_t or bad_ut)
    # amounts (+ percents)
    miss_a = [a for a in req["amounts"] if a not in f["amounts"]]
    bad_a = sorted(a for a in f["amounts"] if a not in A["amounts"])
    bad_pct = f["percents"] if not exp.get("allow_late_fee") else []
    c["amounts"] = not (miss_a or bad_a or bad_pct)
    # links, phones, emails
    miss_u = [u for u in req["urls"] if u not in f["urls"]]; bad_u = [u for u in f["urls"] if u not in A["urls"]]
    miss_p = [p for p in req["phones"] if p not in f["phones"]]; bad_p = [p for p in f["phones"] if p not in A["phones"]]
    bad_e = [e for e in f["emails"] if e not in A["emails"]]
    c["links_contacts"] = not (miss_u or bad_u or miss_p or bad_p or bad_e)
    # required phrases (invoice number, prep items, ET label, confirm line)
    miss_ph = [p for p in req["phrases"] if not re.search(p, msg, re.I)]
    c["required_phrases"] = not miss_ph
    # forbidden terms
    forb = list(GLOBAL_FORBIDDEN) + list(exp.get("forbidden", []))
    if rec["record_type"] == "invoice_reminder" and not exp.get("allow_late_fee"): forb += INVOICE_FEE_TERMS
    if rec["record_type"] == "appointment_reminder": forb += APPT_FORBIDDEN
    hits = sorted({p for p in forb if re.search(p, msg, re.I)})
    c["no_forbidden"] = not hits
    row["checks"] = c
    row["missing"] = [*(f"date:{d}" for d in miss_d), *(f"time:{t}" for t in miss_t), *(f"amount:{a}" for a in miss_a), *(f"url:{u}" for u in miss_u),
                      *(f"phone:{p}" for p in miss_p), *(f"phrase:{p}" for p in miss_ph), *([] if c["name"] else [f"name:{req['name']}"])]
    row["disallowed"] = [*(f"date:{d}" for d in bad_d), *(f"weekday:{w}" for w in bad_wd), *(f"time:{t}" for t in bad_t + bad_ut), *(f"amount:{a}" for a in bad_a),
                         *(f"percent:{p}" for p in bad_pct), *(f"url:{u}" for u in bad_u), *(f"phone:{p}" for p in bad_p), *(f"email:{e}" for e in bad_e)]
    row["forbidden_hits"] = hits
    row["serious_fact_error"] = bool(miss_d or bad_d or bad_wd or miss_t or bad_t or bad_ut or miss_a or bad_a)
    row["invented_content"] = bool(row["disallowed"] or hits)
    row["text_over_320"] = (ch == "text" and len(msg) > 320)
    row["pass"] = row["decision_ok"] and all(c.values())
    if not row["pass"] and "fail_reason" not in row:
        row["fail_reason"] = "; ".join([k for k, v in c.items() if not v] + row["missing"] + row["disallowed"] + row["forbidden_hits"])
    return row

def fact_key(row):
    f = row["facts"] or {}
    return json.dumps([row["decision"], row["channel"], sorted(f.get("dates", [])), sorted(f.get("rel_dates", [])), sorted(f.get("times", [])),
                       sorted(f.get("amounts", [])), sorted(f.get("urls", [])), sorted(f.get("phones", []))])

if __name__ == "__main__":
    rules = json.load(open("evidence/rules-outputs.json"))
    rows = [{"method": "rules", "run": 1, **score(x["record_id"], json.dumps(x["output"], ensure_ascii=False))} for x in rules]
    ai = json.load(open("evidence/ai-outputs.json"))
    rows += [{"method": "ai", "run": x["run"], **score(x["record_id"], x["raw_text"])} for x in ai]
    cons = {}
    for rid in RECS:
        rr = [r for r in rows if r["method"] == "ai" and r["record_id"] == rid]
        cons[rid] = {"runs": len(rr), "decision_disagree": len({r["decision"] for r in rr}) > 1, "any_disagree": len({fact_key(r) for r in rr}) > 1,
                     "pass_disagree": len({r["pass"] for r in rr}) > 1}
    json.dump({"scored_at": datetime.datetime.now().astimezone().isoformat(timespec="seconds"), "rows": rows, "ai_consistency": cons},
              open("evidence/scores-mechanical-v2.json", "w"), indent=2, ensure_ascii=False, default=sorted)
    print(Counter((r["method"], r["pass"]) for r in rows))
