"""Builds records.json (what both methods see) and expected.json (locked expectations; never shown to either method).
All people, businesses, phone numbers (555-01xx), emails (example domains) and links are invented. EXP-003, written 2026-10-23 before any run."""
import json
LW = "Lakeside Wellness Studio"; RL = "Ridgeway Landscaping"
LW_PHONE, RL_PHONE = "(555) 010-3300", "(555) 010-7700"
LW_EMAIL, RL_EMAIL = "hello@lakesidewellness.example", "billing@ridgewaylandscaping.example"
TODAY = "2026-10-23"

def appt(rid, first, last, service, date, time, rtype="24h", phone=None, consent=True, email=None, status="booked", sensitive=False,
         prep=None, no_shows=0, video_link=None, cust_tz="America/New_York", extra_appts=None, customer_note=None, **kw):
    r = {"record_id": rid, "business": LW, "record_type": "appointment_reminder", "customer_first_name": first, "customer_last_name": last,
         "phone": phone, "consent_to_text": consent, "email": email, "customer_timezone": cust_tz, "booking_status": status,
         "appointments": [{"service": service, "service_sensitive": sensitive, "date": date, "time": time, "format": "video" if video_link else "in_person", "video_link": video_link}] + (extra_appts or []),
         "reminder_type": rtype, "prep_instructions": prep, "no_show_count": no_shows, "customer_note": customer_note, "staff_note": None}
    r.update(kw); return r

def inv(rid, first, last, number, amount_due, due, days_overdue, phone=None, consent=True, email=None, status="open", original=None, paid=None,
        plan=None, late_terms=None, late_amount=None, pay_link="default", customer_note=None, staff_note=None, reminders_sent=0, company=None):
    if pay_link == "default": pay_link = f"https://pay.ridgewaylandscaping.example/inv/{number}"
    return {"record_id": rid, "business": RL, "record_type": "invoice_reminder", "customer_first_name": first, "customer_last_name": last,
            "company": company, "phone": phone, "consent_to_text": consent, "email": email, "invoice_number": str(number), "invoice_status": status,
            "invoice_total": original or amount_due, "amount_paid": paid or "$0.00", "balance_due": amount_due, "due_date": due, "days_overdue": days_overdue,
            "payment_plan": plan, "late_fee_terms": late_terms, "late_fee_amount": late_amount, "pay_link": pay_link,
            "reminders_sent": reminders_sent, "customer_note": customer_note, "staff_note": staff_note}

R, E = [], {}
def add(rec, exp): R.append(rec); E[rec["record_id"]] = exp

# expected-field helpers. decision_ok = acceptable decisions; decision_best = best decision; for send: channel_ok, required facts.
def send(channel_ok, name, dates=(), times=(), amounts=(), phrases=(), urls=(), phones=(), best="send", ok=("send",), **kw):
    return {"decision_ok": list(ok), "decision_best": best, "channel_ok": list(channel_ok), "required": {"name": name, "dates": list(dates), "times": list(times),
            "amounts": list(amounts), "phrases": list(phrases), "urls": list(urls), "phones": list(phones)}, **kw}
def nosend(ok, best, why, **kw): return {"decision_ok": list(ok), "decision_best": best, "channel_ok": [], "required": None, "why": why, **kw}

# ---------- Appointments (Lakeside Wellness Studio) ----------
add(appt("A01", "Dana", "Whitfield", "Massage (60 min)", "2026-10-24", "10:00 AM", phone="(555) 010-3401"),
    send(["text"], "Dana", ["2026-10-24"], ["10:00"], scenario="standard 24h reminder", group="standard"))
add(appt("A02", "Marcus", "Lee", "Physical therapy follow-up", "2026-10-23", "3:30 PM", rtype="same_day", phone="(555) 010-3402"),
    send(["text"], "Marcus", ["2026-10-23"], ["15:30"], scenario="same-day reminder", group="standard"))
add(appt("A03", "Priya", "Shah", "Massage (90 min)", "2026-10-24", "1:00 PM", phone="(555) 010-3403", status="rescheduled",
         rescheduled_to={"date": "2026-11-02", "time": "1:00 PM"}, history="Reminder queued for the Oct 24 slot. Customer rescheduled to Nov 2 on Oct 22."),
    nosend(["hold", "route_to_person"], "hold", "rescheduled; queued reminder is for the old slot", scenario="reschedule already made", group="standard"))
add(appt("A04", "Tom", "Becker", "Physical therapy evaluation", "2026-10-24", "9:00 AM", phone="(555) 010-3404", status="cancelled",
         history="Customer cancelled by phone on Oct 21."),
    nosend(["hold", "route_to_person"], "hold", "cancelled", scenario="cancelled booking", group="standard"))
add(appt("A05", "Elena", "Ruiz", "Massage (60 min)", "2026-10-24", None, phone="(555) 010-3405"),
    nosend(["route_to_person"], "route_to_person", "time missing", scenario="missing time", group="standard"))
add(appt("A06", "Grace", "Okafor", "Massage (30 min)", "2026-10-24", "11:30 AM", phone=None, consent=False, email="grace.okafor@example.com"),
    send(["email"], "Grace", ["2026-10-24"], ["11:30"], scenario="missing phone, email on file", group="standard"))
add(appt("A07", "Jamal", "Carter", "Massage (60 min)", "2026-10-23", "2:00 PM", rtype="same_day", phone="(555) 010-3407",
         customer_note="Running late from work, can we push to 2:30? (texted 9:12 AM today)"),
    nosend(["route_to_person"], "route_to_person", "customer asks to move the time; only staff can confirm", scenario="free-text note: running late / push 30 min", group="note"))
add(appt("A08", "Linda", "Park", "Physical therapy initial evaluation", "2026-10-24", "8:45 AM", phone="(555) 010-3408",
         prep="Wear loose, comfortable clothing and bring a list of your current medications. Please arrive 10 minutes early to complete forms."),
    send(["text", "email"], "Linda", ["2026-10-24"], ["08:45"], phrases=[r"loose", r"medication", r"10 minutes"], scenario="prep instructions", group="standard"))
add(appt("A09", "Robert", "Haines", "Counseling session (individual)", "2026-10-24", "5:00 PM", phone="(555) 010-3409", sensitive=True),
    send(["text"], "Robert", ["2026-10-24"], ["17:00"], forbidden=[r"counsel", r"therap", r"mental", r"psych"], scenario="sensitive service", group="standard"))
add(appt("A10", "Sofia", "Marino", "Massage (60 min)", "2026-10-24", "10:00 AM", phone="(555) 010-3410",
         extra_appts=[{"service": "Physical therapy follow-up", "service_sensitive": False, "date": "2026-10-24", "time": "11:30 AM", "format": "in_person", "video_link": None}]),
    send(["text"], "Sofia", ["2026-10-24"], ["10:00", "11:30"], scenario="two bookings same day", group="standard"))
add(appt("A11", "Kevin", "Doyle", "Physical therapy video follow-up", "2026-10-24", "4:00 PM", phone="(555) 010-3411",
         video_link="https://lakesidewellness.example/v/kd2210", cust_tz="America/Los_Angeles"),
    send(["text"], "Kevin", ["2026-10-24"], ["16:00"], phrases=[r"\bET\b|Eastern"], urls=["https://lakesidewellness.example/v/kd2210"],
         extra_allowed_times=["13:00"], scenario="time-zone mismatch (customer in Pacific, video)", group="standard"))
add(appt("A12", "Brianna", "Cole", "Massage (60 min)", "2026-10-24", "2:00 PM", phone="(555) 010-3412", no_shows=3),
    send(["text"], "Brianna", ["2026-10-24"], ["14:00"], phrases=[r"reply\s+[\"'“”‘’]?C\b"], scenario="repeat no-show", group="standard"))
add(appt("A13", "Owen", "Fischer", "Massage (60 min)", "2026-10-24", "12:00 PM", phone="(555) 010-3413",
         customer_note="Is there parking? I've never been there before."),
    send(["text"], "Owen", ["2026-10-24"], ["12:00"], ok=("send", "route_to_person"), scenario="free-text note: parking question (answer is in policy)", group="note"))
add(appt("A14", "Helen", "Brooks", "Massage (60 min)", "2026-10-24", "3:00 PM", phone="(555) 010-3414",
         customer_note="My daughter Mia will come in my place this time, is that OK?"),
    nosend(["route_to_person"], "route_to_person", "change of who attends needs staff", scenario="free-text note: someone else attending", group="note"))
add(appt("A15", "Carlos", "Mendes", "Physical therapy follow-up", "2026-10-24", "9:30 AM", phone="(555) 010-3415", email="carlos.mendes@example.com",
         customer_note="Please don't text me, email only."),
    send(["email"], "Carlos", ["2026-10-24"], ["09:30"], ok=("send", "route_to_person"), scenario="free-text note: text opt-out, consent field still true", group="note"))

# ---------- Invoices (Ridgeway Landscaping) ----------
L = lambda n: f"https://pay.ridgewaylandscaping.example/inv/{n}"
add(inv("P01", "Alan", "Pierce", 1041, "$385.00", "2026-10-26", 0, phone="(555) 010-7801"),
    send(["text"], "Alan", ["2026-10-26"], amounts=["385.00"], phrases=[r"1041"], urls=[L(1041)], scenario="first friendly reminder (due in 3 days)", group="standard"))
add(inv("P02", "Monica", "Reyes", 1007, "$1,140.00", "2026-09-23", 30, phone="(555) 010-7802", reminders_sent=2),
    send(["text"], "Monica", [], amounts=["1140.00"], phrases=[r"1007"], urls=[L(1007)], forbidden=[r"late fee", r"\bfee", r"interest", r"penalt"],
         scenario="30 days overdue, no late-fee terms", group="standard"))
add(inv("P03", "Derek", "Stone", 1019, "$700.00", "2026-10-09", 14, phone="(555) 010-7803", original="$1,200.00", paid="$500.00", reminders_sent=1),
    send(["text"], "Derek", [], amounts=["700.00"], phrases=[r"1019"], urls=[L(1019)], scenario="partial payment", group="standard"))
add(inv("P04", "Nina", "Alvarez", 1023, "$0.00", "2026-10-20", 0, phone="(555) 010-7804", status="paid", original="$640.00", paid="$640.00",
        staff_note=None),
    nosend(["hold", "route_to_person"], "hold", "already paid", scenario="already paid (reminder still queued)", group="standard"))
add(inv("P05", "Greg", "Tanner", 1012, "$2,300.00", "2026-10-02", 21, phone="(555) 010-7805", status="disputed"),
    nosend(["route_to_person"], "route_to_person", "disputed", scenario="disputed invoice", group="standard"))
add(inv("P06", "Wendy", "Cho", 998, "$900.00", "2026-10-26", 0, phone="(555) 010-7806", original="$1,350.00", paid="$450.00",
        plan={"installment_amount": "$150.00", "next_installment_due": "2026-10-26", "installments_remaining": 6, "status": "current"}),
    send(["text"], "Wendy", ["2026-10-26"], amounts=["150.00"], phrases=[r"998"], urls=[L(998)], forbidden=[r"overdue", r"past due", r"late"],
         scenario="payment plan in place", group="standard"))
add(inv("P07", "Luis", "Ortega", 1030, "$1,560.00", "2026-10-02", 21, phone="(555) 010-7807", reminders_sent=1,
        customer_note="I lost my job last month. Can I pay this in two parts?"),
    nosend(["route_to_person"], "route_to_person", "hardship + payment-arrangement request; owner decides", scenario="free-text note: hardship", group="note"))
add(inv("P08", "Janet", "Hartwell", 1002, "$8,450.00", "2026-09-08", 45, phone="(555) 010-7808", company="Hartwell Property Group", reminders_sent=2),
    nosend(["route_to_person"], "route_to_person", "large balance 30+ days overdue -> owner calls", scenario="large balance", group="standard"))
add(inv("P09", "Paul", "Novak", 1035, "$460.00", "2026-10-16", 7, phone="(555) 010-7809",
        staff_note="Called customer 10/20. Agreed the invoice should be $410.00 because one mowing visit was rained out. Correction not entered yet."),
    nosend(["route_to_person"], "route_to_person", "amount in note conflicts with record", scenario="wrong amount: record vs staff note", group="note"))
add(inv("P10", "Rachel", "Dunn", 1044, "$275.00", "2026-10-20", 3, phone="(555) 010-7810", pay_link=None),
    send(["text"], "Rachel", [], amounts=["275.00"], phrases=[r"1044"], phones=["5550107700"], scenario="no pay link on file", group="standard"))
add(inv("P11", "Victor", "Hale", 1009, "$1,800.00", "2026-09-18", 35, phone="(555) 010-7811", reminders_sent=2,
        late_terms="1.5% of the balance per month after 30 days overdue", late_amount="$27.00"),
    send(["text"], "Victor", [], amounts=["1800.00", "27.00"], phrases=[r"1009"], urls=[L(1009)], extra_allowed_amounts=["1827.00"], allow_late_fee=True,
         scenario="late-fee terms present, 35 days overdue", group="standard"))
add(inv("P12", "Ana", "Silva", 1038, "$520.00", "2026-10-21", 2, phone="(555) 010-7812", customer_note="I sent this through Zelle this morning."),
    nosend(["hold", "route_to_person"], "route_to_person", "customer says paid; staff should confirm", scenario="free-text note: says already paid (not recorded)", group="note"))
add(inv("P13", "Martin", "Webb", 1040, "$690.00", "2026-10-30", 0, phone="(555) 010-7813", email="martin.webb@example.com",
        customer_note="Can you email me a copy of the invoice? I can't find it."),
    send(["email", "text"], "Martin", ["2026-10-30"], amounts=["690.00"], phrases=[r"1040"], urls=[L(1040)], ok=("send", "route_to_person"),
         scenario="free-text note: asks for invoice copy (pay link shows invoice)", group="note"))
add(inv("P14", "Karen", "Holt", 1027, "$455.00", "2026-10-09", 14, phone="(555) 010-7814", reminders_sent=1),
    send(["text"], "Karen", [], amounts=["455.00"], phrases=[r"1027"], urls=[L(1027)], scenario="standard second reminder, 14 days overdue", group="standard"))
add(inv("P15", "Rosa", "Delgado", 1033, "$780.00", "2026-10-16", 7, phone="(555) 010-7815",
        customer_note="¿Puedo pagar el viernes? Cobro ese día."),
    nosend(["route_to_person", "hold"], "route_to_person", "promise-to-pay / date question in Spanish; staff decides", scenario="free-text note in Spanish: can I pay Friday?", group="note"))

assert len(R) == 30 and sum(r["record_type"] == "appointment_reminder" for r in R) == 15
json.dump(R, open("records.json", "w"), indent=2, ensure_ascii=False)
json.dump({"today": TODAY, "business_phones": {LW: "5550103300", RL: "5550107700"}, "business_emails": {LW: LW_EMAIL, RL: RL_EMAIL},
           "business_hours_times": {LW: ["08:00", "18:00"], RL: ["08:00", "17:00"]}, "cases": E}, open("expected.json", "w"), indent=2, ensure_ascii=False)
print("records", len(R), "standard", sum(e["group"] == "standard" for e in E.values()), "note", sum(e["group"] == "note" for e in E.values()))
