# EXP-003 deviations log

Pre-run files are locked by `fingerprints.sha256` (written 2026-10-23 17:17:19 EDT). Until 2026-10-23 17:40 EDT, `sha256sum -c fingerprints.sha256` passed on all 8 files. After Ollie's evidence review, design.md (D5) and prompt.md (D6) each got a dated post-run note, so those two now fail the check on purpose. Byte-identical originals are in `evidence/prerun-originals/` and still match the manifest. The other 6 files are unchanged. Everything below is logged with a date and either re-fingerprinted (`fingerprints-postrun.sha256`) or noted as a record-keeping fix.

## D1. Addendum timestamp (record-keeping note, no content change). Logged Fri 23 Oct 2026.
The addendum header in `design.md` says "written Fri 23 Oct 2026, ~17:20 ET". The file's last write was 17:17:12 EDT and the manifest was written at 17:17:19 EDT. So the addendum was finished by 17:17 ET, before the rules run (17:17:23) and the first API call (17:17:27). "~17:20" was a rough estimate. `design.md` stays as it is because it's locked.

## D2. Mechanical scorer v2: business-hours weekdays (written after the run). Logged Fri 23 Oct 2026. score_mechanical_v2.py was written and scores-mechanical-v2.json was produced at 17:22:59 EDT, after the locked scoring at 17:22:00 EDT. (An earlier draft of this line said "~17:35 ET", which was wrong and is corrected here.)
**What happened.** The locked scorer failed 3 of 90 AI outputs: P10 run 2, P13 run 1 and P13 run 2. Each was flagged as `dates_times` failed, `weekday:monday`, which also sets `serious_fact_error` and `invented_content`. In all three, the message gave the office hours, "Monday to Friday, 8 AM to 5 PM". Those hours are a policy fact in prompt.md (line 15). The locked scorer already allowed business-hours *times* (8 AM, 5 PM) but forgot business-hours *weekday names*. "Monday" wasn't a date claim. (Runs that wrote "Mon-Fri" passed, because the extractor only matches full weekday names.)
**What changed.** `score_mechanical_v2.py` is a copy of the locked scorer with three edits, all visible in `diff score_mechanical.py score_mechanical_v2.py`:
1. a `HOURS_DAYS` table, copied from prompt.md lines 11 and 15;
2. one line adding those weekdays to the allowed weekday set;
3. the output filename, which is now `evidence/scores-mechanical-v2.json`.
**Effect.** Exactly those 3 outputs flip from fail to pass. Nothing else changes (checked row by row). Rules results are identical.
**Side effect checked.** v2 would let a wrong weekday through if it fell inside business days. To make up for that, every "Weekday, Month D" pair in all 120 outputs was checked against the 2026 calendar: 83 pairs, 0 mismatches.
**How it's reported.** The locked result (`results.md`, AI 87/90) stays the primary result. The v2 result (`results-v2-deviation.md`, AI 90/90) is shown next to it, labeled as a post-run deviation. The decision rule is applied both ways below.

## D3. tally.py edited after first write. Logged Fri 23 Oct 2026.
tally.py only adds up numbers and was never part of the pre-run fingerprint. After the run I made two edits:
- It now takes the scores file and the output filename as arguments, so the same code produces both results files.
- It prints a note explaining the "extracted" parse category.
No scoring logic changed.

## D4. Judgment scoring conditions (disclosed, not a change to the plan).
The judgment scores in `evidence/scores-judgment.json` come from the site's AI assistant, which also designed the test and wrote the rules script. It scored with full knowledge of which output came from which method (not blind) and after seeing the mechanical results. No human has re-scored anything.

## D5. design.md status line updated after the run. Logged Fri 23 Oct 2026, 17:40 EDT.
Line 2 of design.md said "Status: proposed, awaiting Ollie's sign-off. Nothing has been run." That was out of date after the run. At Ollie's request (evidence review, 23 Oct 2026) it now says the design was signed off and run on 2026-10-23. That status line is the only change. No rubric, rule, record or expected answer changed. The original is kept byte for byte in `evidence/prerun-originals/design.md` (sha256 e536e356…d373, matching the manifest).

## D6. prompt.md: post-run note on thinking blocks, and a correction. Logged Fri 23 Oct 2026, 17:40 EDT.
Every call used the API defaults (no temperature, thinking or effort sent). Those defaults still produced thinking blocks. 25 of 90 raw responses start with a content block of type "thinking" (empty text) before the "text" block: A08 run 2, A11 runs 1 to 3, and runs 1 to 3 of P02, P06, P10, P11, P12, P13 and P15. Those calls reported 10,265 thinking tokens in total. They are counted inside the 28,330 output tokens already used for cost, so the cost ($0.5770) doesn't change. `evidence/run.py` joins only blocks of type "text", so the scored outputs are unaffected.
**Correction.** Earlier write-ups (the Notion entry) said "0 thinking tokens". That was wrong and has been corrected. A note saying the above was appended to prompt.md below a horizontal rule. Nothing above the rule changed. The original is kept byte for byte in `evidence/prerun-originals/prompt.md` (sha256 321604bc…c298, matching the manifest). evidence/README.md step 3 now tells readers to use the first block of type "text".

## D7. Consistency summary corrected (reporting fix, no data change). Logged Fri 23 Oct 2026, 17:40 EDT.
The "5 of 30 cases differed" figure is unchanged, but an earlier summary described the differences as mostly about channel. Checked against `evidence/scores-mechanical.json`: 3 cases (A12, P06, P11) differed only in whether the business phone number was included; 1 (A13) differed only in whether "tomorrow" was written next to the same date; 1 (P13) differed in channel (email in runs 1 and 2, text in run 3). No case differed in decision. The article, results.md hand-written note and Notion entry now say this.

## Decision rule (from the design.md addendum) applied to both scorings
| | Locked scorer (primary) | v2 scorer (deviation D2) |
|---|---|---|
| Standard cases | Rules 21/21. AI 62/63 (P10 run 2 failed) → rule says **recommend rules** | Rules 21/21, AI 63/63 → **tie on accuracy; rules win on cost and predictability** |
| Note cases: AI passes all 27? | No (P13 runs 1 and 2) → AI does **not** "clearly outperform" | Yes |
| Note cases: AI best decision on ≥2 more cases than rules (majority of runs)? | Yes: 3 more (A13, A15, P13) | Yes: 3 more |
| Note cases: higher note-judgment score? | Yes: 1.96 vs 1.67 (JUDGMENT) | Yes |
| Outcome for notes | AI not recommended for notes | AI "clearly outperforms" on notes under the pre-set test |

**What the article does with this.** Both scorings point to rules for standard reminders. The note-case result depends on D2, so the article reports it as a narrower, hedged finding and does not recommend AI auto-sending. Two reasons:
1. The AI's advantage was 3 note cases out of 9.
2. In 1 of 3 runs on P13, the AI ignored an explicit "email me" request. That run passed the mechanical check because the locked expected.json allowed either channel.

The article's recommendation: rules for sending. If you use AI, use it to read free-text notes and draft a staff summary or suggested reply that a person approves.
