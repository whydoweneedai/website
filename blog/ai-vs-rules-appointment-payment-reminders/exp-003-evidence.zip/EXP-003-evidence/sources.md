# Sources: EXP-003 (AI vs. simple rules for reminders)

All web sources were checked on October 23, 2026. Vendor sources are the vendors' own claims, and we did not test them.

## Primary legal sources (cited, not tested)

1. **47 CFR 64.1200, Delivery restrictions** (FCC TCPA rules), Cornell LII. https://www.law.cornell.edu/cfr/text/47/64.1200
   - (a)(1)(iii): prior express consent is required for autodialed or prerecorded/artificial-voice calls to a number assigned to a "cellular telephone service".
   - (a)(9): "As used in this paragraph (a)(9), the term 'call' includes a text message, including a short message service (SMS) call." (a)(9) lists four exemptions: (i) package delivery, (ii) inmate collect call service providers, (iii) financial institutions and (iv) healthcare providers. The 160-characters-or-less limit for texts is a condition of the package-delivery, financial-institution and healthcare exemptions only. The inmate collect-call exemption has no character limit (it says notifications must be "clear and concise, generally one minute or less").
   - (a)(9)(iv): healthcare provider exemption. Messages go only to the wireless number the patient provided. They are limited to purposes including "appointment and exam confirmations and reminders". They "may not include accounting, billing, debt-collection, or other financial content". Limits are 160 characters or less, one message per day and three per week, and every message must offer an easy opt-out.
   - (a)(10): consent may be revoked "by using any reasonable method to clearly express a desire not to receive further calls or text messages". A reply in other words must be treated as revocation "if a reasonable person would understand those words to have conveyed a request to revoke consent". Revocation must be honored "within a reasonable time not to exceed ten business days from receipt of such request".
   - Official PDF (2025 CFR edition, govinfo): https://www.govinfo.gov/content/pkg/CFR-2025-title47-vol3/pdf/CFR-2025-title47-vol3-sec64-1200.pdf
2. **47 U.S.C. 227** (Telephone Consumer Protection Act), Cornell LII. https://www.law.cornell.edu/uscode/text/47/227

The article does not say any message in the test was or wasn't compliant. Whether a particular texting system counts as an "automatic telephone dialing system" is a legal question we did not address.

## Vendor claims (not tested)

3. **Square Appointments, "Manage appointment booking notifications and reminders".** Square says clients can get confirmations, reminders and notifications by text, email or both, and that you pick a time frame before the appointment from a drop-down. This page does not state the range. https://squareup.com/help/us/en/article/6729-customer-confirmations-with-square-appointments
   - **Square, "Adjust your appointment settings"** (US support center), for the timing range: "choose when to send a text message reminder between one hour prior or three days prior to the appointment", and the same for email reminders. Rechecked 23 Oct 2026. https://squareup.com/help/us/en/article/5351-manage-your-square-appointments-account-settings
4. **QuickBooks, send invoice reminders automatically or manually.** Intuit says you can set up to three automatic email reminders, up to 90 days before or after the due date. https://quickbooks.intuit.com/learn-support/en-us/help-article/invoicing/send-invoice-reminders-automatically-manually/L84cQjpxo_US_en_US
5. **QuickBooks, "Get started with the Payments AI"** (page title rechecked 23 Oct 2026; Intuit's page says "Updated 8/5/2026"; the URL still says payments-agent). Intuit says Payments AI "suggests a specific schedule for invoice reminders, which you can review before approving" and "writes an editable message for all invoice reminders". https://quickbooks.intuit.com/learn-support/en-us/help-article/intuit-assist/get-started-payments-agent/L5y4ix9cA_US_en_US

## Model and pricing

6. **Anthropic pricing.** Claude Sonnet 5.5 costs $2 per million input tokens and $10 per million output tokens. Checked October 23, 2026. https://platform.claude.com/docs/en/about-claude/pricing
7. **Model string.** `claude-sonnet-5-5` was requested, and the API returned that model string on all 90 calls (see evidence/ai-outputs.json, field `model`).

## Test evidence (this folder)

8. design.md, prompt.md, records.json, expected.json, build_records.py, rules.py, score_mechanical.py and evidence/run.py were locked before the run (fingerprints.sha256, 2026-10-23 17:17:19 EDT).
9. evidence/results.md has the primary results (locked scorer). evidence/results-v2-deviation.md has the corrected-scorer results (deviation D2). deviations.md lists D1 to D7.
10. evidence/raw/ has the 90 raw API request/response files. evidence/scores-judgment.json has the judgment scores (AI assistant, labeled as judgment).
