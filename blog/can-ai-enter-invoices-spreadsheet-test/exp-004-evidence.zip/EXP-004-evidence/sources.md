# EXP-004 sources

All checked 2026-10-23.

## Anthropic API (used to run the test)
- Thinking, per-model settings table and the Sonnet 5.5 `between_tools` note: https://platform.claude.com/docs/en/build-with-claude/thinking ("Claude Sonnet 5.5 ... rejects thinking: {type: "disabled"} with a 400 error. To turn off up-front thinking, send thinking: {type: "between_tools"} instead. It's the lowest thinking setting on Claude Sonnet 5.5, and it's accepted at effort high or below.")
- Extended thinking (budget_tokens): https://platform.claude.com/docs/en/build-with-claude/extended-thinking
- Structured outputs (`output_config.format`, json_schema): https://platform.claude.com/docs/en/build-with-claude/structured-outputs
- PDF support (document blocks): https://platform.claude.com/docs/en/build-with-claude/pdf-support
- Pricing ($2 / $10 per million input / output tokens for Claude Sonnet 5.5): https://platform.claude.com/docs/en/about-claude/pricing

## Vendor tools (vendor claims only, not tested)
- QuickBooks Online, "Email receipts and bills": https://quickbooks.intuit.com/learn-support/en-us/help-article/accounts-payable/email-receipts-bills-quickbooks-online/L7r2LAQ7C_US_en_US. Claim: QuickBooks "automatically pulls dates, amounts, vendor, and last four digits of the credit card from the image", then you review it in Receipts.
- Xero, "Smart Document Capture" (UK): https://www.xero.com/uk/accounting-software/store-files/ (the earlier URL /uk/accounting-software/capture-data-with-hubdoc/ now 301-redirects here; re-checked 2026-10-23 ~18:35 ET). Quoted claims: photograph a receipt and "Xero then captures the amount, date, and other details automatically"; "Double-check and approve the info before Xero creates a financial record". The earlier quote ("supplier names, amounts, invoice numbers and due dates" / draft transactions) is not on the current page and was removed from the article.
- Hubdoc upload guide: https://content.hubdoc.com/getstarted/upload-paper-and-digital-documents. Claim: for accurate extraction "the date, supplier name, and amount must be clearly visible".
- Xero Central, "Publish Hubdoc documents to Xero": https://central.xero.com/0/article/Publish-Hubdoc-documents-to-Xero-US-GL. Describes confirming extracted data before publishing, and optional Autosync.

## Local tools
- Tesseract OCR 5.5.0 (`--psm 6`), poppler-utils pdftotext/pdftoppm, reportlab, Pillow, numpy. Handwriting font: Caveat Brush (Google Fonts, OFL).
