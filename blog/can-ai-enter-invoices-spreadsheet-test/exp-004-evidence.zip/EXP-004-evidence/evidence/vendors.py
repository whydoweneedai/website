"""EXP-004 synthetic vendors. All names, addresses, phones and domains are made up.
Phones use 555-01xx, domains use .example. Not real companies."""

CUSTOMER = ["Copper Kettle Cafe (synthetic customer)", "22 Example Lane", "Millbrook, ST 00000"]

VENDORS = {
    "V1": {"name": "Brightwater Paper Supply", "layout": "L1", "currency": "USD",
           "addr": ["1180 Quarry Row, Suite 4", "Ashcombe, ST 00001", "Tel 555-0141"],
           "web": "brightwater-paper.example", "tax": [("Sales Tax (8.25%)", "0.0825")], "tax_type": "sales_tax"},
    "V6": {"name": "Northgate Studio Supplies", "layout": "L1", "currency": "USD",
           "addr": ["orders@northgate-studio.example", "northgate-studio.example"],
           "web": "northgate-studio.example", "tax": [("Sales Tax (7.00%)", "0.07")], "tax_type": "sales_tax"},
    "V2": {"name": "Kestrel Hill Coffee Roasters", "layout": "L2", "currency": "USD",
           "addr": ["40 Larkspur Yard, Fenwick, ST 00002", "555-0162 | kestrelhill.example"],
           "web": "kestrelhill.example", "tax": [("Tax (6%)", "0.06")], "tax_type": "sales_tax"},
    "V3": {"name": "Ostrander Plumbing Parts", "layout": "L3", "currency": "USD",
           "addr": ["9 Foundry Street", "Halvern, ST 00003", "555-0177"],
           "web": "ostrander-parts.example", "tax": [("Sales tax 7.5%", "0.075")], "tax_type": "sales_tax"},
    "V5": {"name": "Maple Ridge Print Co.", "layout": "L3", "currency": "CAD",
           "addr": ["310 Cedarline Avenue", "Port Alder, BC V0V 0V0", "555-0193"],
           "web": "mapleridgeprint.example", "tax": [("GST 5%", "0.05"), ("PST 7%", "0.07")], "tax_type": "GST_PST"},
    "V4": {"name": "Vellmar Packaging B.V.", "layout": "L4", "currency": "EUR",
           "addr": ["Kadeweg 17", "0000 XX Oostvliet", "Tel +00 555 0188"],
           "web": "vellmar-packaging.example", "tax": [("VAT 21%", "0.21")], "tax_type": "VAT"},
}
