# EXP-004 evidence

Synthetic test, 2026-10-23 (ET). Every invoice, vendor, customer and ledger entry is invented. Handwriting is a font overlay (Caveat Brush) on a simulated scan. No real business data.

## Order of work (ET)
1. 18:04:55 rules.py locked (rules-lock.sha256) after writing it against only the 4 dev invoices (C1, C3, C5, C6). cases_heldout.py did not exist yet.
2. Held-out cases written, all 24 rendered (gen.py), expected.json written, context.json (vendor list, ledger) written.
3. Smoke call and thinking probes (smoke/), rules dry run (prerun-dryrun/). See ../deviations.md P1-P3.
4. 18:11:15 ../fingerprints.sha256 written; files made read-only.
5. 18:11:26 official rules run (rules-run.txt; two runs byte-identical, identical to the dry run).
6. 18:11:32-18:16:01 72 AI calls (run.py), claude-sonnet-5-5, thinking {"type":"between_tools"}, effort high, max_tokens 8000, structured JSON output. All HTTP 200, end_turn, 0 retries, 0 thinking tokens.
7. 18:16:15 score.py and tally.py (first output: scoring-check/tally-first-run-output.txt); judgment scores 18:18. scores-mechanical.json mtime is 18:20:39 from a byte-identical reproducibility re-run of score.py (see ../deviations.md D3).

## Files
- gen.py, vendors.py, cases_dev.py, cases_heldout.py: invoice generator and case definitions.
- inputs/: 17 PDFs, S1-S4 .jpg (simulated scans), H1-H3 .png (simulated handwriting).
- expected.json (24 cases incl. trap/credit/duplicate correctness rules), expected-dev.json, context.json.
- rules.py, rules-lock.sha256, rules-dev-tests/, rules-outputs.json, rules-run.txt.
- ../prompt.md (system prompt, user template, JSON schema), run.py, raw/ (72 files: request body with the file replaced by its sha256, thinking setting, effort, response), ai-outputs.json, run-log.json, run-stdout.txt.
- smoke/: SMOKE-run1.json, smoke-dummy.png, probe_thinking.py, thinking-probes.json.
- score.py -> scores-mechanical.json (primary). tally.py -> tally-output.txt. scores-judgment.json (JUDGMENT, AI assistant, not blind).
- results.md: all tables.
- prerun-dryrun/: disclosed rules dry run. prerun-originals/: tally.py before deviation D2.

## Verify
    cd invoices-ai-to-spreadsheet
    grep -v '^#' fingerprints.sha256 | sha256sum -c          # all OK except evidence/tally.py (D2)
    grep -v '^#' fingerprints-postrun.sha256 | sha256sum -c   # all OK
    cd evidence && python3 rules.py --all && python3 score.py && python3 tally.py

The API key is not in any file. Raw request files omit the base64 file data and the key.
