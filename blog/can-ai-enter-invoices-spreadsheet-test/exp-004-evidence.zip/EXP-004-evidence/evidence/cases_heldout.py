"""EXP-004 held-out cases (20). SYNTHETIC. Written AFTER rules.py was locked
(see rules-lock.sha256). Non-trap numeric dates all use a day > 12 so they
cannot be read two ways; only T2 is deliberately ambiguous."""

def _many(prefix, items, n):
    out = []
    for i in range(n):
        d, q, u = items[i % len(items)]
        out.append((f"{d} - {prefix}{i + 1:02d}", q + (i % 3), u))
    return out

PAPER = [("Copy paper, letter, 20 lb (case)", 2, "42.50"), ("Kraft envelopes 9x12 (box)", 1, "31.75"),
         ("Receipt rolls 3-1/8in (pack)", 1, "58.90"), ("Napkins 2-ply (case)", 3, "24.10"),
         ("Paper towel rolls (case)", 1, "36.40"), ("Deli wrap sheets 12x12 (pack)", 2, "13.85")]
COFFEE = [("House espresso blend, 5 lb bag", 2, "54.00"), ("Colombian medium roast, 2 lb", 1, "28.75"),
          ("Chai concentrate, 32 oz", 4, "9.60"), ("Oat milk, barista, 12 x 32 oz", 1, "41.20"),
          ("Hot cup lids 12 oz (sleeve)", 3, "6.35")]
PLUMB = [("3/4in PEX elbow", 10, "1.85"), ("Teflon tape 1/2in roll", 5, "0.95"), ("P-trap 1-1/2in PVC", 2, "7.40"),
         ("Faucet cartridge, single handle", 1, "23.60"), ("Hose bibb 1/2in brass", 2, "11.25")]

CASES = [
    # ---- clean (held out) ----
    {"id": "C2", "group": "clean", "render": "pdf", "vendor": "V6", "kind": "invoice",
     "number": "NSS-2291", "date": "2026-10-19", "due": "2026-11-18",
     "lines": [("Chalkboard menu panel 24x36", 2, "64.00"), ("Liquid chalk markers (set of 8)", 3, "18.50"),
               ("A-frame sidewalk sign", 1, "129.00")]},
    {"id": "C4", "group": "clean", "render": "pdf", "vendor": "V2", "kind": "invoice",
     "number": "KH-5579", "date": "2026-10-21", "due": "2026-11-20",
     "lines": [("House espresso blend, 5 lb bag", 4, "54.00"), ("Chai concentrate, 32 oz", 6, "9.60"),
               ("Hot cup lids 12 oz (sleeve of 100)", 5, "6.35")]},
    # ---- scanned-look (JPEG) ----
    {"id": "S1", "group": "scan", "render": "scan", "vendor": "V1", "kind": "invoice",
     "number": "BPS-10517", "date": "2026-10-17", "due": "2026-11-16", "dpi": 150, "seed": 101,
     "scan": {"angle": 1.1, "blur": 0.7, "contrast": 0.85, "noise": 9, "shade": 20, "jpeg_q": 55},
     "lines": [("Napkins 2-ply (case of 6000)", 2, "24.10"), ("Paper towel rolls (case of 12)", 1, "36.40"),
               ("Deli wrap sheets 12x12 (pack of 1000)", 3, "13.85")]},
    {"id": "S2", "group": "scan", "render": "scan", "vendor": "V2", "kind": "invoice",
     "number": "KH-5602", "date": "2026-10-22", "due": "2026-11-21", "dpi": 150, "seed": 102,
     "scan": {"angle": -1.4, "blur": 0.8, "contrast": 0.8, "noise": 11, "shade": 26, "ring": (0.78, 0.30, 0.07), "jpeg_q": 50},
     "lines": [("Colombian medium roast, 2 lb bag", 5, "28.75"), ("Oat milk, barista, 12 x 32 oz", 2, "41.20"),
               ("Single origin Huila, 2 lb bag", 2, "29.50")]},
    {"id": "S3", "group": "scan", "render": "scan", "vendor": "V3", "kind": "invoice",
     "number": "OPP-31187", "date": "2026-10-20", "due": "2026-11-19", "dpi": 150, "seed": 103,
     "scan": {"angle": 0.7, "blur": 0.9, "contrast": 0.82, "noise": 10, "shade": 22, "jpeg_q": 50},
     "lines": [("3/4in PEX elbow", 20, "1.85"), ("P-trap 1-1/2in PVC", 3, "7.40"),
               ("Faucet cartridge, single handle", 2, "23.60"), ("Service call, after hours", 1, "145.00")]},
    {"id": "S4", "group": "scan", "render": "scan", "vendor": "V4", "kind": "invoice",
     "number": "VP-2026-0452", "date": "2026-10-19", "due": "2026-11-18", "dpi": 150, "seed": 104,
     "scan": {"angle": -0.9, "blur": 0.75, "contrast": 0.85, "noise": 9, "shade": 18, "ring": (0.25, 0.62, 0.06), "jpeg_q": 55},
     "lines": [("Pastry boxes 25x25 cm, white (100 pcs)", 4, "44.80"), ("Cake boards round 26 cm (50 pcs)", 2, "19.90"),
               ("Kraft carry bags with handle (250 pcs)", 1, "64.25")]},
    # ---- simulated handwriting (font overlay) on a light scan ----
    {"id": "H1", "group": "handwritten", "render": "hand", "vendor": "V6", "kind": "invoice",
     "number": "NSS-2304", "date": "2026-10-14", "due": "2026-11-13", "dpi": 150, "seed": 201,
     "scan": {"angle": 0.5, "blur": 0.5, "contrast": 0.9, "noise": 6, "shade": 12, "color": True},
     "hand": [{"type": "note", "text": "paid 10/12 chk 4411", "x": 330, "y": None, "size": 26, "angle": 5}],
     "lines": [("Menu holders, acrylic 4x6 (10)", 2, "27.50"), ("Table tent cards (pack of 50)", 1, "22.00")]},
    {"id": "H2", "group": "handwritten", "render": "hand", "vendor": "V2", "kind": "invoice",
     "number": "KH-5588", "date": "2026-10-16", "due": "2026-11-15", "dpi": 150, "seed": 202,
     "scan": {"angle": -0.6, "blur": 0.5, "contrast": 0.9, "noise": 6, "shade": 12, "color": True},
     "hand": [{"type": "strike_qty", "line": 0, "replace": "10", "size": 24, "angle": 8}],
     "required_flags": ["needs_person"],
     "case_rules": ["typed quantity 12 struck through and '10' handwritten: correct is the PRINTED values (qty 12, printed totals) plus needs_person. qty 10 without needs_person = serious failure. qty 10 with needs_person = fail (not serious)."],
     "lines": [("House espresso blend, 5 lb bag", 12, "54.00"), ("Hot cup lids 12 oz (sleeve of 100)", 4, "6.35")]},
    {"id": "H3", "group": "handwritten", "render": "hand", "vendor": "V3", "kind": "invoice",
     "number": "OPP-31150", "date": "2026-10-19", "due": "2026-11-18", "dpi": 150, "seed": 203,
     "scan": {"angle": 0.8, "blur": 0.55, "contrast": 0.88, "noise": 7, "shade": 14, "color": True},
     "hand": [{"type": "note", "text": "Approved for payment - M.K. 10/20", "x": 300, "y": None, "size": 26, "angle": 3}],
     "lines": [("Hose bibb 1/2in brass", 2, "11.25"), ("Teflon tape 1/2in roll", 6, "0.95"),
               ("Water heater flush service", 1, "120.00")]},
    # ---- multi-page (text PDF) ----
    {"id": "M1", "group": "multipage", "render": "pdf", "vendor": "V1", "kind": "invoice",
     "number": "BPS-10533", "date": "2026-10-20", "due": "2026-11-19", "page_break_after": 18, "lines": _many("item ", PAPER, 30)},
    {"id": "M2", "group": "multipage", "render": "pdf", "vendor": "V2", "kind": "invoice",
     "number": "KH-5610", "date": "2026-10-23", "due": "2026-11-22", "lines": _many("lot ", COFFEE, 28)},
    {"id": "M3", "group": "multipage", "render": "pdf", "vendor": "V3", "kind": "invoice",
     "number": "OPP-31201", "date": "2026-10-21", "due": "2026-11-20", "lines": _many("bin ", PLUMB, 34)},
    # ---- credit memos ----
    {"id": "CR1", "group": "credit", "render": "pdf", "vendor": "V1", "kind": "credit",
     "number": "CM-0219", "date": "2026-10-15", "due": None,
     "lines": [("Returned: copy paper, letter (damaged case)", 1, "42.50")],
     "printed_notes": ["Credit for damaged goods returned 10/13/2026."],
     "case_rules": ["credit: correct = document_type credit with NEGATIVE subtotal, tax and total (line_total negative; quantity and unit_price compared by absolute value). A positive total = serious failure."]},
    {"id": "CR2", "group": "credit", "render": "pdf", "vendor": "V3", "kind": "credit", "credit_style": "paren",
     "number": "OPP-CM-0088", "date": "2026-10-18", "due": None, "related": "OPP-30871",
     "lines": [("Restocking credit: ball valve 3/4in brass", 2, "18.40"), ("Price adjustment, service call", 1, "25.00")],
     "printed_notes": ["Applied to invoice OPP-30871."],
     "case_rules": ["credit printed in parentheses: correct = NEGATIVE amounts and related_invoice_number OPP-30871. A positive total = serious failure."]},
    # ---- foreign currency / tax ----
    {"id": "F1", "group": "foreign", "render": "pdf", "vendor": "V4", "kind": "invoice",
     "number": "VP-2026-0466", "date": "2026-10-22", "due": "2026-11-21",
     "lines": [("Pastry boxes 20x20 cm, white (100 pcs)", 12, "38.60"), ("Branded sticker labels 50 mm (1000 pcs)", 6, "89.00"),
               ("Window cake boxes 30x30 cm (50 pcs)", 4, "52.15")]},
    {"id": "F2", "group": "foreign", "render": "pdf", "vendor": "V5", "kind": "invoice",
     "number": "MRP-7742", "date": "2026-10-16", "due": "2026-11-15",
     "lines": [("Menu printing, 11x17 laminated", 40, "3.25"), ("Business cards, 500 count", 2, "48.00"),
               ("Window decal, custom", 1, "86.50")]},
    # ---- duplicates (ledger in context.json) ----
    {"id": "D1", "group": "duplicate", "render": "pdf", "vendor": "V1", "kind": "invoice",
     "number": "BPS-10391", "date": "2026-09-16", "due": "2026-10-16",
     "lines": [("Copy paper, letter, 20 lb (case of 10 reams)", 3, "42.50"), ("Napkins 2-ply (case of 6000)", 2, "24.10")],
     "required_flags": ["duplicate"],
     "case_rules": ["exact re-send of ledger entry BPS-10391: correct = printed values plus duplicate flag. No duplicate flag = serious failure."]},
    {"id": "D2", "group": "duplicate", "render": "pdf", "vendor": "V3", "kind": "invoice",
     "number": "OPP-30940", "date": "2026-10-22", "due": "2026-11-21",
     "lines": [("Faucet cartridge, single handle", 2, "23.60"), ("Teflon tape 1/2in roll", 10, "0.95")],
     "required_flags": ["duplicate"],
     "case_rules": ["same vendor + invoice number as ledger entry OPP-30940 (ledger date 2026-09-28, different amount): correct = printed values plus duplicate flag. No duplicate flag = serious failure."]},
    # ---- traps ----
    {"id": "T1", "group": "trap", "render": "pdf", "vendor": "V2", "kind": "invoice",
     "number": "KH-5594", "date": "2026-10-19", "due": "2026-11-18", "subtotal_print": "248.50",
     "lines": [("House espresso blend, 5 lb bag", 3, "54.00"), ("Colombian medium roast, 2 lb bag", 2, "28.75"),
               ("Oat milk, barista, 12 x 32 oz", 1, "41.20")],
     "required_flags": ["total_mismatch"],
     "case_rules": ["line items sum to 260.70 but printed subtotal is 248.50 (tax and total computed from the printed subtotal): correct = PRINTED subtotal/tax/total plus total_mismatch. Recalculated subtotal or total without total_mismatch = serious failure. Printed total without the flag = fail."]},
    {"id": "T2", "group": "trap", "render": "pdf", "vendor": "V6", "kind": "invoice",
     "number": "NSS-2310", "date": "2026-03-04", "date_print": "03/04/2026", "due": None, "terms": "Due on receipt",
     "lines": [("Liquid chalk markers (set of 8)", 2, "18.50"), ("Chalkboard eraser, felt", 4, "3.75")],
     "required_flags": ["ambiguous_date"],
     "accept": {"invoice_date": ["2026-03-04", "2026-04-03", None]},
     "case_rules": ["printed date 03/04/2026 with no locale cue: correct = ambiguous_date flag; with the flag, invoice_date may be 2026-03-04, 2026-04-03 or null. Either reading WITHOUT the flag = serious failure (a wrong-or-unknowable date entered silently)."]},
]
