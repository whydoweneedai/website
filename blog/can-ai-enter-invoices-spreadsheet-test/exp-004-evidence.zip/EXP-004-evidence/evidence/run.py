"""EXP-004 AI runner. 24 invoices x 3 independent runs = 72 calls to the Anthropic Messages API.
System prompt, user text and JSON schema are read verbatim from ../prompt.md (fenced blocks 1-3).
Inputs from inputs/; vendor list and ledger from context.json. expected*.json is never read.
The API key is read from the ANTHROPIC_API_KEY environment variable and is never printed or written.
Saved request bodies contain no headers; the base64 file data in each saved body is replaced by a
placeholder naming the file and its sha256 (the bytes sent are inputs/<file>, fingerprinted pre-run).
Thinking is set explicitly: {"type": "between_tools"} (lowest setting Sonnet 5.5 accepts), effort "high".
Cost cap: stops if estimated spend passes $8.00 (Sonnet 5.5 list price $2/MTok input, $10/MTok output, checked 2026-10-23).
Usage: python3 run.py            # all 72 calls
       python3 run.py --smoke    # ONE pre-run call on a dummy text-only document (not an invoice); writes smoke/
"""
import base64, hashlib, json, os, re, sys, time, datetime, urllib.request, urllib.error
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
md = open(os.path.join(ROOT, "prompt.md"), encoding="utf-8").read()
SYSTEM, USER_T = re.findall(r"```text\n(.*?)\n```", md, re.S)[:2]
SCHEMA = json.loads(re.findall(r"```json\n(.*?)\n```", md, re.S)[0])
MODEL, MAX_TOKENS, RUNS = "claude-sonnet-5-5", 8000, 3
THINKING = {"type": "between_tools"}
EFFORT = "high"
PRICE_IN, PRICE_OUT, CAP = 2.00, 10.00, 8.00
ORDER = ["C1", "C2", "C3", "C4", "C5", "C6", "S1", "S2", "S3", "S4", "H1", "H2", "H3", "M1", "M2", "M3",
         "CR1", "CR2", "F1", "F2", "D1", "D2", "T1", "T2"]
ctx = json.load(open(os.path.join(HERE, "context.json"), encoding="utf-8"))
USER = USER_T.replace("{VENDORS_JSON}", json.dumps(ctx["known_vendors"])).replace("{LEDGER_JSON}", json.dumps(ctx["ledger"], indent=1))


def call(body):
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=json.dumps(body).encode(), method="POST",
        headers={"x-api-key": os.environ["ANTHROPIC_API_KEY"], "anthropic-version": "2023-06-01", "content-type": "application/json"})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=300) as r: return r.status, json.loads(r.read()), attempt
        except urllib.error.HTTPError as e:
            txt = e.read().decode("utf-8", "replace")
            if e.code in (429, 500, 502, 503, 529) and attempt < 3: time.sleep(15 * (attempt + 1)); continue
            try: return e.code, json.loads(txt), attempt
            except Exception: return e.code, {"error_text": txt[:2000]}, attempt
        except Exception as e:
            if attempt < 3: time.sleep(15); continue
            return None, {"error_text": type(e).__name__ + ": " + str(e)[:500]}, attempt


def file_block(path):
    data = open(path, "rb").read()
    ext = path.rsplit(".", 1)[1].lower()
    b64 = base64.standard_b64encode(data).decode()
    if ext == "pdf":
        blk = {"type": "document", "source": {"type": "base64", "media_type": "application/pdf", "data": b64}}
    else:
        blk = {"type": "image", "source": {"type": "base64", "media_type": "image/jpeg" if ext in ("jpg", "jpeg") else "image/png", "data": b64}}
    return blk, hashlib.sha256(data).hexdigest()


def make_body(blk, user_text):
    return {"model": MODEL, "max_tokens": MAX_TOKENS, "system": SYSTEM, "thinking": THINKING,
            "output_config": {"effort": EFFORT, "format": {"type": "json_schema", "schema": SCHEMA}},
            "messages": [{"role": "user", "content": [blk, {"type": "text", "text": user_text}]}]}


def saved_body(body, fname, sha):
    b = json.loads(json.dumps(body))
    b["messages"][0]["content"][0]["source"]["data"] = f"<base64 of {fname}, sha256 {sha}, omitted from the saved copy>"
    return b


def one(cid, run, path, outdir, user_text=USER):
    blk, sha = file_block(path)
    body = make_body(blk, user_text)
    sent = datetime.datetime.now().astimezone().isoformat(timespec="seconds")
    status, resp, retries = call(body)
    recd = datetime.datetime.now().astimezone().isoformat(timespec="seconds")
    u = resp.get("usage", {}) if isinstance(resp, dict) else {}
    cost = u.get("input_tokens", 0) / 1e6 * PRICE_IN + u.get("output_tokens", 0) / 1e6 * PRICE_OUT
    text = "".join(b.get("text", "") for b in resp.get("content", []) if b.get("type") == "text") if isinstance(resp, dict) else ""
    btypes = [b.get("type") for b in resp.get("content", [])] if isinstance(resp, dict) else []
    json.dump({"case_id": cid, "run": run, "sent_at": sent, "received_at": recd, "http_status": status, "retries": retries,
               "thinking_setting": THINKING, "effort": EFFORT, "input_file": os.path.relpath(path, HERE), "input_sha256": sha,
               "request_body": saved_body(body, os.path.basename(path), sha), "response": resp, "est_cost_usd": round(cost, 6)},
              open(os.path.join(outdir, f"{cid}-run{run}.json"), "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    return status, resp, retries, u, cost, text, btypes, sent


if __name__ == "__main__":
    if "--smoke" in sys.argv:
        os.makedirs(os.path.join(HERE, "smoke"), exist_ok=True)
        dummy = os.path.join(HERE, "smoke", "smoke-dummy.png")
        r = one("SMOKE", 1, dummy, os.path.join(HERE, "smoke"),
                user_text="This is a configuration test image, not an invoice. Return the JSON object with vendor_name \"none\", nulls where allowed, empty line_items, and needs_person true.")
        print("smoke status", r[0], "blocks", r[6], "stop", r[1].get("stop_reason") if isinstance(r[1], dict) else None,
              "usage", r[3], "cost", round(r[4], 5))
        print("text", r[5][:600])
        if r[0] != 200:
            print("error", json.dumps(r[1])[:800])
        sys.exit(0)
    os.makedirs(os.path.join(HERE, "raw"), exist_ok=True)
    files = {os.path.splitext(f)[0]: os.path.join(HERE, "inputs", f) for f in os.listdir(os.path.join(HERE, "inputs"))}
    outputs, log, spent = [], [], 0.0
    for run in range(1, RUNS + 1):
        for cid in ORDER:
            if spent > CAP: print("COST CAP HIT, stopping"); sys.exit(2)
            status, resp, retries, u, cost, text, btypes, sent = one(cid, run, files[cid], os.path.join(HERE, "raw"))
            spent += cost
            model = resp.get("model") if isinstance(resp, dict) else None
            stop = resp.get("stop_reason") if isinstance(resp, dict) else None
            outputs.append({"case_id": cid, "run": run, "http_status": status, "model": model, "stop_reason": stop,
                            "content_block_types": btypes, "usage": u, "raw_text": text})
            log.append({"case_id": cid, "run": run, "http_status": status, "retries": retries, "model": model,
                        "input_tokens": u.get("input_tokens"), "output_tokens": u.get("output_tokens"), "stop_reason": stop,
                        "content_block_types": btypes, "est_cost_usd": round(cost, 6), "sent_at": sent})
            print(f"run{run} {cid} status={status} model={model} stop={stop} blocks={btypes} in={u.get('input_tokens')} out={u.get('output_tokens')} cost=${cost:.4f} total=${spent:.4f}", flush=True)
            json.dump(outputs, open(os.path.join(HERE, "ai-outputs.json"), "w", encoding="utf-8"), indent=2, ensure_ascii=False)
            json.dump(log, open(os.path.join(HERE, "run-log.json"), "w", encoding="utf-8"), indent=2)
    print(f"DONE calls={len(outputs)} est_total=${spent:.4f}")
