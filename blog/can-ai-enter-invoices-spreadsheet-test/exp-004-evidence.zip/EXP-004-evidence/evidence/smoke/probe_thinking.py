"""Pre-run config probe (no invoice): which thinking settings claude-sonnet-5-5 accepts.
Key from ANTHROPIC_API_KEY env, never printed or saved. Saves request bodies and responses only."""
import json, os, urllib.request, urllib.error, datetime
HERE = os.path.dirname(os.path.abspath(__file__))
probes = {"disabled": {"type": "disabled"}, "enabled_budget": {"type": "enabled", "budget_tokens": 1024},
          "between_tools": {"type": "between_tools"}}
out = []
for name, th in probes.items():
    body = {"model": "claude-sonnet-5-5", "max_tokens": 2000, "thinking": th,
            "messages": [{"role": "user", "content": "Configuration probe. Reply with the word ok."}]}
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=json.dumps(body).encode(), method="POST",
        headers={"x-api-key": os.environ["ANTHROPIC_API_KEY"], "anthropic-version": "2023-06-01", "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=120) as r: st, resp = r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        st, resp = e.code, json.loads(e.read().decode())
    out.append({"probe": name, "at": datetime.datetime.now().astimezone().isoformat(timespec="seconds"), "request_body": body, "http_status": st, "response": resp})
    print(name, st, json.dumps(resp.get("error", resp.get("usage")))[:300])
json.dump(out, open(os.path.join(HERE, "thinking-probes.json"), "w"), indent=2)
