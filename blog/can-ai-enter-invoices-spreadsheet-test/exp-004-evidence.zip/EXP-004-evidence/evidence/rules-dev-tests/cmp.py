import json,sys
exp=json.load(open('expected-dev.json'))['cases']
for c in ['C1','C3','C5','C6']:
    r=json.load(open(f'/tmp/e4/r_{c}{sys.argv[1] if len(sys.argv)>1 else ""}.json')); e=exp[c]
    for k in ['vendor_name','invoice_number','document_type','invoice_date','due_date','currency','subtotal','tax_amount','tax_type','total']:
        if str(r[k])!=str(e[k]): print(c,k,r[k],e[k])
    for a,b in zip(r['line_items'],e['line_items']):
        for k in a:
            if str(a[k]).lower()!=str(b[k]).lower(): print(c,'line',k,repr(a[k]),repr(b[k]))
    if len(r['line_items'])!=len(e['line_items']): print(c,'nlines',len(r['line_items']))
    print(c,r['flags'],r['notes'])
