"""EXP-004 rules baseline: pdftotext (text PDFs) or Tesseract OCR (images) + regex.
Written and locked while looking ONLY at the 4 dev invoices (C1, C3, C5, C6).
Applies the same written policies the AI prompt states (credit -> negative,
duplicate vs ledger, total mismatch -> keep printed + flag, ambiguous numeric
date -> flag and leave null, anything unparsed -> needs_person).

Usage: python3 rules.py <input file> [more files...]   -> JSON per file on stdout
       python3 rules.py --all                          -> writes rules-outputs.json
"""
import difflib, json, os, re, subprocess, sys, glob
from decimal import Decimal, InvalidOperation

HERE = os.path.dirname(os.path.abspath(__file__))
MONTHS = {m: i + 1 for i, m in enumerate(["january", "february", "march", "april", "may", "june", "july",
                                          "august", "september", "october", "november", "december"])}


def load_context():
    with open(os.path.join(HERE, "context.json")) as f:
        return json.load(f)


def get_text(path):
    if path.lower().endswith(".pdf"):
        return subprocess.run(["pdftotext", "-layout", path, "-"], capture_output=True, text=True, check=True).stdout, "pdftotext"
    out = subprocess.run(["tesseract", path, "stdout", "--psm", "6"], capture_output=True, text=True, check=True).stdout
    out = re.sub(r"\bIb\b", "lb", out)  # common OCR confusion seen on dev rasters
    return out, "tesseract"


def parse_amount(tok, comma_decimal):
    t = tok.strip().replace("$", "").replace("EUR", "").replace(" ", "")
    neg = False
    if t.startswith("(") and t.endswith(")"):
        neg, t = True, t[1:-1]
    if t.startswith("-"):
        neg, t = True, t[1:]
    t = t.rstrip(".:")  # OCR stray punctuation after a number
    if comma_decimal or re.fullmatch(r"\d+,\d{2}", t):  # "185,00" in a dot-decimal doc is an OCR comma
        t = t.replace(".", "").replace(",", ".")
    else:
        t = t.replace(",", "")
    if not re.fullmatch(r"\d+(\.\d+)?", t):
        return None
    try:
        v = Decimal(t)
    except InvalidOperation:
        return None
    return -v if neg else v


NUM_TOKEN = r"[-(]?\$?\d[\d.,]*\)?"


def parse_date(s):
    """Return (iso or None, ambiguous: bool)."""
    if not s:
        return None, False
    s = s.strip()
    m = re.search(r"(\d{4})-(\d{2})-(\d{2})", s)
    if m:
        return f"{m.group(1)}-{m.group(2)}-{m.group(3)}", False
    m = re.search(r"([A-Za-z]+)\s+(\d{1,2}),\s*(\d{4})", s)
    if m and m.group(1).lower() in MONTHS:
        return f"{m.group(3)}-{MONTHS[m.group(1).lower()]:02d}-{int(m.group(2)):02d}", False
    m = re.search(r"(\d{1,2})\.(\d{1,2})\.(\d{4})", s)
    if m:
        return f"{m.group(3)}-{int(m.group(2)):02d}-{int(m.group(1)):02d}", False
    m = re.search(r"(\d{1,2})/(\d{1,2})/(\d{4})", s)
    if m:
        a, b, y = int(m.group(1)), int(m.group(2)), m.group(3)
        if a <= 12 and b <= 12 and a != b:
            return None, True
        if a > 12:
            return f"{y}-{b:02d}-{a:02d}", False
        return f"{y}-{a:02d}-{b:02d}", False
    return None, False


def find_label(text, labels):
    for lab in labels:
        m = re.search(lab + r"\s*:?\s*(.+)", text)
        if m:
            return m.group(1)
    return None


def extract(path, ctx):
    text, engine = get_text(path)
    flat = text.replace("\f", "\n")
    lines = flat.split("\n")
    low = flat.lower()
    out = {"vendor_name": None, "invoice_number": None, "document_type": "invoice", "invoice_date": None,
           "due_date": None, "currency": "USD", "line_items": [], "subtotal": None, "tax_amount": None,
           "tax_type": "none", "total": None, "related_invoice_number": None,
           "flags": {"duplicate": False, "total_mismatch": False, "ambiguous_date": False, "needs_person": False},
           "notes": ""}
    reasons = []
    # vendor: master list match, else first line's first segment
    for v in ctx["known_vendors"]:
        if v.lower() in low:
            out["vendor_name"] = v
            break
    if out["vendor_name"] is None:  # OCR: fuzzy match the first lines against the master list
        head = " ".join(l.strip() for l in lines[:3]).lower()
        best = max(ctx["known_vendors"], key=lambda v: difflib.SequenceMatcher(None, v.lower(), head[:len(v) + 10]).ratio())
        for l in lines[:3]:
            for v in ctx["known_vendors"]:
                if difflib.SequenceMatcher(None, v.lower(), l.strip().lower()[:len(v)]).ratio() >= 0.85 or \
                   difflib.SequenceMatcher(None, v.lower(), l.strip().lower()[-len(v):]).ratio() >= 0.85:
                    out["vendor_name"] = v
                    break
            if out["vendor_name"]:
                break
    if out["vendor_name"] is None:
        first = next((l for l in lines if l.strip()), "")
        out["vendor_name"] = re.split(r"\s{2,}", first.strip())[0] or None
        reasons.append("vendor not in master list")
    # currency / number format
    if re.search(r"\bEUR\b", flat):
        out["currency"] = "EUR"
    elif re.search(r"\bCAD\b", flat):
        out["currency"] = "CAD"
    comma_decimal = out["currency"] == "EUR" or len(re.findall(r"\d,\d{2}\b(?!\d)", flat)) > len(re.findall(r"\d\.\d{2}\b(?!\d)", flat))
    # document type
    if re.search(r"credit\s+(memo|note)", low):
        out["document_type"] = "credit"
    # invoice number
    m = re.search(r"(?:Invoice|Credit Memo|Credit note)\s*(?:#|No\.?|Number)\s*:?\s*([A-Z0-9][A-Z0-9-]{2,})", flat, re.I)
    if m:
        out["invoice_number"] = m.group(1).upper()
    else:
        reasons.append("invoice number not found")
    # dates
    ds = find_label(flat, [r"Invoice [Dd]ate", r"Issued", r"(?<![Dd]ue )\bDate"])
    due = find_label(flat, [r"Due [Dd]ate", r"Payment due"])
    out["invoice_date"], amb1 = parse_date(ds.split("  ")[0] if ds else None)
    out["due_date"], amb2 = parse_date(due.split("  ")[0] if due else None)
    if amb1 or amb2:
        out["flags"]["ambiguous_date"] = True
    if out["invoice_date"] is None and not amb1:
        reasons.append("invoice date not parsed")
    # related invoice for credits
    m = re.search(r"(?:applied to|against)\s+invoice\s*(?:#|no\.?|number)?\s*:?\s*([A-Z0-9][A-Z0-9-]{2,})", flat, re.I)
    if m:
        out["related_invoice_number"] = m.group(1).upper()
    # line items: rows after a table header until the totals block
    in_table, header_kind = False, None
    total_re = re.compile(r"^\s*(Subtotal|Net amount)\b", re.I)
    for raw in lines:
        l = raw.rstrip()
        if re.search(r"^\s*(Description|Item|Qty|Pos)\b.*\b(Amount|Line total|Total)", l, re.I):
            in_table = True
            header_kind = "qty_first" if re.match(r"^\s*Qty", l, re.I) else ("pos" if re.match(r"^\s*Pos", l, re.I) else "desc_first")
            continue
        if not in_table:
            continue
        if total_re.search(l):
            in_table = False
            continue
        if not l.strip() or re.search(r"continued|SYNTHETIC TEST DOCUMENT|Page \d+ of \d+", l, re.I):
            continue
        cells = [c for c in re.split(r"\s{2,}", l.strip()) if c]
        if len(cells) < 4 and engine == "tesseract":  # OCR collapses column gaps: split on single spaces
            toks = l.strip().split()
            nums = 3 if header_kind != "qty_first" else 2
            if len(toks) < nums + 2 or parse_amount(toks[-1], comma_decimal) is None:
                continue  # no amount at the end of the row: OCR noise, not a line item
            head = toks[:-nums]
            if header_kind == "qty_first":
                cells = [head[0], " ".join(head[1:]).lstrip("—-.:| "), toks[-2], toks[-1]]
            elif header_kind == "pos":
                cells = [head[0], " ".join(head[1:])] + toks[-3:]
            else:
                cells = [" ".join(head)] + toks[-3:]
        try:
            if header_kind == "qty_first":
                qty, desc, unit, amt = cells[0], " ".join(cells[1:-2]), cells[-2], cells[-1]
            elif header_kind == "pos":
                desc, qty, unit, amt = " ".join(cells[1:-3]), cells[-3], cells[-2], cells[-1]
            else:
                desc, qty, unit, amt = " ".join(cells[:-3]), cells[-3], cells[-2], cells[-1]
        except IndexError:
            reasons.append(f"unparsed table row: {l.strip()[:40]}")
            continue
        q = parse_amount(qty, comma_decimal)
        u = parse_amount(unit, comma_decimal)
        a = parse_amount(amt, comma_decimal)
        if q is None or u is None or a is None or not desc:
            reasons.append(f"unparsed table row: {l.strip()[:40]}")
            continue
        out["line_items"].append({"description": desc.strip(), "quantity": float(abs(q)), "unit_price": float(abs(u)), "line_total": a})
    # totals
    def amount_after(label_re):
        for l in lines:
            m = re.search(label_re + r".*?(?P<num>" + NUM_TOKEN + r")\s*$", l.strip(), re.I)
            if m:
                return parse_amount(m.group("num"), comma_decimal)
        return None
    out["subtotal"] = amount_after(r"^(Subtotal|Net amount)\b")
    tax_total, tax_labels = Decimal(0), []
    for l in lines:
        s = l.strip()
        m = re.match(r"^(.*?(Sales Tax|Sales tax|Tax|VAT|GST|PST)[^\d-]*[\d.,]*%?\)?)\s+(" + NUM_TOKEN + r")\s*$", s)
        if m and not re.search(r"total|VAT no", s, re.I):
            v = parse_amount(m.group(3), comma_decimal)
            if v is not None:
                tax_total += v
                tax_labels.append(m.group(2).upper())
    out["tax_amount"] = tax_total if tax_labels else None
    if "VAT" in tax_labels:
        out["tax_type"] = "VAT"
    elif "GST" in tax_labels and "PST" in tax_labels:
        out["tax_type"] = "GST_PST"
    elif "GST" in tax_labels:
        out["tax_type"] = "GST"
    elif tax_labels:
        out["tax_type"] = "sales_tax"
    out["total"] = amount_after(r"^(Total Due|Amount due|TOTAL CREDIT|TOTAL|Total amount|Total credit)\b")
    # credit sign policy
    if out["document_type"] == "credit":
        for li in out["line_items"]:
            li["line_total"] = -abs(li["line_total"])
        for k in ("subtotal", "tax_amount", "total"):
            if out[k] is not None:
                out[k] = -abs(out[k])
    # checks
    if out["subtotal"] is None or out["total"] is None:
        reasons.append("totals not found")
    if not out["line_items"]:
        reasons.append("no line items parsed")
    if out["line_items"] and out["subtotal"] is not None:
        s = sum((li["line_total"] for li in out["line_items"]), Decimal(0))
        if abs(s - out["subtotal"]) > Decimal("0.005"):
            out["flags"]["total_mismatch"] = True
    if out["subtotal"] is not None and out["total"] is not None:
        if abs(out["subtotal"] + (out["tax_amount"] or 0) - out["total"]) > Decimal("0.005"):
            out["flags"]["total_mismatch"] = True
    for li in out["line_items"]:
        if abs(Decimal(str(li["quantity"])) * Decimal(str(li["unit_price"])) - abs(li["line_total"])) > Decimal("0.011"):
            reasons.append("line math does not check")
            break
    # duplicate against ledger (same vendor + invoice number)
    for e in ctx["ledger"]:
        if out["invoice_number"] and e["invoice_number"].upper() == out["invoice_number"] and \
                (out["vendor_name"] or "").lower() == e["vendor_name"].lower():
            out["flags"]["duplicate"] = True
    if reasons:
        out["flags"]["needs_person"] = True
        out["notes"] = "rules: " + "; ".join(dict.fromkeys(reasons))
    # serialize decimals as strings with 2dp
    def fx(v):
        return None if v is None else f"{v:.2f}"
    for k in ("subtotal", "tax_amount", "total"):
        out[k] = fx(out[k])
    for li in out["line_items"]:
        li["line_total"] = fx(li["line_total"])
        li["unit_price"] = f"{li['unit_price']:.2f}"
        li["quantity"] = format(Decimal(str(li["quantity"])).normalize(), "f")
    out["_engine"] = engine
    return out


def main():
    ctx = load_context()
    if sys.argv[1:] == ["--all"]:
        res = {}
        for p in sorted(glob.glob(os.path.join(HERE, "inputs", "*"))):
            cid = os.path.splitext(os.path.basename(p))[0]
            try:
                res[cid] = extract(p, ctx)
            except Exception as e:  # a crash is recorded, not hidden
                res[cid] = {"_error": repr(e)}
        with open(os.path.join(HERE, "rules-outputs.json"), "w") as f:
            json.dump(res, f, indent=1)
        print("wrote rules-outputs.json for", len(res), "inputs")
    else:
        for p in sys.argv[1:]:
            print(json.dumps(extract(p, ctx), indent=1))


if __name__ == "__main__":
    main()
