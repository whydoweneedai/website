"""EXP-004 invoice generator. SYNTHETIC DATA ONLY.

Renders made-up invoices as text PDFs (reportlab, invariant=1 so output is
byte-deterministic) and, for scanned-look and handwritten cases, rasterizes
the PDF with pdftoppm and degrades/overlays it with Pillow (seeded RNG).
Handwriting is a font overlay (Caveat Brush), i.e. SIMULATED handwriting.

Usage:
  python3 gen.py            # render every case found in cases_*.py
  python3 gen.py --dev-only # render only the 4 dev cases
Writes inputs/<ID>.<pdf|jpg|png> and expected.json.
"""
import json, os, subprocess, sys, tempfile, math
from decimal import Decimal, ROUND_HALF_UP
from datetime import date
from reportlab.lib.pagesizes import letter, A4
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, white, black
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import numpy as np

from vendors import VENDORS, CUSTOMER

HERE = os.path.dirname(os.path.abspath(__file__))
HAND_FONT = "/usr/share/fonts/truetype/sand-box/google/Caveat Brush/CaveatBrush-Regular.ttf"
FOOTER = "SYNTHETIC TEST DOCUMENT - EXP-004 - not a real invoice"
Q = Decimal("0.01")
MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August",
          "September", "October", "November", "December"]


def d2(x):
    return Decimal(x).quantize(Q, rounding=ROUND_HALF_UP)


# ---------- amounts and dates ----------
def compute(case):
    v = VENDORS[case["vendor"]]
    sign = Decimal(-1) if case["kind"] == "credit" else Decimal(1)
    lines = []
    for desc, qty, unit in case["lines"]:
        q, u = Decimal(str(qty)), Decimal(str(unit))
        lines.append({"description": desc, "quantity": q, "unit_price": u, "line_total": sign * d2(q * u)})
    line_sum = sum((l["line_total"] for l in lines), Decimal(0))
    subtotal = Decimal(str(case["subtotal_print"])) if "subtotal_print" in case else line_sum
    taxes = [(label, d2(subtotal * Decimal(rate))) for label, rate in v["tax"]]
    tax = sum((t for _, t in taxes), Decimal(0))
    total = Decimal(str(case["total_print"])) if "total_print" in case else subtotal + tax
    return {"lines": lines, "line_sum": line_sum, "subtotal": subtotal, "taxes": taxes, "tax": tax, "total": total}


def fmt_num(x, layout, credit_style=None, dec_places=2):
    neg = x < 0
    a = abs(x)
    s = f"{a:,.{dec_places}f}"
    if layout == "L4":
        s = s.replace(",", "_").replace(".", ",").replace("_", ".")
    if neg:
        s = f"({s})" if credit_style == "paren" else f"-{s}"
    return s


def fmt_qty(q, layout):
    s = format(q.normalize(), "f")
    return s.replace(".", ",") if layout == "L4" else s


def fmt_date(iso, layout):
    if iso is None:
        return None
    y, m, d = map(int, iso.split("-"))
    if layout == "L1":
        return f"{m:02d}/{d:02d}/{y}"
    if layout == "L2":
        return f"{MONTHS[m-1]} {d}, {y}"
    if layout == "L3":
        return iso
    if layout == "L4":
        return f"{d:02d}.{m:02d}.{y}"


# ---------- PDF layouts ----------
class Doc:
    def __init__(self, path, layout):
        self.layout = layout
        self.size = A4 if layout == "L4" else letter
        self.c = canvas.Canvas(path, pagesize=self.size, invariant=1)
        self.W, self.H = self.size
        self.page = 0
        self.pos = {"qty_cells": [], "page_size": self.size}

    def text(self, x, y, s, font="Helvetica", size=10, align="left", color=black):
        c = self.c
        c.setFillColor(color)
        c.setFont(font, size)
        if align == "right":
            c.drawRightString(x, y, s)
        elif align == "center":
            c.drawCentredString(x, y, s)
        else:
            c.drawString(x, y, s)
        c.setFillColor(black)

    def footer(self, npages):
        self.text(self.W / 2, 28, FOOTER, size=7, align="center", color=HexColor("#666666"))
        self.text(self.W - 40, 28, f"Page {self.page + 1} of {npages}", size=7, align="right", color=HexColor("#666666"))

    def next_page(self, npages):
        self.footer(npages)
        self.c.showPage()
        self.page += 1


SPEC = {
    # columns: (key, header, x, align)
    "L1": {"font": "Helvetica", "bold": "Helvetica-Bold", "row": 16,
           "cols": [("desc", "Description", 50, "left"), ("qty", "Qty", 380, "right"),
                    ("unit", "Unit Price", 470, "right"), ("amt", "Amount", 562, "right")],
           "table_top": 585, "cont_top": 690, "bottom": 70},
    "L2": {"font": "Helvetica", "bold": "Helvetica-Bold", "row": 18,
           "cols": [("desc", "Item", 50, "left"), ("qty", "Quantity", 360, "right"),
                    ("unit", "Rate", 460, "right"), ("amt", "Line total", 562, "right")],
           "table_top": 560, "cont_top": 690, "bottom": 70},
    "L3": {"font": "Times-Roman", "bold": "Times-Bold", "row": 15,
           "cols": [("qty", "Qty", 80, "right"), ("desc", "Description", 95, "left"),
                    ("unit", "Unit", 470, "right"), ("amt", "Total", 562, "right")],
           "table_top": 575, "cont_top": 690, "bottom": 70},
    "L4": {"font": "Helvetica", "bold": "Helvetica-Bold", "row": 16,
           "cols": [("pos", "Pos", 40, "left"), ("desc", "Description", 70, "left"), ("qty", "Qty", 360, "right"),
                    ("unit", "Unit price EUR", 460, "right"), ("amt", "Amount EUR", 555, "right")],
           "table_top": 610, "cont_top": 760, "bottom": 70},
}
TOTALS_SPACE = 110


def header(doc, case, v, first=True):
    L, s = doc.layout, SPEC[doc.layout]
    credit = case["kind"] == "credit"
    title = "CREDIT MEMO" if credit else "INVOICE"
    numlabel = {"L1": "Credit Memo #:" if credit else "Invoice #:", "L2": "Credit note No." if credit else "Invoice No.",
                "L3": "Credit Memo Number:" if credit else "Invoice Number:", "L4": "Credit note no.:" if credit else "Invoice no.:"}[L]
    dprint = case.get("date_print") or fmt_date(case["date"], L)
    dueprint = fmt_date(case.get("due"), L)
    W, H = doc.W, doc.H
    if not first:
        doc.text(50 if L != "L4" else 40, H - 60, f"{v['name']} - {title} {case['number']} (continued)", s["bold"], 11)
        return
    if L == "L1":
        doc.text(50, 740, v["name"], s["bold"], 18)
        for i, a in enumerate(v["addr"]):
            doc.text(50, 724 - 12 * i, a, size=9)
        doc.text(562, 740, title, s["bold"], 22, "right")
        rows = [(numlabel, case["number"]), ("Date:", dprint)]
        rows.append(("Due Date:", dueprint) if dueprint else ("Terms:", case.get("terms", "")))
        for i, (k, val) in enumerate(rows):
            doc.text(470, 712 - 14 * i, k, s["bold"], 10, "right")
            doc.text(562, 712 - 14 * i, val, size=10, align="right")
        doc.text(50, 655, "Bill To:", s["bold"], 10)
        for i, a in enumerate(CUSTOMER):
            doc.text(50, 641 - 12 * i, a, size=10)
    elif L == "L2":
        c = doc.c
        c.setFillColor(HexColor("#1f4e5a")); c.rect(0, H - 95, W, 95, stroke=0, fill=1); c.setFillColor(black)
        doc.text(50, H - 50, v["name"], s["bold"], 20, color=white)
        doc.text(50, H - 70, v["addr"][0] + "  |  " + v["addr"][1], size=9, color=white)
        doc.text(562, H - 50, title.title(), s["bold"], 16, "right", color=white)
        doc.text(50, 660, f"{numlabel} {case['number']}", s["bold"], 11)
        doc.text(50, 644, f"Issued: {dprint}", size=10)
        doc.text(50, 630, f"Payment due: {dueprint}" if dueprint else case.get("terms", ""), size=10)
        doc.text(340, 660, "Billed to", s["bold"], 10)
        for i, a in enumerate(CUSTOMER):
            doc.text(340, 646 - 12 * i, a, size=10)
    elif L == "L3":
        doc.text(50, 735, title, s["bold"], 24)
        doc.text(562, 740, v["name"], s["bold"], 15, "right")
        for i, a in enumerate(v["addr"]):
            doc.text(562, 725 - 12 * i, a, s["font"], 10, "right")
        rows = [(numlabel, case["number"]), ("Invoice Date:" if not credit else "Date:", dprint)]
        if dueprint:
            rows.append(("Due Date:", dueprint))
        for i, (k, val) in enumerate(rows):
            doc.text(50, 700 - 14 * i, k, s["bold"], 11)
            doc.text(175, 700 - 14 * i, val, s["font"], 11)
        doc.text(330, 670, "Sold To:", s["bold"], 11)
        for i, a in enumerate(CUSTOMER):
            doc.text(330, 656 - 12 * i, a, s["font"], 10)
    elif L == "L4":
        doc.text(40, 790, v["name"], s["bold"], 16)
        for i, a in enumerate(v["addr"]):
            doc.text(40, 775 - 11 * i, a, size=9)
        doc.text(40, 775 - 11 * len(v["addr"]), "VAT no. XX000000000B01", size=9)
        doc.text(555, 790, title, s["bold"], 20, "right")
        rows = [(numlabel, case["number"]), ("Invoice date:" if not credit else "Date:", dprint)]
        if dueprint:
            rows.append(("Due date:", dueprint))
        for i, (k, val) in enumerate(rows):
            doc.text(460, 760 - 13 * i, k, s["bold"], 9, "right")
            doc.text(555, 760 - 13 * i, val, size=9, align="right")
        doc.text(40, 690, "Customer:", s["bold"], 10)
        for i, a in enumerate(CUSTOMER):
            doc.text(40, 676 - 12 * i, a, size=10)


def table_header(doc, y):
    s = SPEC[doc.layout]
    c = doc.c
    if doc.layout == "L2":
        c.setFillColor(HexColor("#e3eef0")); c.rect(45, y - 5, 522, 18, stroke=0, fill=1); c.setFillColor(black)
    for key, h, x, al in s["cols"]:
        doc.text(x, y, h, s["bold"], 10, al)
    c.setLineWidth(0.8)
    left = 40 if doc.layout == "L4" else 50
    right = 555 if doc.layout == "L4" else 562
    c.line(left, y - 6, right, y - 6)
    return y - 6 - s["row"]


def render_pdf(case, path):
    v = VENDORS[case["vendor"]]
    L = v["layout"]
    s = SPEC[L]
    amt = compute(case)
    cs = case.get("credit_style")
    doc = Doc(path, L)
    lines = amt["lines"]
    # paginate
    first_cap = int((s["table_top"] - 6 - s["bottom"]) // s["row"]) - 1
    cont_cap = int((s["cont_top"] - 6 - s["bottom"]) // s["row"]) - 1
    if "page_break_after" in case:
        chunks = [lines[:case["page_break_after"]], lines[case["page_break_after"]:]]
    else:
        chunks, rest, cap = [], list(lines), first_cap
        while rest:
            chunks.append(rest[:cap]); rest = rest[cap:]; cap = cont_cap
    # totals need room on last page
    rows_last = len(chunks[-1])
    top_last = s["table_top"] if len(chunks) == 1 else s["cont_top"]
    if top_last - 6 - s["row"] * (rows_last + 1) - TOTALS_SPACE - (40 if case.get("printed_notes") else 0) < s["bottom"]:
        chunks.append([])
    npages = len(chunks)
    idx = 0
    for p, chunk in enumerate(chunks):
        header(doc, case, v, first=(p == 0))
        y = table_header(doc, s["table_top"] if p == 0 else s["cont_top"])
        for ln in chunk:
            idx += 1
            for key, h, x, al in s["cols"]:
                val = {"pos": str(idx), "desc": ln["description"], "qty": fmt_qty(ln["quantity"], L),
                       "unit": fmt_num(ln["unit_price"], L), "amt": fmt_num(ln["line_total"], L, cs)}[key]
                doc.text(x, y, val, s["font"], 10, al)
                if key == "qty":
                    w = doc.c.stringWidth(val, s["font"], 10)
                    x0 = x - w if al == "right" else x
                    doc.pos["qty_cells"].append({"page": p, "x0": x0, "x1": x0 + w, "y": y, "text": val})
            y -= s["row"]
        if p < npages - 1:
            doc.text(562 if L != "L4" else 555, y - 4, "Continued on next page", s["font"], 9, "right")
            doc.next_page(npages)
    # totals block on last page
    y -= 8
    c = doc.c
    right = 555 if L == "L4" else 562
    labx = 460 if L == "L4" else 470
    c.line(labx - 110, y + 10, right, y + 10)
    sub_label = {"L1": "Subtotal", "L2": "Subtotal", "L3": "Subtotal", "L4": "Net amount"}[L]
    cur = v["currency"]
    tot_label = {"L1": "Total Due", "L2": "Amount due", "L3": f"TOTAL ({cur})", "L4": "Total amount EUR"}[L]
    if case["kind"] == "credit":
        tot_label = {"L1": "Total Credit", "L2": "Total credit", "L3": f"TOTAL CREDIT ({cur})", "L4": "Total credit EUR"}[L]
    rows = [(sub_label, fmt_num(amt["subtotal"], L, cs))]
    for label, t in amt["taxes"]:
        rows.append((label, fmt_num(t, L, cs)))
    tot = fmt_num(amt["total"], L, cs)
    if L in ("L1", "L2"):
        tot = ("-$" + tot[1:]) if tot.startswith("-") else ("$" + tot)
    rows.append((tot_label, tot))
    for i, (k, val) in enumerate(rows):
        bold = i == len(rows) - 1
        doc.text(labx, y - 16 * i, k, s["bold"] if bold else s["font"], 11 if bold else 10, "right")
        doc.text(right, y - 16 * i, val, s["bold"] if bold else s["font"], 11 if bold else 10, "right")
    y -= 16 * len(rows) + 10
    notes = case.get("printed_notes", [])
    for i, n in enumerate(notes):
        doc.text(50 if L != "L4" else 40, y - 12 * i, n, s["font"], 9)
    doc.pos["notes_y"] = y - 12 * len(notes) - 10
    doc.footer(npages)
    c.save()
    doc.pos["npages"] = npages
    return amt, doc.pos


# ---------- raster variants ----------
def rasterize(pdf, dpi):
    with tempfile.TemporaryDirectory() as td:
        subprocess.run(["pdftoppm", "-r", str(dpi), "-png", "-singlefile", pdf, os.path.join(td, "p")], check=True)
        return Image.open(os.path.join(td, "p.png")).convert("RGB")


def pt2px(x, y, dpi, page_h):
    return x * dpi / 72.0, (page_h - y) * dpi / 72.0


def apply_hand(img, case, pos, dpi):
    W, H = pos["page_size"]
    draw_layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ink = (25, 45, 140, 235)
    for h in case.get("hand", []):
        if h["type"] == "strike_qty":
            cell = pos["qty_cells"][h["line"]]
            x0, y = pt2px(cell["x0"] - 3, cell["y"] + 3, dpi, H)
            x1, _ = pt2px(cell["x1"] + 3, cell["y"] + 3, dpi, H)
            d = ImageDraw.Draw(draw_layer)
            d.line([(x0, y + 2), (x1, y - 3)], fill=ink, width=max(3, dpi // 40))
            d.line([(x0, y - 1), (x1, y - 6)], fill=ink, width=max(2, dpi // 60))
            txt, size = h["replace"], int(h.get("size", 22) * dpi / 72)
            font = ImageFont.truetype(HAND_FONT, size)
            tl = Image.new("RGBA", (size * 3, int(size * 1.6)), (0, 0, 0, 0))
            ImageDraw.Draw(tl).text((4, 0), txt, font=font, fill=ink)
            tl = tl.rotate(h.get("angle", 6), expand=True, resample=Image.BICUBIC)
            draw_layer.alpha_composite(tl, (int(x1 + 4), int(y - size * 1.1)))
        elif h["type"] == "note":
            size = int(h.get("size", 24) * dpi / 72)
            font = ImageFont.truetype(HAND_FONT, size)
            y_pt = h["y"] if h.get("y") is not None else pos["notes_y"]
            x, y = pt2px(h["x"], y_pt, dpi, H)
            tw = int(font.getlength(h["text"])) + 20
            tl = Image.new("RGBA", (tw, int(size * 1.7)), (0, 0, 0, 0))
            ImageDraw.Draw(tl).text((10, 0), h["text"], font=font, fill=ink)
            tl = tl.rotate(h.get("angle", 4), expand=True, resample=Image.BICUBIC)
            draw_layer.alpha_composite(tl, (int(x), int(y - size)))
    out = img.convert("RGBA")
    out.alpha_composite(draw_layer)
    return out.convert("RGB")


def apply_scan(img, p, seed):
    """Scanned-look degradation. p["color"] keeps RGB (used for the handwritten
    cases so blue ink stays blue); otherwise converts to grayscale."""
    rng = np.random.default_rng(seed)
    color = p.get("color", False)
    g = img.convert("RGB") if color else img.convert("L")
    if p.get("ring"):
        cx, cy, r = p["ring"]
        ring = Image.new("L", g.size, 0)
        d = ImageDraw.Draw(ring)
        W, H = g.size
        for k in range(14):
            rr = r * W + k * 0.6
            d.ellipse([cx * W - rr, cy * H - rr * 0.95, cx * W + rr, cy * H + rr * 0.95], outline=int(70 - k * 4), width=3)
        ring = ring.filter(ImageFilter.GaussianBlur(2.5))
        rr_ = np.asarray(ring).astype(np.float32) * 0.9
        arr = np.asarray(g).astype(np.float32) - (rr_[..., None] if color else rr_)
        g = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))
    g = g.rotate(p.get("angle", 0), resample=Image.BICUBIC, fillcolor=(235, 235, 232) if color else 235)
    g = g.filter(ImageFilter.GaussianBlur(p.get("blur", 0.7)))
    arr = np.asarray(g).astype(np.float32)
    arr = arr * p.get("contrast", 0.85) + 255 * (1 - p.get("contrast", 0.85)) * 0.8
    arr += rng.normal(0, p.get("noise", 10), arr.shape)
    # uneven lighting
    H, W = arr.shape[:2]
    grad = np.linspace(0, p.get("shade", 18), W)[None, :]
    arr -= grad[..., None] if color else grad
    return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))


# ---------- expected values ----------
def expected_for(case, amt):
    v = VENDORS[case["vendor"]]
    def s2(x):
        return None if x is None else f"{d2(x):.2f}"
    e = {
        "vendor_name": v["name"], "invoice_number": case["number"],
        "document_type": case["kind"], "invoice_date": case["date"], "due_date": case.get("due"),
        "currency": v["currency"],
        "line_items": [{"description": l["description"], "quantity": format(l["quantity"].normalize(), "f"),
                        "unit_price": s2(l["unit_price"]), "line_total": s2(l["line_total"])} for l in amt["lines"]],
        "subtotal": s2(amt["subtotal"]), "tax_amount": s2(amt["tax"]), "tax_type": v["tax_type"],
        "total": s2(amt["total"]), "related_invoice_number": case.get("related"),
        "required_flags": case.get("required_flags", []),
        "accept": case.get("accept", {}),
        "case_rules": case.get("case_rules", []),
        "group": case["group"], "dev": case.get("dev", False), "render": case["render"],
        "line_sum": s2(amt["line_sum"]),
    }
    return e


def load_cases(dev_only):
    import cases_dev
    cases = list(cases_dev.CASES)
    if not dev_only and os.path.exists(os.path.join(HERE, "cases_heldout.py")):
        import cases_heldout
        cases += cases_heldout.CASES
    return cases


def main():
    dev_only = "--dev-only" in sys.argv
    out = os.path.join(HERE, "inputs")
    os.makedirs(out, exist_ok=True)
    expected = {}
    for case in load_cases(dev_only):
        cid = case["id"]
        if case["render"] == "pdf":
            amt, pos = render_pdf(case, os.path.join(out, cid + ".pdf"))
        else:
            with tempfile.TemporaryDirectory() as td:
                pdf = os.path.join(td, cid + ".pdf")
                amt, pos = render_pdf(case, pdf)
                dpi = case.get("dpi", 150)
                img = rasterize(pdf, dpi)
            if case["render"] == "hand":
                img = apply_hand(img, case, pos, dpi)
                if case.get("scan"):
                    img = apply_scan(img, case["scan"], case["seed"]).convert("RGB")
                img.save(os.path.join(out, cid + ".png"), optimize=False)
            else:
                img = apply_scan(img, case["scan"], case["seed"])
                img.save(os.path.join(out, cid + ".jpg"), quality=case["scan"].get("jpeg_q", 60))
        expected[cid] = expected_for(case, amt)
        expected[cid]["file"] = "inputs/" + cid + {"pdf": ".pdf", "scan": ".jpg", "hand": ".png"}[case["render"]]
        expected[cid]["pages"] = pos["npages"]
    name = "expected-dev.json" if dev_only else "expected.json"
    with open(os.path.join(HERE, name), "w") as f:
        json.dump({"_note": "SYNTHETIC expected values for EXP-004, generated from case data by gen.py", "cases": expected}, f, indent=1)
    print("rendered", len(expected), "cases ->", name)


if __name__ == "__main__":
    main()
