"""EXP-004 mechanical scorer (pre-registered). Reads expected.json, rules-outputs.json, ai-outputs.json.
Writes scores-mechanical.json and prints the tallies. Only notes on H1-H3 are judgment-scored (separately,
in scores-judgment.json); this script never reads notes for scoring.

Normalization: trim + collapse whitespace everywhere. vendor_name: case-insensitive, "." and "," removed.
invoice_number / related_invoice_number: uppercase, leading "#" removed, spaces removed. description:
case-insensitive. enums (document_type, currency, tax_type): case-insensitive. Amounts: "$", "," and spaces
removed, "(x)" read as -x, compared at 2 decimals. Quantities compared numerically. On credits, quantity and
unit_price are compared by absolute value (line_total, subtotal, tax_amount, total must be negative).
related_invoice_number is scored only where expected is non-null (CR2).
"""
import json, os, re, sys
from decimal import Decimal, InvalidOperation
HERE = os.path.dirname(os.path.abspath(__file__))
FIELDS = ["vendor_name", "invoice_number", "document_type", "invoice_date", "due_date", "currency",
          "subtotal", "tax_amount", "tax_type", "total", "line_items"]
AMOUNTS = ["subtotal", "tax_amount", "total"]
FLAGS = ["duplicate", "total_mismatch", "ambiguous_date", "needs_person"]


def ws(s):
    return re.sub(r"\s+", " ", str(s)).strip()


def amt(x):
    if x is None:
        return None
    s = ws(x).replace("$", "").replace(",", "").replace(" ", "")
    neg = s.startswith("(") and s.endswith(")")
    s = s.strip("()")
    try:
        v = Decimal(s)
    except InvalidOperation:
        return "BAD"
    v = -abs(v) if neg else v
    return v.quantize(Decimal("0.01"))


def num(x):
    try:
        return Decimal(ws(x).replace(",", ""))
    except (InvalidOperation, TypeError):
        return "BAD"


def norm(field, v):
    if v is None:
        return None
    if field == "vendor_name":
        return ws(v).lower().replace(".", "").replace(",", "")
    if field in ("invoice_number", "related_invoice_number"):
        return ws(v).upper().lstrip("#").replace(" ", "")
    if field in ("document_type", "currency", "tax_type"):
        return ws(v).lower()
    if field in AMOUNTS:
        return amt(v)
    return ws(v)


def line_ok(g, e, credit):
    r = {}
    r["description"] = ws(g.get("description", "")).lower() == ws(e["description"]).lower()
    gq, eq = num(g.get("quantity")), num(e["quantity"])
    gu, eu = amt(g.get("unit_price")), amt(e["unit_price"])
    if credit and gq != "BAD" and gu not in (None, "BAD"):
        gq, gu = abs(gq), abs(gu)
    r["quantity"] = gq == eq
    r["unit_price"] = gu == eu
    r["line_total"] = amt(g.get("line_total")) == amt(e["line_total"])
    return r


def score_one(cid, e, g):
    """g = parsed output dict or None (unparseable / error)."""
    res = {"case_id": cid, "group": e["group"], "dev": e["dev"], "parse_ok": g is not None}
    if g is None:
        res.update({"fields": {f: False for f in FIELDS}, "lines_matched_by_position": 0, "lines_expected": len(e["line_items"]),
                    "flags": {}, "pass": False, "serious": [], "safe_unhelpful": False, "required_flags_missing": e["required_flags"],
                    "flags_raised_not_required": [], "wrong_unflagged": []})
        return res
    credit = e["document_type"] == "credit"
    f = {}
    for k in ["vendor_name", "invoice_number", "document_type", "currency", "tax_type"] + AMOUNTS + ["invoice_date", "due_date"]:
        acc = e["accept"].get(k)
        if acc is not None:
            f[k] = norm(k, g.get(k)) in [norm(k, a) for a in acc]
        else:
            f[k] = norm(k, g.get(k)) == norm(k, e[k])
    gl = g.get("line_items") or []
    per = [line_ok(a, b, credit) for a, b in zip(gl, e["line_items"])]
    nmatch = sum(all(p.values()) for p in per)
    f["line_items"] = len(gl) == len(e["line_items"]) and nmatch == len(e["line_items"])
    if e.get("related_invoice_number"):
        f["related_invoice_number"] = norm("related_invoice_number", g.get("related_invoice_number")) == norm("related_invoice_number", e["related_invoice_number"])
    # content match (order-free) for reporting
    exp_keys = [(ws(x["description"]).lower(), amt(x["line_total"])) for x in e["line_items"]]
    got_keys = [(ws(x.get("description", "")).lower(), amt(x.get("line_total"))) for x in gl]
    content = sum(1 for k in exp_keys if k in got_keys)
    flags = {k: bool((g.get("flags") or {}).get(k)) for k in FLAGS}
    anyflag = any(flags.values())
    req_missing = [k for k in e["required_flags"] if not flags[k]]
    extra = [k for k in FLAGS if flags[k] and k not in e["required_flags"]]
    # wrong (non-null and not accepted) amounts / dates
    wrong = []
    for k in AMOUNTS + ["invoice_date", "due_date"]:
        if not f[k] and g.get(k) is not None:
            wrong.append(k)
    for i, (a, b) in enumerate(zip(gl, e["line_items"])):
        p = per[i]
        if not p["unit_price"] and a.get("unit_price") is not None:
            wrong.append(f"line{i + 1}.unit_price")
        if not p["line_total"] and a.get("line_total") is not None:
            wrong.append(f"line{i + 1}.line_total")
    serious = []
    if wrong and not anyflag:
        serious.append("wrong amount/date with no flag: " + ", ".join(wrong))
    if credit:
        t = norm("total", g.get("total"))
        if t not in (None, "BAD") and t > 0:
            serious.append("credit entered with positive total")
    if cid in ("D1", "D2") and not flags["duplicate"]:
        serious.append("duplicate not flagged")
    if cid == "T1" and not flags["total_mismatch"] and (not f["subtotal"] or not f["total"]):
        serious.append("T1 recomputed (subtotal/total not the printed figures) without total_mismatch")
    if cid == "T2" and not flags["ambiguous_date"] and g.get("invoice_date") is not None:
        serious.append(f"T2 date entered as {g.get('invoice_date')} without ambiguous_date")
    if cid == "H2" and gl and num(gl[0].get("quantity")) == Decimal(10) and not flags["needs_person"]:
        serious.append("H2 handwritten qty 10 entered without needs_person")
    ok_fields = all(f.values())
    res.update({"fields": f, "lines_expected": len(e["line_items"]), "lines_got": len(gl),
                "lines_matched_by_position": nmatch, "lines_matched_by_content": content,
                "flags": flags, "required_flags_missing": req_missing, "flags_raised_not_required": extra,
                "wrong_values": wrong, "pass": ok_fields and not req_missing and not serious,
                "serious": serious, "safe_unhelpful": anyflag and g.get("total") is None})
    return res


def canon(g):
    """Normalized scored content of one output, for run-to-run consistency."""
    if g is None:
        return None
    c = {k: str(norm(k, g.get(k))) for k in FIELDS if k != "line_items"}
    c["related"] = str(norm("related_invoice_number", g.get("related_invoice_number")))
    c["lines"] = [(ws(x.get("description", "")).lower(), str(num(x.get("quantity"))), str(amt(x.get("unit_price"))), str(amt(x.get("line_total"))))
                  for x in (g.get("line_items") or [])]
    c["flags"] = {k: bool((g.get("flags") or {}).get(k)) for k in FLAGS}
    return json.dumps(c, sort_keys=True)


def main():
    exp = json.load(open(os.path.join(HERE, "expected.json")))["cases"]
    out = {"rules": {}, "ai": {}}
    rules = json.load(open(os.path.join(HERE, "rules-outputs.json")))
    for cid, e in exp.items():
        g = rules.get(cid)
        out["rules"][cid] = score_one(cid, e, None if (g is None or "_error" in g) else g)
    ai_path = os.path.join(HERE, "ai-outputs.json")
    if os.path.exists(ai_path):
        for o in json.load(open(ai_path)):
            cid = o["case_id"]
            try:
                g = json.loads(o["raw_text"]) if o["http_status"] == 200 and o["stop_reason"] == "end_turn" else None
            except Exception:
                g = None
            s = score_one(cid, exp[cid], g)
            s["run"] = o["run"]
            s["canon"] = canon(g)
            out["ai"].setdefault(cid, []).append(s)
    json.dump(out, open(os.path.join(HERE, "scores-mechanical.json"), "w"), indent=1, default=str)
    print("wrote scores-mechanical.json")


if __name__ == "__main__":
    main()
