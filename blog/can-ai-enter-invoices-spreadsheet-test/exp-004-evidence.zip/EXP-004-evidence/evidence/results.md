# EXP-004 results: can AI reliably type invoices into a spreadsheet?

Synthetic test. All 24 invoices, vendors and the customer are invented. One model (claude-sonnet-5-5), 3 runs per invoice (72 calls), against one deterministic rules script (OCR + regex). Mechanical scoring by score.py; counts by tally.py (full output in tally-output.txt). Only the handwritten-note scores are judgment.

Timeline (ET, 2026-10-23): rules.py locked 18:04:55 (before the 20 held-out cases existed). Pre-run fingerprints 18:11:15. Official rules run 18:11:26. First invoice API call 18:11:32. Last call sent 18:16:01, ai-outputs.json written 18:16:04. First scored 18:16:15 (score.py, then tally.py; that first tally output is saved with its original mtime as scoring-check/tally-first-run-output.txt). scores-mechanical.json has mtime 18:20:39 because score.py was re-run at 18:20:39 as a reproducibility check during packaging; the rewritten file was byte-identical to the 18:16:15 one (compared with cmp against a copy taken just before).

Held-out = 20 invoices rules.py never saw while it was written. Dev = 4 clean invoices (C1, C3, C5, C6) used to write rules.py. They are reported separately everywhere.

## Invoice-level pass

| Set | AI attempts passed | AI invoices passed in all 3 runs | AI invoices passed in 0 runs | Rules invoices passed |
| --- | --- | --- | --- | --- |
| Held-out (20) | 54/60 | 18/20 | 2/20 (CR1, T1) | 16/20 |
| Dev (4) | 12/12 | 4/4 | 0/4 | 4/4 |

Pass = every scored field correct, no required flag missing, no serious failure.

### Held-out by group

| Group | n | AI attempts passed | Rules passed |
| --- | --- | --- | --- |
| Clean | 2 | 6/6 | 2/2 |
| Scanned (simulated) | 4 | 12/12 | 1/4 |
| Handwriting (simulated font overlay) | 3 | 9/9 | 2/3 |
| Multi-page | 3 | 9/9 | 3/3 |
| Credit memo | 2 | 3/6 | 2/2 |
| Foreign (EUR, CAD) | 2 | 6/6 | 2/2 |
| Duplicate | 2 | 6/6 | 2/2 |
| Trap | 2 | 3/6 | 2/2 |
| Messy (decision rule: all held-out except the 2 clean) | 18 | 48/54 = 88.9% | 14/18 = 77.8% |

### Every case

| Case | Set | Group | AI r1 | AI r2 | AI r3 | Rules | What failed |
| --- | --- | --- | --- | --- | --- | --- | --- |
| C1 | dev | clean | pass | pass | pass | pass | - |
| C2 | held-out | clean | pass | pass | pass | pass | - |
| C3 | dev | clean | pass | pass | pass | pass | - |
| C4 | held-out | clean | pass | pass | pass | pass | - |
| C5 | dev | clean | pass | pass | pass | pass | - |
| C6 | dev | clean | pass | pass | pass | pass | - |
| S1 | held-out | scan | pass | pass | pass | pass | - |
| S2 | held-out | scan | pass | pass | pass | FAIL | Rules: description-only failure. 2 of 3 line descriptions with OCR typos ("Oat mitk", "2 tb bag"), no flag; every number on S2 correct |
| S3 | held-out | scan | pass | pass | pass | FAIL | Rules: subtotal null ("totals not found"), needs_person raised |
| S4 | held-out | scan | pass | pass | pass | FAIL | Rules: invoice number and date null, line description OCR errors ("100 pes"), needs_person raised |
| H1 | held-out | hand | pass | pass | pass | pass | - |
| H2 | held-out | hand | pass | pass | pass | FAIL | Rules: struck qty read as "40", line items wrong, needs_person raised ("line math does not check") |
| H3 | held-out | hand | pass | pass | pass | pass | - |
| M1-M3 | held-out | multi-page | pass x9 | | | pass x3 | - |
| CR1 | held-out | credit | FAIL | FAIL | FAIL | pass | AI: invoice_date null with ambiguous_date on an unambiguous date (10/15/2026), all 3 runs |
| CR2 | held-out | credit | pass | pass | pass | pass | - |
| F1, F2 | held-out | foreign | pass x6 | | | pass x2 | - |
| D1, D2 | held-out | duplicate | pass x6 | | | pass x2 | - |
| T1 | held-out | trap | FAIL | FAIL | FAIL | pass | AI: printed figures correct, but total_mismatch not raised, all 3 runs |
| T2 | held-out | trap | pass | pass | pass | pass | - |

## Per-field accuracy

| Field | AI held-out (60) | AI dev (12) | Rules held-out (20) | Rules dev (4) |
| --- | --- | --- | --- | --- |
| vendor_name | 60/60 | 12/12 | 20/20 | 4/4 |
| invoice_number | 60/60 | 12/12 | 19/20 (S4) | 4/4 |
| document_type | 60/60 | 12/12 | 20/20 | 4/4 |
| invoice_date | 57/60 (CR1 x3) | 12/12 | 19/20 (S4) | 4/4 |
| due_date | 60/60 | 12/12 | 20/20 | 4/4 |
| currency | 60/60 | 12/12 | 20/20 | 4/4 |
| subtotal | 60/60 | 12/12 | 19/20 (S3) | 4/4 |
| tax_amount | 60/60 | 12/12 | 20/20 | 4/4 |
| tax_type | 60/60 | 12/12 | 20/20 | 4/4 |
| total | 60/60 | 12/12 | 20/20 | 4/4 |
| line_items (whole table right) | 60/60 | 12/12 | 17/20 (S2, S4, H2) | 4/4 |
| related_invoice_number (CR2 only) | 3/3 | n/a | 1/1 | n/a |
| Individual line rows matched | 408/408 | 39/39 | 131/136 | 13/13 |

## Serious failures

None, for either method, under the pre-registered definition: a wrong amount or date with no flag, a credit with a positive total, a duplicate not flagged, T1 recalculated without the flag, T2 given a date without the flag, or H2 entered as qty 10 without needs_person.

Not counted as serious under that definition, but worth stating: rules.py entered wrong line descriptions on S2 with no flag at all (the definition covers amounts and dates only).

## Trap, duplicate and credit outcomes

| Case | Correct (defined in expected.json before the run) | AI (3 runs) | Rules |
| --- | --- | --- | --- |
| T1 total mismatch (lines sum 260.70, printed subtotal 248.50) | printed subtotal/tax/total + total_mismatch | Printed figures kept 3/3 (no recalculation), flag raised 0/3, notes empty. Fail, not serious | Printed figures + flag. Pass |
| T2 date 03/04/2026 | flag ambiguous_date (date null or either reading) | null + flag 3/3. Pass | null + flag. Pass |
| D1 exact duplicate of ledger | duplicate flag | 3/3. Pass | Pass |
| D2 reused invoice number, different date and total | duplicate flag | 3/3, and notes explain the date and total differ. Pass | Pass |
| CR1 credit memo | negative subtotal/tax/total, document_type credit | Amounts negative 3/3, but date blanked (see CR1 above). Fail | Pass |
| CR2 credit in parentheses, applied to OPP-30871 | negative amounts + related invoice | 3/3 incl. related number. Pass | Pass |
| H2 qty 12 struck, "10" handwritten | printed qty 12 + needs_person | 3/3. Pass | needs_person raised but qty read as 40. Fail |

## Flags

| | AI (72 attempts) | Rules (24) |
| --- | --- | --- |
| Required flags raised | 12 of 15 required (D1 3/3, D2 3/3, T2 3/3, H2 3/3, T1 0/3) | 5 of 5 (D1, D2, T1, T2, H2) |
| Required flag missed | T1 total_mismatch, 3/3 runs | none |
| Flag raised that was not required | CR1 ambiguous_date 3/3 (date is not ambiguous); M2 run 3 total_mismatch (notes claim lines sum to 2137.60; its own 28 extracted lines sum to 2137.65, the printed subtotal) | needs_person on S3 and S4. Not required by expected.json, but these are the cases where rules failed a field, so the flag was the right signal |
| Safe but unhelpful (flag + total left null) | none | none |
| Unparseable or error responses | 0 of 72 (all HTTP 200, end_turn, one text block, schema-valid JSON) | n/a |

M2 run 3 still counts as a pass because extra flags do not fail an invoice under the pre-registered rule. It is a false alarm, not a data error.

## Consistency (AI, 3 runs per invoice)

- Same pass/fail in all 3 runs: 24/24.
- Identical normalized fields, line items and flags in all 3 runs: 23/24. M2 differed (run 3 raised the false total_mismatch flag). Notes text is not part of this comparison; it varied in wording across runs.
- Both AI failures (CR1, T1) were the same in all 3 runs. Running the same invoice 3 times would not have caught them.

## Judgment scores (JUDGMENT, not mechanical, not blind, scored by the site's AI writing assistant)

Handwritten note handling, 0-2 per run, rubric pre-registered: 18/18 points (H1, H2, H3, each 2 in all 3 runs). Details in scores-judgment.json. H3 was scored against what the image actually shows: the generator clipped the note at the page edge ("10/20" renders as "10/2"), and the AI quoted the visible text and said it looked cut off (deviation D1). Rules: not scored, because rules.py cannot read handwriting.

## Cost (from API usage fields, list price $2 per million input tokens and $10 per million output tokens, checked 2026-10-23)

- 72 invoice calls: 368,382 input tokens x $2 / 1,000,000 = $0.7368, plus 37,684 output tokens x $10 / 1,000,000 = $0.3768. Total $1.1136, about $0.0155 per invoice attempt.
- Smoke call (dummy image): 2,250 x $2/1M + 202 x $10/1M = $0.00652.
- Thinking probes: 2 returned HTTP 400 with no usage (counted as $0); 1 returned 22 input + 4 output tokens = $0.000084.
- All API calls: $0.736764 + $0.37684 + $0.00652 + $0.000084 = $1.120208, so $1.1202. Rules + OCR ran locally: $0 API cost.
- 0 thinking tokens on every call.

## Decision rule outcome (pre-registered, design.md addendum)

1. AI serious failure on any clean invoice: none (18/18 clean attempts passed). The "not unchecked" rule is not triggered by this clause.
2. Clause 2 (AI pass rate on messy held-out inputs higher than rules, with zero serious failures): met. On the 18 messy held-out invoices, the AI passed 48 of 54 attempts (89%), the rules script 14 of 18 (78%). 0 serious failures in 72 AI attempts. Because the AI's pass/fail never changed between runs, that is the same as 16 of 18 invoices vs 14 of 18: a gap of 2 invoices out of 18. One of the 4 rules failures (S2) was description-only: two OCR typos ("Oat mitk", "2 tb bag"), nothing flagged, every number correct. The pre-registered wording applies: AI extraction can be recommended with a person checking flagged invoices and totals.
3. Not triggered: both methods were not weak on messy inputs.

What the result adds to that wording: the AI's total_mismatch flag missed the one deliberate mismatch in 3/3 runs and raised a false one once, so "a person checking totals" should mean a sum check in the spreadsheet (line items vs subtotal, subtotal + tax vs total), not trusting the AI's flag. The AI extracted T1's line items correctly every time, so that check would have caught it. The rules script did catch T1 (total_mismatch raised); the AI missed it in all 3 runs. That is why the article recommends a sum formula.
