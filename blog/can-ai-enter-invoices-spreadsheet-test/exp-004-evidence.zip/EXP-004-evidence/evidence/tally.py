"""EXP-004 tally: reads scores-mechanical.json (+ scores-judgment.json if present) and run-log.json,
prints every table used in results.md. Held-out (20) and dev (4) always reported separately."""
import json, os
from collections import Counter, defaultdict
HERE = os.path.dirname(os.path.abspath(__file__))
S = json.load(open(os.path.join(HERE, "scores-mechanical.json")))
FIELDS = ["vendor_name", "invoice_number", "document_type", "invoice_date", "due_date", "currency",
          "subtotal", "tax_amount", "tax_type", "total", "line_items"]
GROUPS = ["clean", "scan", "handwritten", "multipage", "credit", "foreign", "duplicate", "trap"]
MESSY = {"scan", "handwritten", "multipage", "credit", "foreign", "duplicate", "trap"}


def split(d):
    return {"held-out": {k: v for k, v in d.items() if not (v[0] if isinstance(v, list) else v)["dev"]},
            "dev": {k: v for k, v in d.items() if (v[0] if isinstance(v, list) else v)["dev"]}}


def line(*a):
    print("| " + " | ".join(str(x) for x in a) + " |")


ai, rules = split(S["ai"]), split(S["rules"])
print("## Invoice-level pass")
line("set", "AI passes (attempts)", "AI invoices passed in all 3 runs", "AI passed in 0 runs", "rules passes")
for part in ("held-out", "dev"):
    A, R = ai[part], rules[part]
    att = sum(r["pass"] for v in A.values() for r in v)
    all3 = sum(all(r["pass"] for r in v) for v in A.values())
    none = sum(not any(r["pass"] for r in v) for v in A.values())
    line(part, f"{att}/{3 * len(A)}", f"{all3}/{len(A)}", f"{none}/{len(A)}", f"{sum(r['pass'] for r in R.values())}/{len(R)}")
print("\n## By group (held-out only, dev excluded)")
line("group", "n", "AI passes (attempts)", "rules passes")
for g in GROUPS:
    A = {k: v for k, v in ai["held-out"].items() if v[0]["group"] == g}
    R = {k: v for k, v in rules["held-out"].items() if v["group"] == g}
    line(g, len(A), f"{sum(r['pass'] for v in A.values() for r in v)}/{3 * len(A)}", f"{sum(r['pass'] for r in R.values())}/{len(R)}")
A = {k: v for k, v in ai["held-out"].items() if v[0]["group"] in MESSY}
R = {k: v for k, v in rules["held-out"].items() if v["group"] in MESSY}
pa = sum(r['pass'] for v in A.values() for r in v); pr = sum(r['pass'] for r in R.values())
line("MESSY (decision rule)", len(A), f"{pa}/{3 * len(A)} = {pa / (3 * len(A)):.1%}", f"{pr}/{len(R)} = {pr / len(R):.1%}")
print("\n## Per-case detail")
line("case", "dev", "group", "AI run1", "AI run2", "AI run3", "rules", "AI failed fields (runs)", "rules failed fields")
for cid in S["ai"]:
    v = S["ai"][cid]; r = S["rules"][cid]
    ff = Counter(k for x in v for k, ok in x["fields"].items() if not ok)
    mf = [k for x in v for k in x["required_flags_missing"]]
    if mf: ff.update(Counter("missing flag " + k for k in mf))
    rf = [k for k, ok in r["fields"].items() if not ok] + ["missing flag " + k for k in r["required_flags_missing"]]
    line(cid, "dev" if r["dev"] else "", r["group"], *["PASS" if x["pass"] else "fail" for x in v], "PASS" if r["pass"] else "fail",
         ", ".join(f"{k} x{n}" for k, n in ff.items()) or "-", ", ".join(rf) or "-")
print("\n## Per-field accuracy")
line("field", "AI held-out (60)", "AI dev (12)", "rules held-out (20)", "rules dev (4)")
for f in FIELDS + ["related_invoice_number"]:
    cells = []
    for src, n in ((ai, 3), (rules, 1)):
        for part in ("held-out", "dev"):
            xs = [x for v in src[part].values() for x in (v if isinstance(v, list) else [v]) if f in x["fields"]]
            cells.append(f"{sum(x['fields'][f] for x in xs)}/{len(xs)}" if xs else "n/a")
    line(f, *cells)
print("\n## Line items (by position / by content)")
for name, src in (("AI", ai), ("rules", rules)):
    for part in ("held-out", "dev"):
        xs = [x for v in src[part].values() for x in (v if isinstance(v, list) else [v])]
        line(name, part, f"by position {sum(x['lines_matched_by_position'] for x in xs)}/{sum(x['lines_expected'] for x in xs)}",
             f"by content {sum(x.get('lines_matched_by_content', 0) for x in xs)}/{sum(x['lines_expected'] for x in xs)}")
print("\n## Serious failures")
for name, src in (("AI", S["ai"]), ("rules", S["rules"])):
    for cid, v in src.items():
        for x in (v if isinstance(v, list) else [v]):
            for s in x["serious"]:
                print(f"- {name} {cid}{' run' + str(x['run']) if 'run' in x else ''} ({'dev' if x['dev'] else 'held-out'}): {s}")
print("\n## Flags: required raised / raised but not required / safe-but-unhelpful / unparseable")
for name, src in (("AI", S["ai"]), ("rules", S["rules"])):
    req = Counter(); miss = Counter(); extra = Counter(); safe = []; bad = []
    for cid, v in src.items():
        for x in (v if isinstance(v, list) else [v]):
            for k in x.get("required_flags_missing", []): miss[(cid, k)] += 1
            for k in x.get("flags_raised_not_required", []): extra[(cid, k)] += 1
            if x.get("safe_unhelpful"): safe.append(cid)
            if not x["parse_ok"]: bad.append(cid)
    print(f"- {name} required flags missed: {dict(miss) or 'none'}")
    print(f"- {name} raised but not required: {dict(extra) or 'none'}")
    print(f"- {name} safe but unhelpful: {safe or 'none'}; unparseable/error: {bad or 'none'}")
print("\n## Consistency (AI, 3 runs)")
same = [cid for cid, v in S["ai"].items() if len({x['canon'] for x in v}) == 1]
pf = [cid for cid, v in S["ai"].items() if len({x['pass'] for x in v}) == 1]
print(f"- identical normalized output in all 3 runs: {len(same)}/24 ({', '.join(c for c in S['ai'] if c not in same) or 'none'} differed)")
print(f"- same pass/fail in all 3 runs: {len(pf)}/24 ({', '.join(c for c in S['ai'] if c not in pf) or 'none'} differed)")
jp = os.path.join(HERE, "scores-judgment.json")
if os.path.exists(jp):
    print("\n## Judgment scores (JUDGMENT, not mechanical; notes on H1-H3, 0-2)")
    for row in json.load(open(jp))["scores"]:
        print(f"- {row['case_id']} run{row['run']}: {row['score']} - {row['reason']}")
lp = os.path.join(HERE, "run-log.json")
if os.path.exists(lp):
    L = json.load(open(lp))
    ti = sum(x["input_tokens"] or 0 for x in L); to = sum(x["output_tokens"] or 0 for x in L)
    print(f"\n## Cost\n- calls {len(L)}, status {dict(Counter(x['http_status'] for x in L))}, stop {dict(Counter(x['stop_reason'] for x in L))}, models {dict(Counter(x['model'] for x in L))}")
    print(f"- input tokens {ti:,}, output tokens {to:,}")
    print(f"- cost = {ti:,} x $2/1e6 + {to:,} x $10/1e6 = ${ti * 2 / 1e6:.4f} + ${to * 10 / 1e6:.4f} = ${ti * 2 / 1e6 + to * 10 / 1e6:.4f}")
    print(f"- per invoice attempt ${(ti * 2 / 1e6 + to * 10 / 1e6) / len(L):.4f}")
