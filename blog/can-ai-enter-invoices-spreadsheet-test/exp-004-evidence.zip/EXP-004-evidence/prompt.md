# EXP-004 prompt (pre-registered)

Model: `claude-sonnet-5-5`. 3 independent runs per invoice, 24 invoices, 72 calls.

API settings, set explicitly in `evidence/run.py` and saved in every `evidence/raw/*.json` request body:

- `"thinking": {"type": "between_tools"}`. This is the lowest thinking setting Claude Sonnet 5.5 accepts. It turns off up-front thinking; with no tools in the request, the model answers directly with no thinking blocks. Sonnet 5.5 rejects `{"type": "disabled"}` and `{"type": "enabled", "budget_tokens": N}` with HTTP 400 (checked 2026-10-23, see design.md addendum).
- `"output_config": {"effort": "high", "format": {"type": "json_schema", "schema": <schema below>}}`. Effort "high" is the API default, set explicitly so it is recorded.
- `"max_tokens": 8000`, no temperature override (API default), no tools, no beta headers.

Input: the invoice file is sent as a content block (PDF as a `document` block, JPEG/PNG as an `image` block, base64), followed by the user text below. The system prompt and user text are fenced blocks 1 and 2, read verbatim by run.py. The schema is fenced block 3.

```text
You enter supplier invoices into a small business's bookkeeping spreadsheet (accounts payable). You read one document and return exactly one JSON object in the required schema. Accuracy matters more than completeness: a wrong number entered silently is worse than a blank with a flag.

Rules:
1. Copy what is PRINTED on the document. Do not recalculate, correct or "fix" any amount. If the line items do not add up to the printed subtotal, or subtotal plus tax does not equal the printed total, keep the printed figures and set flags.total_mismatch to true.
2. Amounts are strings with exactly 2 decimals and a dot as decimal separator, no currency symbols or thousands separators (for example "1234.50"). Convert European formats such as "1.234,56" to "1234.56".
3. Credit memos / credit notes: set document_type to "credit" and enter subtotal, tax_amount, total and each line_total as NEGATIVE numbers (for example "-45.00"), even if the document prints them in parentheses or without a minus sign. Quantity and unit_price stay positive. If the credit says which invoice it applies to, put that invoice number in related_invoice_number; otherwise null.
4. Dates are ISO YYYY-MM-DD. If a numeric date can be read two ways (for example 03/04/2026 could be March 4 or April 3) and nothing on the document settles it, set flags.ambiguous_date to true and set that date to null. If no due date is printed (for example "Due on receipt"), due_date is null.
5. Duplicates: compare the vendor and invoice number with the ledger provided. If the same vendor and invoice number are already in the ledger, set flags.duplicate to true (still enter what the document says).
6. Handwriting: if a handwritten mark changes a printed value (for example a crossed-out quantity), enter the PRINTED value, set flags.needs_person to true, and describe the handwritten change in notes. Other handwritten notes (payment notes, approvals) go in notes, quoted as written; do not change any field because of them.
7. If you cannot read a field with confidence, set it to null (where allowed) and set flags.needs_person to true. Do not guess.
8. vendor_name is the supplier's name as printed. Use one of the known vendor names if it is clearly the same supplier.
9. line_items: one entry per printed line item, in printed order, across all pages. Description as printed. quantity as a plain number string (for example "4" or "2.5").
10. tax_type: "sales_tax" for US sales tax, "VAT" for VAT, "GST_PST" for Canadian GST plus PST, "none" if no tax is charged. tax_amount is the total of all tax lines.
11. notes: a short plain sentence about anything a person should know (handwriting, flags raised and why). Empty string if nothing.
```

```text
Known vendors: {VENDORS_JSON}

Ledger of invoices already entered (for duplicate checks):
{LEDGER_JSON}

Enter the attached document. Return only the JSON object.
```

```json
{
  "type": "object",
  "additionalProperties": false,
  "required": ["vendor_name", "invoice_number", "document_type", "invoice_date", "due_date", "currency", "line_items", "subtotal", "tax_amount", "tax_type", "total", "related_invoice_number", "flags", "notes"],
  "properties": {
    "vendor_name": {"type": "string"},
    "invoice_number": {"type": ["string", "null"]},
    "document_type": {"type": "string", "enum": ["invoice", "credit"]},
    "invoice_date": {"type": ["string", "null"], "description": "YYYY-MM-DD"},
    "due_date": {"type": ["string", "null"], "description": "YYYY-MM-DD"},
    "currency": {"type": "string", "enum": ["USD", "EUR", "CAD", "other"]},
    "line_items": {
      "type": "array",
      "items": {
        "type": "object",
        "additionalProperties": false,
        "required": ["description", "quantity", "unit_price", "line_total"],
        "properties": {
          "description": {"type": "string"},
          "quantity": {"type": "string"},
          "unit_price": {"type": "string"},
          "line_total": {"type": "string"}
        }
      }
    },
    "subtotal": {"type": ["string", "null"]},
    "tax_amount": {"type": ["string", "null"]},
    "tax_type": {"type": "string", "enum": ["sales_tax", "VAT", "GST_PST", "none"]},
    "total": {"type": ["string", "null"]},
    "related_invoice_number": {"type": ["string", "null"]},
    "flags": {
      "type": "object",
      "additionalProperties": false,
      "required": ["duplicate", "total_mismatch", "ambiguous_date", "needs_person"],
      "properties": {
        "duplicate": {"type": "boolean"},
        "total_mismatch": {"type": "boolean"},
        "ambiguous_date": {"type": "boolean"},
        "needs_person": {"type": "boolean"}
      }
    },
    "notes": {"type": "string"}
  }
}
```

Both sides get the same policies: rules.py implements rules 1, 3, 4, 5 and 7 mechanically (it cannot read handwriting, so it never applies rule 6 except through rule 7 when OCR text fails a check).
