# EXP-004 test design (PROPOSED, not run): Can AI reliably type invoices into a spreadsheet?
Status: proposed Oct 23 2026, awaiting Ollie's sign-off. Nothing generated or run.
Reader question: Should a small-business owner trust AI to read supplier invoices into a spreadsheet, use simpler extraction, or keep a person on it?

## What we compare
- AI: Claude via the Anthropic API (claude-sonnet-5-5, as EXP-002/003). It gets each invoice as a PDF or image and returns JSON in a fixed spreadsheet schema, or flags it for a person. Model string, date and token cost are recorded.
- Rules baseline: a script I write before seeing any AI output. It uses pdftotext for text PDFs, Tesseract OCR for images, and regex/field rules for the invoice layouts. It flags anything it can't parse.
- Not tested: off-the-shelf invoice tools (QuickBooks, Dext, etc.). If mentioned, they're cited as vendor claims only.
- Inputs are generated on my computer with Python (reportlab for PDFs, Pillow for images). I don't expect to need Wally, but I'll say so if rendering the scanned or handwritten cases turns out to need help.

## Invoices (synthetic, clearly labeled; 24 invoices from 6 made-up vendors, 4 layouts)
- Clean (6): text PDFs in standard layouts.
- Scanned look (4): rasterized at low DPI, with slight rotation, blur, noise and a coffee-ring style smudge.
- Handwritten notes (3): a handwriting-style font overlaid, e.g. "paid 10/12 chk 4411" or a struck-through quantity corrected by hand. This is simulated, not real handwriting, and will be labeled that way.
- Multi-page (3): line items run onto page 2, with totals on the last page.
- Credit memo (2): negative amounts, and one with a credit applied against an earlier invoice.
- Foreign currency (2): EUR with comma decimals (1.234,56) and CAD with GST and PST.
- Duplicate (2): the same invoice number resubmitted, once identical and once with a new date. Should be flagged.
- Traps (2): one where the printed total doesn't match the sum of the lines (a vendor error that should be flagged, not "fixed"), and one ambiguous date (03/04/2026) with no locale cue.

## Locked expected fields (one row per invoice, plus one row per line item)
Vendor name, invoice number, invoice date (ISO), due date, currency, line items (description, quantity, unit price, line total), subtotal, tax (amount and type), total, document type (invoice or credit), and flags (duplicate, total mismatch, ambiguous date, needs a person).

## Scoring (mechanical, by script, against locked fields)
- Exact match after documented normalization: trimmed whitespace, ISO dates, amounts to 2 decimals in the invoice's currency, case-insensitive vendor name.
- Score each field separately; line items are matched by position and by content.
- Invoice-level pass: every header field, the totals and the tax are exact, all line items are exact, and the required flags are raised.
- Serious failure: a wrong amount or date written without a flag, a credit entered as positive, an unflagged duplicate, or a total silently "corrected".
- A flag plus correct output counts as a pass. A flag with no output is "safe but unhelpful" and reported separately.
- Judgment-scored, and labeled as such: only whether the free-text note handling ("paid 10/12") was sensible.
- Consistency: each invoice is run through the AI 3 times (72 calls); I report disagreements on any field. The rules script runs once.
- Cost: actual API cost from token usage. The OCR and rules run is local and has no API cost. No time-savings claims.

## Pre-registration
Before the first API call, save the generator script, the rendered inputs, expected.json, the AI prompt, the rules script and the scorers. Fingerprint them all with sha256 and a timestamp. Any later change becomes a dated deviation, with the originals preserved.

## Decision rule (pre-registered)
- If the AI has any serious failure on clean invoices, the article says not to let it enter invoices unchecked.
- If the AI beats rules on messy inputs with zero serious failures, the article can recommend AI extraction with a person checking flagged invoices and totals.
- If both are weak on messy inputs, the recommendation is a person, or a tool with human review.
- Results override the planned angle.

## Limits to state
- Synthetic invoices from few layouts, and simulated handwriting and scans.
- One model, one date.
- The rules script was written for these layouts, so it's an optimistic baseline for rules.
- Scored by the site's AI assistant with scripts. Not a live pilot or case study.

## Addendum, Oct 23 2026 (ET): Ollie's sign-off changes, written before fingerprinting and before any invoice was sent to the API
Ollie approved the design above with three changes. This addendum records how each was applied, plus details the proposal left open. It is part of the pre-registration (fingerprinted in fingerprints.sha256).

### 1. Fairer rules baseline: 4 dev invoices, 20 held out
- Dev invoices (one clean text PDF per layout): C1 (layout L1, Brightwater Paper Supply), C3 (L2, Kestrel Hill Coffee Roasters), C5 (L3, Ostrander Plumbing Parts), C6 (L4, Vellmar Packaging B.V.).
- Order of work: cases_dev.py and the 4 dev PDFs were generated first. evidence/rules.py was written looking only at those 4 (their pdftotext output, a montage of the 4 renders, and expected-dev.json). To test the OCR path I rasterized the same 4 dev PDFs (clean, and with an ad-hoc scan filter) in /tmp; those test outputs are saved in evidence/rules-dev-tests/. No held-out case existed at that point.
- rules.py was then locked: evidence/rules-lock.sha256 (sha256 80260d4b..., 2026-10-23 18:04:55 EDT) and made read-only. Only after that did I write cases_heldout.py and render the other 20. Re-rendering with all 24 cases left the 4 dev PDFs byte-identical.
- The vendor list and ledger the rules use (context.json) were written after the lock. They are data, not code, and the AI gets the identical vendor list and ledger.
- Disclosed: after rendering the held-out set I ran rules.py over all 24 inputs once as a dry run, to test that score.py executes. rules.py could not change (locked); score.py logic was not changed after seeing that dry run except as listed in deviations.md (if any). The official rules run happens after fingerprinting.
- Every result is reported in two groups: the 20 held-out invoices and the 4 dev invoices. The headline numbers are held-out.
- The rules script was written by the same assistant that wrote the generator, so it knows the layouts in general terms. It is still an optimistic baseline for rules.

### 2. API thinking setting, set explicitly
- Ollie asked for thinking "disabled or a fixed budget". On claude-sonnet-5-5 neither is accepted. Probe requests on a one-line dummy prompt (no invoice), saved in evidence/smoke/thinking-probes.json: `{"type": "disabled"}` returned HTTP 400 with the message "To turn thinking off on this model, send "thinking": {"type": "between_tools"} instead of {"type": "disabled"}. The model does not think before responding."; `{"type": "enabled", "budget_tokens": 1024}` returned HTTP 400 ("not supported for this model"); `{"type": "between_tools"}` returned 200 with 0 thinking tokens. I had hit the same two 400s earlier today while checking the docs; those first attempts were not saved, so the probes were repeated and saved. Docs: sources.md.
- Setting used: `"thinking": {"type": "between_tools"}` with `"output_config": {"effort": "high", ...}`. With no tools in the request, this means no thinking before the answer. It is written in prompt.md, hard-coded in run.py (THINKING, EFFORT) and saved in every raw request file (`request_body.thinking`, plus `thinking_setting` and `effort` fields).
- One pre-run smoke call was made on a dummy image that says "CONFIGURATION TEST - not an invoice" to validate the settings and the schema: HTTP 200, one text block, 0 thinking tokens, 2,250 input and 202 output tokens, est. $0.0065. Saved in evidence/smoke/. It and the 3 probe calls are counted in the cost total.

### 3. Trap, duplicate and credit correctness (also written into expected.json `case_rules` and `accept`)
- T2 ambiguous date (printed 03/04/2026, vendor with no address or locale cue, "Due on receipt"): correct = ambiguous_date flag. With the flag, invoice_date may be 2026-03-04, 2026-04-03 or null. Either reading without the flag is a serious failure.
- T1 total mismatch (lines sum to 260.70, printed subtotal 248.50, tax and total printed from 248.50): correct = the PRINTED subtotal, tax and total plus total_mismatch. Recalculated subtotal or total without total_mismatch is a serious failure. The printed figures without the flag is a fail (not serious, since nothing wrong was entered).
- D1 (exact re-send of ledger entry BPS-10391) and D2 (same vendor and number as ledger entry OPP-30940, new date and amounts): correct = the printed values plus duplicate. No duplicate flag is a serious failure.
- CR1 (credit memo, minus signs) and CR2 (credit printed in parentheses, "Applied to invoice OPP-30871"): correct = document_type credit with negative subtotal, tax, total and line totals; quantity and unit price compared by absolute value; CR2 also needs related_invoice_number OPP-30871. A positive total on a credit is a serious failure.
- H2 (typed quantity 12 struck through, "10" handwritten): correct = the printed values (12, 648.00, printed totals) plus needs_person. Quantity 10 without needs_person is a serious failure; quantity 10 with needs_person is a fail, not serious.
- H1 ("paid 10/12 chk 4411") and H3 ("Approved for payment - M.K. 10/20"): correct = the printed values; no flag required.

### Details fixed before the run
- Inputs: 24 files in evidence/inputs/. 17 text PDFs (6 clean, 3 multi-page, 2 credit, 2 foreign, 2 duplicate, 2 trap), 4 scanned-look JPEGs (150 dpi, rotation, blur, noise, uneven light, 2 with a coffee ring), 3 PNGs with simulated handwriting (Caveat Brush font in blue on a light scan filter). Every page carries "SYNTHETIC TEST DOCUMENT - EXP-004 - not a real invoice". All numeric dates outside T2 use a day above 12.
- AI input: PDF as a `document` block, images as `image` blocks (base64), then the vendor list, ledger and instruction text. Structured output via `output_config.format` json_schema (prompt.md). Saved request bodies replace the base64 with the file name and sha256.
- Scored fields per invoice: vendor_name, invoice_number, document_type, invoice_date, due_date, currency, subtotal, tax_amount, tax_type, total, line_items (all lines exact by position), plus related_invoice_number on CR2. Normalization is in the score.py docstring. Notes are never mechanically scored.
- Pass = every scored field correct (with the case's accept list), all required flags raised, no serious failure. Extra flags do not fail an invoice but are reported as "raised but not required".
- Serious failure = any of: a non-null wrong amount (subtotal, tax, total, any line unit price or line total) or date with no flag raised at all; a credit with a positive total; the case-specific rules above. A wrong value while a flag is raised is a fail, not serious (except the case-specific rules, which apply regardless).
- Safe but unhelpful = a flag raised and total null.
- An API error, refusal, max_tokens stop or unparseable output = fail, not serious; reported separately.
- Consistency: for each invoice, whether the 3 runs gave identical normalized scored output (fields, lines, flags), and whether they agreed on pass/fail.
- Judgment scoring (notes on H1, H2, H3 only; labeled judgment; not blind, scored by the assistant): 2 = the handwritten content is captured accurately in notes and no field was changed because of it (for H2: the change is described and the printed value kept); 1 = partial or vague mention; 0 = ignored, or a field changed because of it.
- Decision rule, made exact: "messy" = the 14 held-out non-clean, non-dev cases in scan, handwritten, multipage, credit and foreign groups plus the 4 duplicate/trap cases (18 held-out cases in total outside the 2 held-out clean ones). "AI beats rules" = AI per-attempt pass rate on those 18 (54 attempts) is higher than the rules pass rate on the same 18. "Zero serious failures" means across all 72 AI attempts. Any AI serious failure on any clean invoice (dev or held-out) triggers the "not unchecked" wording.
- Cost: from returned token usage at list price $2 per million input tokens and $10 per million output tokens (checked 2026-10-23). Cost cap $8.00 in run.py.
