# EXP-004 deviations and disclosures

All times ET, 2026-10-23. Pre-run fingerprints: fingerprints.sha256 (written 18:11:15). Originals of any file changed after that are in evidence/prerun-originals/.

## Deviations (after the pre-run fingerprints)

### D1. H3 input clips the handwritten note (found after the run, input not changed)
- What: gen.py placed the H3 note "Approved for payment - M.K. 10/20" so its end runs off the right edge of the image. The visible text is "Approved for payment - M.K. 10/2". My pre-run spot-check of H3 did not catch it.
- Found: after scoring (about 18:20), while reading the AI notes, which said the date "appears cut off at the page edge". Confirmed by viewing evidence/inputs/H3.png.
- Effect on mechanical scores: none. No scored field depends on the note, and expected.json requires no flag on H3.
- Effect on judgment scores: H3 was scored against the visible text. All 3 AI runs quoted the visible text and said it was cut off, scored 2.
- Not fixed, so the input stays as fingerprinted. Rerunning would mean a new input and new calls.

### D2. tally.py per-case display bug (fixed after the run)
- What: in the per-case table, a missing flag that occurred in several runs was shown as "x1" (T1 showed "missing flag total_mismatch x1"; it was missed in 3/3 runs). The flags section of the same output already showed 3. Cause: Counter.update was given a dict, which collapses repeats.
- Fix: one line, Counter.update(Counter(...)). No score changed; scores come from score.py, which was not changed.
- Original: evidence/prerun-originals/tally.py (sha256 in fingerprints.sha256). New hash in fingerprints-postrun.sha256.

### D3. scores-mechanical.json rewritten after scoring (same content; disclosed 2026-10-23 after Ollie's review)
- What: score.py first ran at 18:16:15 (the tally printed right after it was written to /tmp/e4/tally1.txt, file created at 18:16:15 ET; because /tmp is cleared, a copy is packaged as evidence/scoring-check/tally-first-run-output.txt, and that packaged copy's own creation time is 18:31:41, not 18:16:15). At 18:20:39, while packaging, I copied scores-mechanical.json aside and re-ran score.py to check that it reproduces. The re-run rewrote the file, so its mtime is 18:20:39. `cmp` against the copy showed the files byte-identical. Ollie's independent re-score also matched byte for byte.
- Effect: none on any score. results.md, README and Notion now give both times.

### Status note on design.md (2026-10-23, revision 1)
- design.md lines 1-2 still read "PROPOSED, not run" and "Nothing generated or run". That was true when written. Ollie approved the design with changes (recorded in design.md's addendum), and the test was then run as described here. design.md is deliberately not edited, to keep the pre-run fingerprints intact.

### Revision 1 (2026-10-23, after Ollie's evidence review; text and disclosure only, no reruns)
- Article, results.md, publication.md, sources.md and Notion wording revised per Ollie's notes: invoice-to-invoice comparison (16/18 vs 14/18) plus the pre-registered 48/54 vs 14/18 sentence; S2 marked description-only; T1 caught by rules; rules script disclosed as an optimistic baseline written for these layouts; prompt example date 03/04/2026 = T2's trap date disclosed; Xero source replaced (old URL redirects); total API cost corrected to $1.1202 (was $1.1201, a rounding slip); scoring times clarified (D3). No input, prompt, rules, scorer or output file was changed.

### Approval line (2026-10-24, after Ross's approval)
- Ross approved the article in Ollie's chat on Oct 24 2026 at 10:22 AM ET ("I approve the invoices article, send it to Wally"). The approval placeholder comment in article.md and publication.md was replaced with "Reviewed and approved by Ross C, Oct 24, 2026." and publication.md's internal status header was updated. That is the only change: no other article text, input, prompt, rules, scorer or output file changed.

## Disclosures (before the pre-run fingerprints; not deviations, listed so nothing is hidden)

- P1. Rules dry run. rules.py (already locked at 18:04:55) was run on all 24 inputs before the fingerprints, to check the pipeline. Its outputs are kept in evidence/prerun-dryrun/. rules.py was not changed after it (hash unchanged since the lock). The official run at 18:11:26 was byte-identical to the dry run and to a second official run.
- P2. Thinking setting. Ollie asked for thinking "disabled or a fixed budget". claude-sonnet-5-5 rejects both with HTTP 400. Used `{"type": "between_tools"}`, which Anthropic's docs describe as the lowest setting on this model (turns off up-front thinking), with effort "high". I first hit the two 400s while reading the docs and did not save those attempts; I repeated them as 3 saved probe calls (evidence/smoke/thinking-probes.json) before fingerprinting. Every call reported 0 thinking tokens.
- P3. Smoke call. One call on a blank dummy image (evidence/smoke/) before fingerprinting, to check the request format. No invoice was sent before the fingerprints.
- P4. gen.py changes before fingerprinting: color mode for the handwriting scan (so blue ink stays blue), thicker strike line, M1 page break after row 18. The 4 dev PDFs re-rendered byte-identical.
- P5. Scan realism. The simulated scans are mild (slight rotation, noise, a coffee ring on S2 and S4, 150 dpi). Real phone photos and faxes can be worse. The handwriting is a font overlay, not real handwriting.
- P6. Judgment scoring is by the site's AI writing assistant, not blind, not re-scored by a person.
- P7. The person who wrote the cases, expected.json, rules.py and the prompt is the same agent. rules.py was written seeing only the 4 dev invoices; the prompt and scorer were written after all 24 cases existed.
- P8 (added in revision 1). The rules script was written by the same assistant that wrote gen.py, so it handles labels that appear only in held-out documents ("TOTAL CREDIT", "applied to invoice", "Credit Memo", GST/PST). It is an optimistic baseline for rules (design.md limits).
- P9 (added in revision 1). prompt.md rule 4 uses "03/04/2026" as its example of an ambiguous date. That is T2's exact trap date, so T2 was easier for the AI than an unseen date would be.
