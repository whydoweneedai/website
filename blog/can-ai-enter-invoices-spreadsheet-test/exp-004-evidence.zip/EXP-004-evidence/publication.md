# Publication metadata: EXP-004 (APPROVED)

Status: APPROVED (EXP-004, synthetic test). Ollie evidence review cleared Oct 23 2026; Ross approved in Ollie's chat Oct 24 2026 10:22 AM ET ("I approve the invoices article, send it to Wally"); handed to Wally for PR; not merged, not live.

- **Headline:** Can AI type your invoices into a spreadsheet? We tested it on 24 made-up invoices
- **Alternate headline:** AI copied 18 of 20 test invoices perfectly. It missed the one whose numbers didn't add up.
- **Slug:** `can-ai-enter-invoices-spreadsheet-test`
- **Meta description (151 chars):** We ran 24 invented invoices, including scans and handwriting, through an AI model and a rules script. AI read messy ones better but missed a bad total.
- **Pillar:** Tested experiments
- **Evidence label:** Synthetic test (EXP-004). 24 invented invoices, simulated scans and handwriting (font overlay). Not a live pilot.
- **Byline:** By Ross C, editor
- **Disclosure line (under article meta):** Test designed and scored with the site's AI writing assistant. Reviewed and approved by Ross C, Oct 24, 2026.
- **Date of test:** October 23, 2026
- **Key table:** "What happened" (fair-test invoices only; the 4 invoices used to write the rules script are mentioned separately)
- **Evidence download (if approved):** evidence.zip (sha256 in the final report and Notion entry)

## Claims allowed
- "In our synthetic test, the AI model got 18 of 20 held-out invoices fully right in all 3 of its runs. Our rules script got 16 of 20."
- "On the 18 messy held-out invoices, the AI passed 48 of 54 attempts (89%), the rules script 14 of 18 (78%)." Pair it with: the AI's pass/fail never changed between runs, so that is 16 of 18 invoices vs 14 of 18, a gap of 2 invoices out of 18.
- "The rules script caught the invoice whose line items didn't match its subtotal; the AI missed it in all 3 runs."
- "On the 4 simulated scans, the AI passed 4 of 4 invoices; the rules script passed 1 of 4."
- "On the invoice whose line items didn't match its subtotal, the AI copied the printed figures correctly but never raised the mismatch warning in 3 runs. The rules script caught it."
- "Neither method entered a wrong amount or date without a warning."
- "The 72 AI runs cost $1.11 at list price on 23 Oct 2026, about 1.5 cents per invoice per run."
- "On the 4 clean invoices used to write the rules script, both methods were perfect (AI 12/12, rules 4/4)."

## Claims not allowed
- Any accuracy rate for real invoices or other tools ("AI is 90% accurate at invoices").
- Time or money saved.
- Anything about how QuickBooks, Xero or Hubdoc perform beyond their own help pages.
- That the handwriting or scans were real.
- That a person scored or verified the test. Never "scored by" or "verified by" Ross C.
- That the result holds on other models, prompts or reruns.
- That AI "beat" rules; compare invoice to invoice instead.
- That phone photos were tested, or that AI did better than rules on foreign formats (both were perfect).
- That the rules script represents real-world rules tools; it was written for these layouts (optimistic baseline).
